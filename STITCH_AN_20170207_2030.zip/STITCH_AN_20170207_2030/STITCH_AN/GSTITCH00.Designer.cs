﻿namespace STITCH_AN
{
    partial class GSTITCH00
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GSTITCH00));
            this.grpCloth = new System.Windows.Forms.GroupBox();
            this.picCloth = new System.Windows.Forms.PictureBox();
            this.cmbReverse = new System.Windows.Forms.ComboBox();
            this.cmbRotate = new System.Windows.Forms.ComboBox();
            this.cmbSize = new System.Windows.Forms.ComboBox();
            this.cmbCloth = new System.Windows.Forms.ComboBox();
            this.grpStitches = new System.Windows.Forms.GroupBox();
            this.lblSave = new System.Windows.Forms.Label();
            this.lblAuto = new System.Windows.Forms.Label();
            this.lblMin = new System.Windows.Forms.Label();
            this.cmbMins = new System.Windows.Forms.ComboBox();
            this.txtInfo = new System.Windows.Forms.TextBox();
            this.picUndo4 = new System.Windows.Forms.PictureBox();
            this.picUndo3 = new System.Windows.Forms.PictureBox();
            this.picUndo2 = new System.Windows.Forms.PictureBox();
            this.picUndo1 = new System.Windows.Forms.PictureBox();
            this.picPallet8 = new System.Windows.Forms.PictureBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.clearPalleteToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.picPallet7 = new System.Windows.Forms.PictureBox();
            this.picPallet6 = new System.Windows.Forms.PictureBox();
            this.picPallet5 = new System.Windows.Forms.PictureBox();
            this.picPallet4 = new System.Windows.Forms.PictureBox();
            this.picPallet3 = new System.Windows.Forms.PictureBox();
            this.picPallet2 = new System.Windows.Forms.PictureBox();
            this.picPallet1 = new System.Windows.Forms.PictureBox();
            this.picStitchImage = new System.Windows.Forms.PictureBox();
            this.cmbCrossStitch = new System.Windows.Forms.ComboBox();
            this.picStitchColor = new System.Windows.Forms.PictureBox();
            this.cmbStitchColor = new System.Windows.Forms.ComboBox();
            this.rdoStitch = new System.Windows.Forms.RadioButton();
            this.rdoErase = new System.Windows.Forms.RadioButton();
            this.cmbBackColor = new System.Windows.Forms.ComboBox();
            this.grpDesign = new System.Windows.Forms.GroupBox();
            this.lblCloth = new System.Windows.Forms.Label();
            this.picDrawing = new System.Windows.Forms.PictureBox();
            this.btnDown = new System.Windows.Forms.Button();
            this.btnR = new System.Windows.Forms.Button();
            this.btnL = new System.Windows.Forms.Button();
            this.btnUp = new System.Windows.Forms.Button();
            this.btnCLR = new System.Windows.Forms.Button();
            this.btnLoad = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.lblOpacity = new System.Windows.Forms.Label();
            this.cmbOpacity = new System.Windows.Forms.ComboBox();
            this.picBackground = new System.Windows.Forms.PictureBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.timStoreImage = new System.Windows.Forms.Timer(this.components);
            this.cmbFOpacity = new System.Windows.Forms.ComboBox();
            this.grpCloth.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picCloth)).BeginInit();
            this.grpStitches.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picUndo4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picUndo3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picUndo2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picUndo1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPallet8)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picPallet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPallet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPallet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPallet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPallet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPallet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPallet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picStitchImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picStitchColor)).BeginInit();
            this.grpDesign.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picDrawing)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBackground)).BeginInit();
            this.SuspendLayout();
            // 
            // grpCloth
            // 
            this.grpCloth.Controls.Add(this.picCloth);
            this.grpCloth.Controls.Add(this.cmbReverse);
            this.grpCloth.Controls.Add(this.cmbRotate);
            this.grpCloth.Controls.Add(this.cmbSize);
            this.grpCloth.Controls.Add(this.cmbCloth);
            this.grpCloth.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.grpCloth.Location = new System.Drawing.Point(2, 29);
            this.grpCloth.Name = "grpCloth";
            this.grpCloth.Size = new System.Drawing.Size(192, 113);
            this.grpCloth.TabIndex = 0;
            this.grpCloth.TabStop = false;
            this.grpCloth.Text = "CLOTH";
            // 
            // picCloth
            // 
            this.picCloth.Location = new System.Drawing.Point(154, 18);
            this.picCloth.Name = "picCloth";
            this.picCloth.Size = new System.Drawing.Size(32, 32);
            this.picCloth.TabIndex = 16;
            this.picCloth.TabStop = false;
            // 
            // cmbReverse
            // 
            this.cmbReverse.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbReverse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbReverse.FormattingEnabled = true;
            this.cmbReverse.Location = new System.Drawing.Point(6, 82);
            this.cmbReverse.Name = "cmbReverse";
            this.cmbReverse.Size = new System.Drawing.Size(180, 20);
            this.cmbReverse.TabIndex = 13;
            this.cmbReverse.SelectedIndexChanged += new System.EventHandler(this.cmbReverse_SelectedIndexChanged);
            // 
            // cmbRotate
            // 
            this.cmbRotate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRotate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbRotate.FormattingEnabled = true;
            this.cmbRotate.Location = new System.Drawing.Point(98, 58);
            this.cmbRotate.Name = "cmbRotate";
            this.cmbRotate.Size = new System.Drawing.Size(88, 20);
            this.cmbRotate.TabIndex = 12;
            this.cmbRotate.SelectedIndexChanged += new System.EventHandler(this.cmbRotate_SelectedIndexChanged);
            // 
            // cmbSize
            // 
            this.cmbSize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbSize.FormattingEnabled = true;
            this.cmbSize.Location = new System.Drawing.Point(6, 58);
            this.cmbSize.Name = "cmbSize";
            this.cmbSize.Size = new System.Drawing.Size(88, 20);
            this.cmbSize.TabIndex = 11;
            this.cmbSize.SelectedIndexChanged += new System.EventHandler(this.cmbSize_SelectedIndexChanged);
            // 
            // cmbCloth
            // 
            this.cmbCloth.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCloth.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbCloth.FormattingEnabled = true;
            this.cmbCloth.Location = new System.Drawing.Point(6, 18);
            this.cmbCloth.Name = "cmbCloth";
            this.cmbCloth.Size = new System.Drawing.Size(142, 20);
            this.cmbCloth.TabIndex = 10;
            this.cmbCloth.SelectedIndexChanged += new System.EventHandler(this.cmbCloth_SelectedIndexChanged);
            // 
            // grpStitches
            // 
            this.grpStitches.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.grpStitches.Controls.Add(this.lblSave);
            this.grpStitches.Controls.Add(this.lblAuto);
            this.grpStitches.Controls.Add(this.lblMin);
            this.grpStitches.Controls.Add(this.cmbMins);
            this.grpStitches.Controls.Add(this.txtInfo);
            this.grpStitches.Controls.Add(this.picUndo4);
            this.grpStitches.Controls.Add(this.picUndo3);
            this.grpStitches.Controls.Add(this.picUndo2);
            this.grpStitches.Controls.Add(this.picUndo1);
            this.grpStitches.Controls.Add(this.picPallet8);
            this.grpStitches.Controls.Add(this.picPallet7);
            this.grpStitches.Controls.Add(this.picPallet6);
            this.grpStitches.Controls.Add(this.picPallet5);
            this.grpStitches.Controls.Add(this.picPallet4);
            this.grpStitches.Controls.Add(this.picPallet3);
            this.grpStitches.Controls.Add(this.picPallet2);
            this.grpStitches.Controls.Add(this.picPallet1);
            this.grpStitches.Controls.Add(this.picStitchImage);
            this.grpStitches.Controls.Add(this.cmbCrossStitch);
            this.grpStitches.Controls.Add(this.picStitchColor);
            this.grpStitches.Controls.Add(this.cmbStitchColor);
            this.grpStitches.Controls.Add(this.rdoStitch);
            this.grpStitches.Controls.Add(this.rdoErase);
            this.grpStitches.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.grpStitches.Location = new System.Drawing.Point(2, 148);
            this.grpStitches.Name = "grpStitches";
            this.grpStitches.Size = new System.Drawing.Size(192, 339);
            this.grpStitches.TabIndex = 1;
            this.grpStitches.TabStop = false;
            this.grpStitches.Text = "STITCH";
            // 
            // lblSave
            // 
            this.lblSave.AutoSize = true;
            this.lblSave.Location = new System.Drawing.Point(149, 205);
            this.lblSave.Name = "lblSave";
            this.lblSave.Size = new System.Drawing.Size(30, 12);
            this.lblSave.TabIndex = 44;
            this.lblSave.Text = "Save";
            // 
            // lblAuto
            // 
            this.lblAuto.AutoSize = true;
            this.lblAuto.Location = new System.Drawing.Point(149, 194);
            this.lblAuto.Name = "lblAuto";
            this.lblAuto.Size = new System.Drawing.Size(29, 12);
            this.lblAuto.TabIndex = 43;
            this.lblAuto.Text = "Auto";
            // 
            // lblMin
            // 
            this.lblMin.AutoSize = true;
            this.lblMin.Location = new System.Drawing.Point(149, 216);
            this.lblMin.Name = "lblMin";
            this.lblMin.Size = new System.Drawing.Size(29, 12);
            this.lblMin.TabIndex = 42;
            this.lblMin.Text = "Mins";
            // 
            // cmbMins
            // 
            this.cmbMins.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbMins.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbMins.FormattingEnabled = true;
            this.cmbMins.Location = new System.Drawing.Point(149, 231);
            this.cmbMins.Name = "cmbMins";
            this.cmbMins.Size = new System.Drawing.Size(37, 20);
            this.cmbMins.TabIndex = 26;
            this.cmbMins.SelectedIndexChanged += new System.EventHandler(this.cmbMins_SelectedIndexChanged);
            // 
            // txtInfo
            // 
            this.txtInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtInfo.Location = new System.Drawing.Point(6, 257);
            this.txtInfo.Multiline = true;
            this.txtInfo.Name = "txtInfo";
            this.txtInfo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtInfo.Size = new System.Drawing.Size(180, 72);
            this.txtInfo.TabIndex = 27;
            // 
            // picUndo4
            // 
            this.picUndo4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picUndo4.Location = new System.Drawing.Point(78, 183);
            this.picUndo4.Name = "picUndo4";
            this.picUndo4.Size = new System.Drawing.Size(68, 68);
            this.picUndo4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picUndo4.TabIndex = 38;
            this.picUndo4.TabStop = false;
            this.picUndo4.Click += new System.EventHandler(this.picUndo4_Click);
            // 
            // picUndo3
            // 
            this.picUndo3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picUndo3.Location = new System.Drawing.Point(6, 183);
            this.picUndo3.Name = "picUndo3";
            this.picUndo3.Size = new System.Drawing.Size(68, 68);
            this.picUndo3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picUndo3.TabIndex = 37;
            this.picUndo3.TabStop = false;
            this.picUndo3.Click += new System.EventHandler(this.picUndo3_Click);
            // 
            // picUndo2
            // 
            this.picUndo2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picUndo2.Location = new System.Drawing.Point(78, 111);
            this.picUndo2.Name = "picUndo2";
            this.picUndo2.Size = new System.Drawing.Size(68, 68);
            this.picUndo2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picUndo2.TabIndex = 36;
            this.picUndo2.TabStop = false;
            this.picUndo2.Click += new System.EventHandler(this.picUndo2_Click);
            // 
            // picUndo1
            // 
            this.picUndo1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picUndo1.Location = new System.Drawing.Point(6, 111);
            this.picUndo1.Name = "picUndo1";
            this.picUndo1.Size = new System.Drawing.Size(68, 68);
            this.picUndo1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picUndo1.TabIndex = 35;
            this.picUndo1.TabStop = false;
            this.picUndo1.Click += new System.EventHandler(this.picUndo1_Click);
            // 
            // picPallet8
            // 
            this.picPallet8.ContextMenuStrip = this.contextMenuStrip1;
            this.picPallet8.Location = new System.Drawing.Point(173, 36);
            this.picPallet8.Name = "picPallet8";
            this.picPallet8.Size = new System.Drawing.Size(16, 16);
            this.picPallet8.TabIndex = 34;
            this.picPallet8.TabStop = false;
            this.picPallet8.Click += new System.EventHandler(this.picPallet8_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clearPalleteToolStripMenuItem1});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(101, 26);
            this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
            // 
            // clearPalleteToolStripMenuItem1
            // 
            this.clearPalleteToolStripMenuItem1.Name = "clearPalleteToolStripMenuItem1";
            this.clearPalleteToolStripMenuItem1.Size = new System.Drawing.Size(100, 22);
            this.clearPalleteToolStripMenuItem1.Text = "Clear";
            this.clearPalleteToolStripMenuItem1.Click += new System.EventHandler(this.clearPalleteToolStripMenuItem1_Click);
            // 
            // picPallet7
            // 
            this.picPallet7.ContextMenuStrip = this.contextMenuStrip1;
            this.picPallet7.Location = new System.Drawing.Point(154, 36);
            this.picPallet7.Name = "picPallet7";
            this.picPallet7.Size = new System.Drawing.Size(16, 16);
            this.picPallet7.TabIndex = 33;
            this.picPallet7.TabStop = false;
            this.picPallet7.Click += new System.EventHandler(this.picPallet7_Click);
            // 
            // picPallet6
            // 
            this.picPallet6.ContextMenuStrip = this.contextMenuStrip1;
            this.picPallet6.Location = new System.Drawing.Point(135, 36);
            this.picPallet6.Name = "picPallet6";
            this.picPallet6.Size = new System.Drawing.Size(16, 16);
            this.picPallet6.TabIndex = 32;
            this.picPallet6.TabStop = false;
            this.picPallet6.Click += new System.EventHandler(this.picPallet6_Click);
            // 
            // picPallet5
            // 
            this.picPallet5.ContextMenuStrip = this.contextMenuStrip1;
            this.picPallet5.Location = new System.Drawing.Point(116, 36);
            this.picPallet5.Name = "picPallet5";
            this.picPallet5.Size = new System.Drawing.Size(16, 16);
            this.picPallet5.TabIndex = 31;
            this.picPallet5.TabStop = false;
            this.picPallet5.Click += new System.EventHandler(this.picPallet5_Click);
            // 
            // picPallet4
            // 
            this.picPallet4.ContextMenuStrip = this.contextMenuStrip1;
            this.picPallet4.Location = new System.Drawing.Point(173, 17);
            this.picPallet4.Name = "picPallet4";
            this.picPallet4.Size = new System.Drawing.Size(16, 16);
            this.picPallet4.TabIndex = 30;
            this.picPallet4.TabStop = false;
            this.picPallet4.Click += new System.EventHandler(this.picPallet4_Click);
            // 
            // picPallet3
            // 
            this.picPallet3.ContextMenuStrip = this.contextMenuStrip1;
            this.picPallet3.Location = new System.Drawing.Point(154, 17);
            this.picPallet3.Name = "picPallet3";
            this.picPallet3.Size = new System.Drawing.Size(16, 16);
            this.picPallet3.TabIndex = 29;
            this.picPallet3.TabStop = false;
            this.picPallet3.Click += new System.EventHandler(this.picPallet3_Click);
            // 
            // picPallet2
            // 
            this.picPallet2.ContextMenuStrip = this.contextMenuStrip1;
            this.picPallet2.Location = new System.Drawing.Point(135, 17);
            this.picPallet2.Name = "picPallet2";
            this.picPallet2.Size = new System.Drawing.Size(16, 16);
            this.picPallet2.TabIndex = 28;
            this.picPallet2.TabStop = false;
            this.picPallet2.Click += new System.EventHandler(this.picPallet2_Click);
            // 
            // picPallet1
            // 
            this.picPallet1.ContextMenuStrip = this.contextMenuStrip1;
            this.picPallet1.Location = new System.Drawing.Point(116, 17);
            this.picPallet1.Name = "picPallet1";
            this.picPallet1.Size = new System.Drawing.Size(16, 16);
            this.picPallet1.TabIndex = 27;
            this.picPallet1.TabStop = false;
            this.picPallet1.Click += new System.EventHandler(this.picPallet1_Click);
            // 
            // picStitchImage
            // 
            this.picStitchImage.Location = new System.Drawing.Point(154, 85);
            this.picStitchImage.Name = "picStitchImage";
            this.picStitchImage.Size = new System.Drawing.Size(16, 16);
            this.picStitchImage.TabIndex = 26;
            this.picStitchImage.TabStop = false;
            // 
            // cmbCrossStitch
            // 
            this.cmbCrossStitch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCrossStitch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbCrossStitch.FormattingEnabled = true;
            this.cmbCrossStitch.Location = new System.Drawing.Point(6, 85);
            this.cmbCrossStitch.Name = "cmbCrossStitch";
            this.cmbCrossStitch.Size = new System.Drawing.Size(142, 20);
            this.cmbCrossStitch.TabIndex = 25;
            this.cmbCrossStitch.SelectedIndexChanged += new System.EventHandler(this.cmbCrossStitch_SelectedIndexChanged);
            // 
            // picStitchColor
            // 
            this.picStitchColor.Location = new System.Drawing.Point(154, 59);
            this.picStitchColor.Name = "picStitchColor";
            this.picStitchColor.Size = new System.Drawing.Size(16, 16);
            this.picStitchColor.TabIndex = 24;
            this.picStitchColor.TabStop = false;
            // 
            // cmbStitchColor
            // 
            this.cmbStitchColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStitchColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbStitchColor.FormattingEnabled = true;
            this.cmbStitchColor.Location = new System.Drawing.Point(6, 59);
            this.cmbStitchColor.Name = "cmbStitchColor";
            this.cmbStitchColor.Size = new System.Drawing.Size(142, 20);
            this.cmbStitchColor.TabIndex = 24;
            this.cmbStitchColor.SelectedIndexChanged += new System.EventHandler(this.cmbStitchColor_SelectedIndexChanged);
            // 
            // rdoStitch
            // 
            this.rdoStitch.AutoSize = true;
            this.rdoStitch.Checked = true;
            this.rdoStitch.Location = new System.Drawing.Point(6, 40);
            this.rdoStitch.Name = "rdoStitch";
            this.rdoStitch.Size = new System.Drawing.Size(84, 16);
            this.rdoStitch.TabIndex = 21;
            this.rdoStitch.TabStop = true;
            this.rdoStitch.Text = "Stitch Color";
            this.rdoStitch.UseVisualStyleBackColor = true;
            // 
            // rdoErase
            // 
            this.rdoErase.AutoSize = true;
            this.rdoErase.Location = new System.Drawing.Point(6, 18);
            this.rdoErase.Name = "rdoErase";
            this.rdoErase.Size = new System.Drawing.Size(52, 16);
            this.rdoErase.TabIndex = 20;
            this.rdoErase.Text = "Erase";
            this.rdoErase.UseVisualStyleBackColor = true;
            // 
            // cmbBackColor
            // 
            this.cmbBackColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBackColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbBackColor.FormattingEnabled = true;
            this.cmbBackColor.Location = new System.Drawing.Point(5, 5);
            this.cmbBackColor.Name = "cmbBackColor";
            this.cmbBackColor.Size = new System.Drawing.Size(145, 20);
            this.cmbBackColor.TabIndex = 2;
            this.cmbBackColor.SelectedIndexChanged += new System.EventHandler(this.cmbBackColor_SelectedIndexChanged);
            // 
            // grpDesign
            // 
            this.grpDesign.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpDesign.Controls.Add(this.lblCloth);
            this.grpDesign.Controls.Add(this.picDrawing);
            this.grpDesign.Controls.Add(this.btnDown);
            this.grpDesign.Controls.Add(this.btnR);
            this.grpDesign.Controls.Add(this.btnL);
            this.grpDesign.Controls.Add(this.btnUp);
            this.grpDesign.Controls.Add(this.btnCLR);
            this.grpDesign.Controls.Add(this.btnLoad);
            this.grpDesign.Controls.Add(this.btnSave);
            this.grpDesign.Controls.Add(this.lblOpacity);
            this.grpDesign.Controls.Add(this.cmbOpacity);
            this.grpDesign.Controls.Add(this.picBackground);
            this.grpDesign.Location = new System.Drawing.Point(200, 2);
            this.grpDesign.Name = "grpDesign";
            this.grpDesign.Size = new System.Drawing.Size(471, 485);
            this.grpDesign.TabIndex = 2;
            this.grpDesign.TabStop = false;
            this.grpDesign.Text = "DESIGN";
            // 
            // lblCloth
            // 
            this.lblCloth.AutoSize = true;
            this.lblCloth.Location = new System.Drawing.Point(4, 15);
            this.lblCloth.Name = "lblCloth";
            this.lblCloth.Size = new System.Drawing.Size(32, 12);
            this.lblCloth.TabIndex = 46;
            this.lblCloth.Text = "Cloth";
            // 
            // picDrawing
            // 
            this.picDrawing.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.picDrawing.BackColor = System.Drawing.Color.Transparent;
            this.picDrawing.Location = new System.Drawing.Point(55, 10);
            this.picDrawing.Name = "picDrawing";
            this.picDrawing.Size = new System.Drawing.Size(413, 471);
            this.picDrawing.TabIndex = 45;
            this.picDrawing.TabStop = false;
            this.picDrawing.Click += new System.EventHandler(this.picDrawing_Click);
            this.picDrawing.MouseDown += new System.Windows.Forms.MouseEventHandler(this.picDrawing_MouseDown);
            this.picDrawing.MouseMove += new System.Windows.Forms.MouseEventHandler(this.picDrawing_MouseMove);
            this.picDrawing.MouseUp += new System.Windows.Forms.MouseEventHandler(this.picDrawing_MouseUp);
            // 
            // btnDown
            // 
            this.btnDown.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDown.Location = new System.Drawing.Point(6, 344);
            this.btnDown.Name = "btnDown";
            this.btnDown.Size = new System.Drawing.Size(44, 20);
            this.btnDown.TabIndex = 43;
            this.btnDown.Text = "Down";
            this.btnDown.UseVisualStyleBackColor = true;
            this.btnDown.Click += new System.EventHandler(this.btnDown_Click);
            // 
            // btnR
            // 
            this.btnR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnR.Location = new System.Drawing.Point(30, 322);
            this.btnR.Name = "btnR";
            this.btnR.Size = new System.Drawing.Size(20, 20);
            this.btnR.TabIndex = 42;
            this.btnR.Text = "R";
            this.btnR.UseVisualStyleBackColor = true;
            this.btnR.Click += new System.EventHandler(this.btnR_Click);
            // 
            // btnL
            // 
            this.btnL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnL.Location = new System.Drawing.Point(6, 322);
            this.btnL.Name = "btnL";
            this.btnL.Size = new System.Drawing.Size(21, 20);
            this.btnL.TabIndex = 41;
            this.btnL.Text = "L";
            this.btnL.UseVisualStyleBackColor = true;
            this.btnL.Click += new System.EventHandler(this.btnL_Click);
            // 
            // btnUp
            // 
            this.btnUp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUp.Location = new System.Drawing.Point(6, 300);
            this.btnUp.Name = "btnUp";
            this.btnUp.Size = new System.Drawing.Size(44, 20);
            this.btnUp.TabIndex = 40;
            this.btnUp.Text = "Up";
            this.btnUp.UseVisualStyleBackColor = true;
            this.btnUp.Click += new System.EventHandler(this.btnUp_Click);
            // 
            // btnCLR
            // 
            this.btnCLR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCLR.Location = new System.Drawing.Point(6, 251);
            this.btnCLR.Name = "btnCLR";
            this.btnCLR.Size = new System.Drawing.Size(44, 20);
            this.btnCLR.TabIndex = 39;
            this.btnCLR.Text = "CLR";
            this.btnCLR.UseVisualStyleBackColor = true;
            this.btnCLR.Click += new System.EventHandler(this.btnCLR_Click);
            // 
            // btnLoad
            // 
            this.btnLoad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLoad.Location = new System.Drawing.Point(6, 165);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(44, 40);
            this.btnLoad.TabIndex = 36;
            this.btnLoad.Text = "Load Img";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // btnSave
            // 
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Location = new System.Drawing.Point(6, 208);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(44, 40);
            this.btnSave.TabIndex = 37;
            this.btnSave.Text = "Save Img";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lblOpacity
            // 
            this.lblOpacity.AutoSize = true;
            this.lblOpacity.Location = new System.Drawing.Point(5, 28);
            this.lblOpacity.Name = "lblOpacity";
            this.lblOpacity.Size = new System.Drawing.Size(44, 12);
            this.lblOpacity.TabIndex = 17;
            this.lblOpacity.Text = "Opacity";
            // 
            // cmbOpacity
            // 
            this.cmbOpacity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbOpacity.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbOpacity.FormattingEnabled = true;
            this.cmbOpacity.Location = new System.Drawing.Point(6, 43);
            this.cmbOpacity.Name = "cmbOpacity";
            this.cmbOpacity.Size = new System.Drawing.Size(46, 20);
            this.cmbOpacity.TabIndex = 30;
            this.cmbOpacity.SelectedIndexChanged += new System.EventHandler(this.cmbOpacity_SelectedIndexChanged_1);
            // 
            // picBackground
            // 
            this.picBackground.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.picBackground.Location = new System.Drawing.Point(55, 10);
            this.picBackground.Name = "picBackground";
            this.picBackground.Size = new System.Drawing.Size(413, 471);
            this.picBackground.TabIndex = 2;
            this.picBackground.TabStop = false;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // timStoreImage
            // 
            this.timStoreImage.Interval = 10000;
            this.timStoreImage.Tick += new System.EventHandler(this.timStoreImage_Tick);
            // 
            // cmbFOpacity
            // 
            this.cmbFOpacity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFOpacity.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbFOpacity.FormattingEnabled = true;
            this.cmbFOpacity.Location = new System.Drawing.Point(151, 5);
            this.cmbFOpacity.Name = "cmbFOpacity";
            this.cmbFOpacity.Size = new System.Drawing.Size(46, 20);
            this.cmbFOpacity.TabIndex = 3;
            this.cmbFOpacity.SelectedIndexChanged += new System.EventHandler(this.cmbFOpacity_SelectedIndexChanged);
            // 
            // GSTITCH00
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.OldLace;
            this.ClientSize = new System.Drawing.Size(674, 489);
            this.Controls.Add(this.cmbFOpacity);
            this.Controls.Add(this.grpDesign);
            this.Controls.Add(this.cmbBackColor);
            this.Controls.Add(this.grpStitches);
            this.Controls.Add(this.grpCloth);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "GSTITCH00";
            this.Text = "STITCH_AN";
            this.Load += new System.EventHandler(this.GSTITCH00_Load);
            this.SizeChanged += new System.EventHandler(this.GSTITCH00_SizeChanged);
            this.grpCloth.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picCloth)).EndInit();
            this.grpStitches.ResumeLayout(false);
            this.grpStitches.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picUndo4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picUndo3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picUndo2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picUndo1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPallet8)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picPallet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPallet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPallet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPallet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPallet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPallet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPallet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picStitchImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picStitchColor)).EndInit();
            this.grpDesign.ResumeLayout(false);
            this.grpDesign.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picDrawing)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBackground)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpCloth;
        private System.Windows.Forms.ComboBox cmbRotate;
        private System.Windows.Forms.ComboBox cmbSize;
        private System.Windows.Forms.ComboBox cmbCloth;
        private System.Windows.Forms.ComboBox cmbReverse;
        private System.Windows.Forms.GroupBox grpStitches;
        private System.Windows.Forms.ComboBox cmbBackColor;
        private System.Windows.Forms.GroupBox grpDesign;
        private System.Windows.Forms.PictureBox picBackground;
        private System.Windows.Forms.ComboBox cmbStitchColor;
        private System.Windows.Forms.RadioButton rdoStitch;
        private System.Windows.Forms.RadioButton rdoErase;
        private System.Windows.Forms.PictureBox picCloth;
        private System.Windows.Forms.Label lblOpacity;
        private System.Windows.Forms.ComboBox cmbOpacity;
        private System.Windows.Forms.PictureBox picStitchColor;
        private System.Windows.Forms.PictureBox picStitchImage;
        private System.Windows.Forms.ComboBox cmbCrossStitch;
        private System.Windows.Forms.PictureBox picDrawing;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Button btnCLR;
        private System.Windows.Forms.PictureBox picPallet4;
        private System.Windows.Forms.PictureBox picPallet3;
        private System.Windows.Forms.PictureBox picPallet2;
        private System.Windows.Forms.PictureBox picPallet1;
        private System.Windows.Forms.PictureBox picPallet8;
        private System.Windows.Forms.PictureBox picPallet7;
        private System.Windows.Forms.PictureBox picPallet6;
        private System.Windows.Forms.PictureBox picPallet5;
        private System.Windows.Forms.PictureBox picUndo4;
        private System.Windows.Forms.PictureBox picUndo3;
        private System.Windows.Forms.PictureBox picUndo2;
        private System.Windows.Forms.PictureBox picUndo1;
        private System.Windows.Forms.TextBox txtInfo;
        private System.Windows.Forms.Timer timStoreImage;
        private System.Windows.Forms.ComboBox cmbMins;
        private System.Windows.Forms.Label lblMin;
        private System.Windows.Forms.Button btnDown;
        private System.Windows.Forms.Button btnR;
        private System.Windows.Forms.Button btnL;
        private System.Windows.Forms.Button btnUp;
        private System.Windows.Forms.Label lblSave;
        private System.Windows.Forms.Label lblAuto;
        private System.Windows.Forms.Label lblCloth;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem clearPalleteToolStripMenuItem1;
        private System.Windows.Forms.ComboBox cmbFOpacity;
    }
}

