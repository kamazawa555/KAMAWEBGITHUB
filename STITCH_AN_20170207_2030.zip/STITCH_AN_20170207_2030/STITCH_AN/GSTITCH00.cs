﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;
using System.Linq;
using System.Runtime.InteropServices;

namespace STITCH_AN
{

    public partial class GSTITCH00 : Form
    {
        ToolTip mo_tooltip;
        string ms_appFolder;
        Boolean mb_Now_Initializing = false;
        Image mo_StitchImage;
        Boolean mb_Drawing = false;
        Bitmap mo_canvas;
        string[] ms_picPallet;
        string[] ms_imgPallet;
        string[] ms_UndoToolTip;
        Bitmap mo_previous_bitmap;
        int mi_Undo_index = 0;
        int mi_times = 1;
        int mi_previous_X = -1;
        int mi_previous_Y = -1;

        [System.Runtime.InteropServices.DllImport(
            "user32.dll",
            CharSet = System.Runtime.InteropServices.CharSet.Auto)]
        extern static bool DestroyIcon(IntPtr handle);

        public GSTITCH00()
        {
            InitializeComponent();
        }

        private void GSTITCH00_Load(object sender, EventArgs e)
        {
            cmbBackColor.DrawMode = DrawMode.OwnerDrawFixed;
            cmbBackColor.DrawItem += new DrawItemEventHandler(this.cmbColor_DrawItem);
            cmbStitchColor.DrawMode = DrawMode.OwnerDrawFixed;
            cmbStitchColor.DrawItem += new DrawItemEventHandler(this.cmbColor_DrawItem);
            M0_Initialize_Form();
        }

        public void M0_Initialize_Form() {
            ms_picPallet = new string [8] { "", "", "", "", "", "", "", "" };
            ms_imgPallet = new string [8] { "", "", "", "", "", "", "", "" };
            ms_UndoToolTip = new string [4] { "", "", "", ""};
            mb_Now_Initializing = true;
            ms_appFolder = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            this.KeyPreview = true;
            cmbCloth.Items.Clear();
            IEnumerable<string> files =
                Directory.EnumerateFiles(
                    ms_appFolder, "*.jpg", SearchOption.AllDirectories);
            foreach (string f in files)
            {
                cmbCloth.Items.Add(Path.GetFileName(f));
            }
            cmbCloth.SelectedIndex = 0;
            cmbCrossStitch.Items.Clear();
            IEnumerable<string> files2 =
                Directory.EnumerateFiles(
                    ms_appFolder, "*.bmp", SearchOption.AllDirectories);
            foreach (string f in files2)
            {
                cmbCrossStitch.Items.Add(Path.GetFileName(f));
            }
            cmbCrossStitch.SelectedIndex = 3;
            cmbSize.Items.Clear();
            cmbSize.Items.Add("x20");
            cmbSize.Items.Add("x30");
            cmbSize.Items.Add("x32");
            cmbSize.Items.Add("x40");
            cmbSize.Items.Add("x50");
            cmbSize.Items.Add("x60");
            cmbSize.Items.Add("x70");
            cmbSize.Items.Add("x80");
            cmbSize.SelectedIndex = 3; 
            cmbRotate.Items.Clear();
            cmbRotate.Items.Add("RotateNone");
            cmbRotate.Items.Add("Rotate90");
            cmbRotate.Items.Add("Rotate180");
            cmbRotate.Items.Add("Rotate270");
            cmbRotate.SelectedIndex = 0;
            cmbReverse.Items.Clear();
            cmbReverse.Items.Add("FlipNone");
            cmbReverse.Items.Add("FlipX");
            cmbReverse.Items.Add("FlipY");
            cmbReverse.SelectedIndex = 0;
            cmbOpacity.Items.Clear();
            cmbOpacity.Items.Add("0.0");
            cmbOpacity.Items.Add("0.1");
            cmbOpacity.Items.Add("0.2");
            cmbOpacity.Items.Add("0.3");
            cmbOpacity.Items.Add("0.4");
            cmbOpacity.Items.Add("0.5");
            cmbOpacity.Items.Add("0.6");
            cmbOpacity.Items.Add("0.7");
            cmbOpacity.Items.Add("0.8");
            cmbOpacity.Items.Add("0.9");
            cmbOpacity.Items.Add("1.0");
            cmbOpacity.SelectedIndex = cmbOpacity.Items.Count-1;
            cmbFOpacity.Items.Clear();
            cmbFOpacity.Items.Add("0.1");
            cmbFOpacity.Items.Add("0.2");
            cmbFOpacity.Items.Add("0.3");
            cmbFOpacity.Items.Add("0.4");
            cmbFOpacity.Items.Add("0.5");
            cmbFOpacity.Items.Add("0.6");
            cmbFOpacity.Items.Add("0.7");
            cmbFOpacity.Items.Add("0.8");
            cmbFOpacity.Items.Add("0.9");
            cmbFOpacity.Items.Add("1.0");
            cmbFOpacity.SelectedIndex = cmbFOpacity.Items.Count - 1;
            cmbBackColor.Items.Clear();
            M1_Add_Item_Color(cmbBackColor, true);
            Random r = new Random();
            cmbBackColor.SelectedIndex = r.Next(cmbBackColor.Items.Count);
            cmbStitchColor.Items.Clear();
            M1_Add_Item_Color(cmbStitchColor, false);
            cmbStitchColor.Text = "Red";
            cmbMins.Items.Clear();
            cmbMins.Items.Add("");
            cmbMins.Items.Add("3");
            cmbMins.Items.Add("10");
            cmbMins.Items.Add("30");
            cmbMins.SelectedIndex = 1;
            mo_tooltip = new ToolTip();
            mo_tooltip.InitialDelay = 300;
            mo_tooltip.ReshowDelay = 300;
            mo_tooltip.AutoPopDelay = 5000;
            mo_tooltip.ShowAlways = true;
            mo_tooltip.SetToolTip(cmbCloth, "Cloth - Design Background image.");
            mo_tooltip.SetToolTip(cmbCrossStitch, "Stitch - Design Foreground Stitching image.");
            mo_tooltip.SetToolTip(cmbSize, "Size - Repeat times of Cloth image.");
            mo_tooltip.SetToolTip(cmbOpacity, "Opacity - If you want not to display Design Background image, use this setting set to zero.");
            mo_tooltip.SetToolTip(cmbRotate, "Rotate - Rotate Cloth image.");
            mo_tooltip.SetToolTip(cmbReverse, "Reverse - Reverse Cloth image.");
            mo_tooltip.SetToolTip(cmbBackColor, "BackColor - This is Random. You can change this anytime.");
            mo_tooltip.SetToolTip(cmbFOpacity, "Form Opacity - If you want to overlay another window, use this setting.");
            mo_tooltip.SetToolTip(cmbStitchColor, "StitchColor - If you want to change Stitching color.");
            mo_tooltip.SetToolTip(cmbMins, "Mins - Minutes of Auto Saving Interval.");
            mo_tooltip.SetToolTip(btnLoad, "Load Image - If you want to load Previously saved image.");
            mo_tooltip.SetToolTip(btnSave, "Save Image - If you want to save image.");
            mo_tooltip.SetToolTip(btnCLR, "Clear Image - If you want to clear image.");
            mo_tooltip.SetToolTip(rdoErase, "Erase Mode - If you want to erase Stitches, use this mode.");
            mo_tooltip.SetToolTip(rdoStitch, "Stitch Mode - If you want to stitch, use this mode.");
            mb_Now_Initializing = false;
            M1_cmbCloth_Refresh();
            M3_txtInfo_Append("STITCH_AN Started.");
        }

        private void M1_Add_Item_Color(ComboBox pc_ComboBox, Boolean pb_Pastel)
        {
            Boolean lb_color_is_DontUseColor;
            string[] dont_use_color = {
                "ActiveBorder","ActiveCaption","ActiveCaptionText","AppWorkspace",
                "Control","ControlDark","ControlDarkDark","ControlLight","ControlLightLight","ControlText",
                "Desktop","GrayText","Highlight","HighlightText",
                "ButtonFace", "ButtonHighlight", "ButtonShadow",
                "GradientActiveCaption", "GradientInactiveCaption",
                "HotTrack","InactiveBorder","InactiveCaption","InactiveCaptionText",
                "Info","InfoText","Menu","MenuBar", "MenuHighlight","MenuText","ScrollBar","Window","WindowFrame","WindowText",
                "Transparent"
            };
            lb_color_is_DontUseColor = false;
            foreach (string colorname in Enum.GetNames(typeof(KnownColor)))
            {
                lb_color_is_DontUseColor = false;
                for (int i = 0; i < dont_use_color.Length; i++)
                {
                    if (colorname == dont_use_color[i])
                    {
                        lb_color_is_DontUseColor = true;
                        break;
                    }
                }
                if (lb_color_is_DontUseColor == false)
                {
                    if ((pb_Pastel == true) && (ColorTranslator.FromHtml(colorname).GetBrightness() >= 0.65 ) &&
                             (ColorTranslator.FromHtml(colorname).GetBrightness() <= 0.98))
                    {
                        pc_ComboBox.Items.Add(colorname);
                    }
                    else if  (pb_Pastel == false) {
                        pc_ComboBox.Items.Add(colorname);
                    }
                }
            }
        }

        private void GSTITCH00_SizeChanged(object sender, EventArgs e)
        {
            M1_cmbCloth_Refresh();
        }

        private void M1_picDrawing_Resize()
        {
            picDrawing.Top = 0;
            picDrawing.Left = 0;
            picDrawing.Width = picBackground.Width;
            picDrawing.Height = picBackground.Height;
        }

        private void cmbColor_DrawItem(object sender, DrawItemEventArgs e)
        {
            string ls_icon = "";
            if (e.Index == -1) { return; }
            ComboBox cmbColor = (ComboBox)sender;
            string ls_Color = e.Index > -1 ? cmbColor.Items[e.Index].ToString() : cmbColor.Text;
            if (ls_Color == "Black") {
                ls_icon = " (#000001)";
            }
            e.DrawBackground();
            e.Graphics.DrawString("■", e.Font, new SolidBrush(Color.FromName(ls_Color)),
                 new RectangleF(e.Bounds.X, e.Bounds.Y, e.Bounds.Width, e.Bounds.Height));
            e.Graphics.DrawString("　　" + ls_Color + ls_icon, e.Font, new SolidBrush(e.ForeColor),
                 new RectangleF(e.Bounds.X, e.Bounds.Y, e.Bounds.Width, e.Bounds.Height));
            e.DrawFocusRectangle();
        }

        private void cmbBackColor_SelectedIndexChanged(object sender, EventArgs e)
        {
            M0_cmbBackColor_Change();
        }

        private void M0_cmbBackColor_Change()
        {
            this.BackColor = ColorTranslator.FromHtml(cmbBackColor.Text);
        }

        private void cmbSize_SelectedIndexChanged(object sender, EventArgs e)
        {
            M1_cmbCloth_Refresh();
            if ( picDrawing.Image == null) { return; }
            M1_Drawing_Resize();
        }

        private void cmbRotate_SelectedIndexChanged(object sender, EventArgs e)
        {
            M1_cmbCloth_Refresh();
        }

        private void cmbReverse_SelectedIndexChanged(object sender, EventArgs e)
        {
            M1_cmbCloth_Refresh();
        }

        private void cmbCloth_SelectedIndexChanged(object sender, EventArgs e)
        {
            string ls_cloth_file = Path.Combine(ms_appFolder, cmbCloth.Text);
            picCloth.ImageLocation = ls_cloth_file;
            M1_cmbCloth_Refresh();
        }

        private void M1_cmbCloth_Refresh()
        {
            if (mb_Now_Initializing == true) { return; }
            if (cmbCloth.Text == "") { return; }
            if (cmbSize.Text == "") { return; }
            if (cmbRotate.Text == "") { return; }
            if (cmbReverse.Text == "") { return; }

            picBackground.Visible = false;
            string ls_cloth_file = Path.Combine(ms_appFolder, cmbCloth.Text);
            Image img = Image.FromFile(ls_cloth_file);

            ColorMatrix cm = new ColorMatrix();
            cm.Matrix00 = 1;
            cm.Matrix11 = 1;
            cm.Matrix22 = 1;
            if (cmbOpacity.Text == "")
            {
                cm.Matrix33 = 1.0F;
            } 
            else
            {
                cm.Matrix33 = float.Parse(cmbOpacity.Text);
            }
            cm.Matrix44 = 1;
            ImageAttributes ia = new ImageAttributes();
            ia.SetColorMatrix(cm);

            mi_times = M2_Get_Times();
            picBackground.Width = img.Width * mi_times;
            picBackground.Height = img.Height * mi_times;
            picBackground.Visible = false;
            //Parent
            picDrawing.Parent = picBackground;
            picDrawing.Left = 0;
            picDrawing.Top = 0;
            picDrawing.Width = picBackground.Width;
            picDrawing.Height = picBackground.Height;
            Bitmap lo_canvas = new Bitmap(picBackground.Width, picBackground.Height);
            Graphics g = Graphics.FromImage(lo_canvas);
            for (int i = 0; i < mi_times; i++)
            {
                for (int j = 0; j < mi_times; j++)
                {
                    Rectangle lo_Rect = new Rectangle(img.Width * j, img.Height * i, img.Width, img.Height);
                    g.DrawImage(img, lo_Rect, 0, 0, img.Width, img.Height, GraphicsUnit.Pixel, ia);
                }
            }
            img.Dispose();
            g.Dispose();
            if ( cmbRotate.Text == "RotateNone" && cmbReverse.Text == "FlipNone")
            {
                //Skip
            }
            else if ( cmbRotate.Text == "Rotate90" && cmbReverse.Text == "FlipNone")
            {
                lo_canvas.RotateFlip(RotateFlipType.Rotate90FlipNone);
            }
            else if (cmbRotate.Text == "Rotate180" && cmbReverse.Text == "FlipNone")
            {
                lo_canvas.RotateFlip(RotateFlipType.Rotate180FlipNone);
            }
            else if (cmbRotate.Text == "Rotate270" && cmbReverse.Text == "FlipNone")
            {
                lo_canvas.RotateFlip(RotateFlipType.Rotate270FlipNone);
            }
            else if (cmbRotate.Text == "RotateNone" && cmbReverse.Text == "FlipX")
            {
                lo_canvas.RotateFlip(RotateFlipType.RotateNoneFlipX);
            }
            else if (cmbRotate.Text == "Rotate90" && cmbReverse.Text == "FlipX")
            {
                lo_canvas.RotateFlip(RotateFlipType.Rotate90FlipX);
            }
            else if (cmbRotate.Text == "Rotate180" && cmbReverse.Text == "FlipX")
            {
                lo_canvas.RotateFlip(RotateFlipType.Rotate180FlipX);
            }
            else if (cmbRotate.Text == "Rotate270" && cmbReverse.Text == "FlipX")
            {
                lo_canvas.RotateFlip(RotateFlipType.Rotate270FlipX);
            }
            else if (cmbRotate.Text == "RotateNone" && cmbReverse.Text == "FlipY")
            {
                lo_canvas.RotateFlip(RotateFlipType.RotateNoneFlipY);
            }
            else if (cmbRotate.Text == "Rotate90" && cmbReverse.Text == "FlipY")
            {
                lo_canvas.RotateFlip(RotateFlipType.Rotate90FlipY);
            }
            else if (cmbRotate.Text == "Rotate180" && cmbReverse.Text == "FlipY")
            {
                lo_canvas.RotateFlip(RotateFlipType.Rotate180FlipY);
            }
            else if (cmbRotate.Text == "Rotate270" && cmbReverse.Text == "FlipY")
            {
                lo_canvas.RotateFlip(RotateFlipType.Rotate270FlipY);
            }
            picBackground.Visible = true;
            picBackground.Image = lo_canvas;
        }

        private void M1_Drawing_Resize()
        {
            picDrawing.Width = picBackground.Width;
            picDrawing.Height = picBackground.Height;
            mo_canvas = new Bitmap(picDrawing.Width, picDrawing.Height);
            Graphics g = Graphics.FromImage(mo_canvas);
            Image img = picDrawing.Image;
            g.DrawImage(img, 0, 0, img.Width, img.Height);
            img.Dispose();
            g.Dispose();
            mo_canvas.MakeTransparent(Color.Black);
            picDrawing.Image = mo_canvas;
        }

        private void cmbOpacity_SelectedIndexChanged(object sender, EventArgs e)
        {
            M1_cmbCloth_Refresh();
        }

        private void cmbStitchColor_SelectedIndexChanged(object sender, EventArgs e)
        {
            M0_cmbStitchColor_Change();
        }

        private void M0_cmbStitchColor_Change()
        {
            if ( cmbStitchColor.Text == "Black") {
                picStitchColor.BackColor = ColorTranslator.FromHtml("#000001");
            }
            else
            {
                picStitchColor.BackColor = ColorTranslator.FromHtml(cmbStitchColor.Text);
            }
            if (mo_StitchImage == null) { return; }
            Bitmap img = new Bitmap(mo_StitchImage);
            ColorMap[] cm = new ColorMap[] { new ColorMap() };
            cm[0].OldColor = img.GetPixel(img.Width / 2, img.Height / 2);
            cm[0].NewColor = picStitchColor.BackColor;
            img.MakeTransparent(Color.Black);
            Graphics g = Graphics.FromImage(img);
            ImageAttributes ia = new ImageAttributes();
            ia.SetRemapTable(cm);
            Rectangle lo_Rect = new Rectangle(0, 0, img.Width, img.Height);
            g.DrawImage(img, lo_Rect, 0, 0, img.Width, img.Height, GraphicsUnit.Pixel, ia);
            picStitchImage.Image = img;
            //Stitchモードに変更
            if (rdoStitch.Checked == false) { rdoStitch.Checked = true; }
        }

        private void cmbCrossStitch_SelectedIndexChanged(object sender, EventArgs e)
        {
            M0_cmbCrossStitch_Change();
        }

        private void M0_cmbCrossStitch_Change()
        {
            string ls_crossstitch = Path.Combine(ms_appFolder, cmbCrossStitch.Text);
            mo_StitchImage = new Bitmap(ls_crossstitch);
            M0_cmbStitchColor_Change();
        }

        private void cmbOpacity_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            M1_cmbCloth_Refresh();
        }

        private void picDrawing_MouseDown(object sender, EventArgs e)
        {
            mb_Drawing = true;
            M1_picDrawing_Resize();
        }

        private void picDrawing_MouseUp(object sender, EventArgs e)
        {
            mb_Drawing = false;
            mi_previous_X = -1;
            mi_previous_Y = -1;
        }

        private void picDrawing_MouseMove(object sender, EventArgs e)
        {
            if (mb_Drawing == true)
            {
                System.Random r = new System.Random();
                System.Drawing.Point sp = System.Windows.Forms.Cursor.Position;
                System.Drawing.Point cp = picDrawing.PointToClient(sp);
                int li_x = cp.X / 16;
                int li_y = cp.Y / 16;
                M1_Draw_or_Erase_Stitch(li_x, li_y);
            }
        }

        private void picDrawing_Click(object sender, EventArgs e)
        {
            picDrawing_MouseMove(sender, e);
        }

        private void M1_Draw_or_Erase_Stitch(int pi_x, int pi_y)
        {
            if (mo_canvas == null)
            {
                mo_canvas = new Bitmap(picBackground.Width, picBackground.Height);
            }
            if (rdoStitch.Checked == true)
            {
                M2_Draw_Erase_Stitch(true, pi_x, pi_y);
                if (pi_x == mi_previous_X)
                {
                    M2_Fill_Vertical_Middle_Points(pi_x, mi_previous_Y, pi_y );
                } else if (pi_y == mi_previous_Y)
                {
                    M2_Fill_Horizontal_Middle_Points(pi_y, mi_previous_X, pi_x );
                }
                mi_previous_X = pi_x;
                mi_previous_Y = pi_y;

                M3_Prepare_Pallet();
            }
            else
            {
                M2_Draw_Erase_Stitch( false, pi_x, pi_y);
            }
        }

        private void M2_Fill_Vertical_Middle_Points(int pi_X, int pi_cpY1, int pi_cpY2)
        {
            if (Math.Abs(pi_cpY1 - pi_cpY2) <= 1) { return; }
            int pi_small;
            int pi_large;
            if (pi_cpY1 < pi_cpY2) {
                pi_small = pi_cpY1;
                pi_large = pi_cpY2;
            }
            else {
                pi_small = pi_cpY2;
                pi_large = pi_cpY1;
            }
            for (int i = 1; i < (pi_large - pi_small) ; i++)
            {
                M2_Draw_Erase_Stitch(true, pi_X, pi_small + i);
            }
        }

        private void M2_Fill_Horizontal_Middle_Points(int pi_Y, int pi_cpX1, int pi_cpX2)
        {
            if (Math.Abs(pi_cpX1 - pi_cpX2) <= 1) { return; }
            int pi_small;
            int pi_large;
            if (pi_cpX1 < pi_cpX2)
            {
                pi_small = pi_cpX1;
                pi_large = pi_cpX2;
            }
            else
            {
                pi_small = pi_cpX2;
                pi_large = pi_cpX1;
            }
            for (int i = 1; i < (pi_large - pi_small); i++)
            {
                M2_Draw_Erase_Stitch(true, pi_small + i, pi_Y);
            }
        }

        private void M3_Prepare_Pallet()
        {
            string ls_color;
            string ls_image;
            for (int i = 0; i < ms_picPallet.Length; i++)
            {
                ls_color = ms_picPallet[i];
                ls_image = ms_imgPallet[i];
                if ((cmbStitchColor.Text == ls_color) && (cmbCrossStitch.Text == ls_image))
                {
                    return;
                }
            }
            for (int i = 0; i < ms_picPallet.Length; i++)
            {
                if (ms_picPallet[i] == "")
                {
                    foreach (Control lc_picBox in grpStitches.Controls)
                    {
                        if (lc_picBox.Name == "picPallet" + (i+1) )
                        {
                            ms_picPallet[i] = cmbStitchColor.Text;
                            ms_imgPallet[i] = cmbCrossStitch.Text;
                            ((PictureBox)lc_picBox).Image = picStitchImage.Image;
                            mo_tooltip.SetToolTip(lc_picBox, cmbCrossStitch.Text + " : " + cmbStitchColor.Text);
                            return;
                        }
                    }
                }
            }
        }

        private void M2_Draw_Erase_Stitch(Boolean pb_Draw, int pi_x, int pi_y)
        {
            Graphics g = Graphics.FromImage(mo_canvas);
            Image img = picStitchImage.Image;
            int li_xpos = img.Width * pi_x;
            int li_ypos = img.Height * pi_y;
            g.FillRectangle(Brushes.Black, li_xpos, li_ypos, img.Width, img.Height);
            if (pb_Draw == true)
            {
                g.DrawImage(img, li_xpos, li_ypos, img.Width, img.Height);
            }
            Bitmap bmp = new Bitmap(mo_canvas);
            bmp.MakeTransparent(Color.Black);
            picDrawing.Image = bmp;
            mo_canvas = (Bitmap)picDrawing.Image;
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            M0_btnLoad_Click();
        }

        private void M0_btnLoad_Click()
        {
            string ls_Filepath = "";
            openFileDialog1.Filter = "PNG Image|*.png";
            openFileDialog1.FileName = ".png";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                ls_Filepath = openFileDialog1.FileName;
                picDrawing.Width = picBackground.Width;
                picDrawing.Height = picBackground.Height;
                mo_canvas = new Bitmap(picDrawing.Width, picDrawing.Height);
                Graphics g = Graphics.FromImage(mo_canvas);
                picDrawing.Image = Image.FromFile(ls_Filepath);
                Image img = picDrawing.Image;
                g.DrawImage(img, 0, 0, img.Width, img.Height);
                img.Dispose();
                g.Dispose();
                mo_canvas.MakeTransparent(Color.Black);
                picDrawing.Image = mo_canvas;
                M1_cmbCloth_Refresh();
                AutoClosingMessageBox.Show("Loaded.", "Notice", 1000);
                M3_txtInfo_Append("Loaded.", Path.GetFileName(ls_Filepath));
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            M0_btnSave_Click();
        }
        
        private void M0_btnSave_Click()
        {
            if (picDrawing.Image == null ) { return; }
            saveFileDialog1.Filter = "Drawing Image(Png)|*.png|Combined Image(Jpeg)|*.jpg|Icon Image (32x32 16 Color)|*.ico";
            saveFileDialog1.FilterIndex = 1;
            saveFileDialog1.FileName = ".png";
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string ls_extension = System.IO.Path.GetExtension(saveFileDialog1.FileName);
                switch (ls_extension.ToUpper())
                {
                    case ".JPG":
                        M1_Shrink_and_Save_picDrawing(saveFileDialog1.FileName, ls_extension);
                        break;
                    case ".PNG":
                        M1_Shrink_and_Save_picDrawing(saveFileDialog1.FileName, ls_extension);
                        break;
                    case ".ICO":
                        M1_Save_Icon(saveFileDialog1.FileName);
                        break;
                }

            }
        }

        private void M1_Save_Icon(string iconFile)
        {
            Bitmap canvas = new Bitmap(32, 32);
            Graphics g = Graphics.FromImage(canvas);
            Image lo_design = picDrawing.Image;
            Rectangle srcRect = new Rectangle(0, 0, 32 * 16, 32 * 16);
            Rectangle desRect = new Rectangle(0, 0, 32, 32);
            g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.NearestNeighbor;
            g.DrawImage(lo_design, desRect, srcRect, GraphicsUnit.Pixel);
            g.Dispose();
            Icon ico = System.Drawing.Icon.FromHandle(canvas.GetHicon());
            System.IO.FileStream fs = new System.IO.FileStream(
                iconFile, System.IO.FileMode.Create, System.IO.FileAccess.Write);
            ico.Save(fs);
            fs.Close();
            ico.Dispose();
            canvas.Dispose();
            DestroyIcon(ico.Handle);
        }

        private void M1_Shrink_and_Save_picDrawing(string ps_Filepath, string ps_extension)
        {
            PictureBox lo_picBox = new PictureBox();
            string ls_cloth_file = Path.Combine(ms_appFolder, cmbCloth.Text);
            Image lo_cloth = Image.FromFile(ls_cloth_file);
            Image lo_design = picDrawing.Image;
            mi_times = M2_Get_Times();
            lo_picBox.Width = lo_cloth.Width * mi_times;
            lo_picBox.Height = lo_cloth.Height * mi_times;
            Bitmap canvas = new Bitmap(lo_picBox.Width, lo_picBox.Height);
            Graphics g = Graphics.FromImage(canvas);
            Rectangle srcRect = new Rectangle(0, 0, lo_cloth.Width * mi_times, lo_cloth.Height * mi_times);
            Rectangle desRect = new Rectangle(0, 0, srcRect.Width, srcRect.Height);
            g.DrawImage(lo_design, desRect, srcRect, GraphicsUnit.Pixel);
            g.Dispose();
            lo_picBox.Image = lo_design;
            switch (ps_extension.ToUpper())
            {
                case ".JPG":
                    M2_Combined_Jpeg(lo_picBox.Image, ps_Filepath);
                    break;
                case ".PNG":
                    lo_picBox.Image.Save(ps_Filepath, System.Drawing.Imaging.ImageFormat.Png);
                    break;
            }
            AutoClosingMessageBox.Show("Saved.", "Notice", 1000);
            M3_txtInfo_Append("Saved.", Path.GetFileName(ps_Filepath));
        }

        private void M2_Combined_Jpeg(Image po_img, string ps_Filepath )
        {
            Bitmap img1 = new Bitmap(picBackground.Image);
            Bitmap img2 = new Bitmap(po_img);
            Bitmap img3 = new Bitmap(picBackground.Image);
            Graphics g = Graphics.FromImage(img3);
            g.DrawImage(img2, 0, 0, img2.Width, img2.Height);
            g.Dispose();
            img1.Dispose();
            img2.Dispose();
            img3.Save(ps_Filepath, System.Drawing.Imaging.ImageFormat.Jpeg);
        }

        private int M2_Get_Times()
        {
            string ls_size = cmbSize.Text;
            int li_times;
            string ls_cloth_file = Path.Combine(ms_appFolder, cmbCloth.Text);
            Image img = Image.FromFile(ls_cloth_file);
            if (ls_size.Length <= 2)
            {
                li_times = 1;
            }
            else
            {
                if (img.Width == 16)
                {
                    li_times = int.Parse(ls_size.Substring(1, 2));
                }
                else
                {
                    li_times = int.Parse(ls_size.Substring(1, 2)) / 2;
                }
            }
            return li_times;
        }

        private void btnCLR_Click(object sender, EventArgs e)
        {
            M0_btnCLR_Click();
        }

        private void M0_btnCLR_Click()
        {
            DialogResult result = MessageBox.Show("Are you sure you want to clear the image?",
                "Question", MessageBoxButtons.OKCancel,MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            if (result == DialogResult.OK)
            {
                picDrawing.Image = null;
                mo_canvas = null;
            }
        }

        private void picPallet1_Click(object sender, EventArgs e)
        {
            M0_picPallet_Click(0);
        }

        private void picPallet2_Click(object sender, EventArgs e)
        {
            M0_picPallet_Click(1);
        }

        private void picPallet3_Click(object sender, EventArgs e)
        {
            M0_picPallet_Click(2);
        }

        private void picPallet4_Click(object sender, EventArgs e)
        {
            M0_picPallet_Click(3);
        }

        private void picPallet5_Click(object sender, EventArgs e)
        {
            M0_picPallet_Click(4);
        }

        private void picPallet6_Click(object sender, EventArgs e)
        {
            M0_picPallet_Click(5);
        }

        private void picPallet7_Click(object sender, EventArgs e)
        {
            M0_picPallet_Click(6);
        }

        private void picPallet8_Click(object sender, EventArgs e)
        {
            M0_picPallet_Click(7);
        }

        private void M0_picPallet_Click(int po_index) {
            cmbStitchColor.Text = ms_picPallet[po_index];
            cmbCrossStitch.Text = ms_imgPallet[po_index];
            if (rdoStitch.Checked == false) { rdoStitch.Checked = true; }
        }

        private void timStoreImage_Tick(object sender, EventArgs e)
        {
            M0_Store_Image();
            System.GC.Collect();
        }

        private void M0_Store_Image()
        {
            string ls_datetime = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            string ls_filename = DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".png";
            string ls_info1 = "";
            string ls_info2 = "";
            int li_index;
            if (picDrawing.Image == null) { return; }
            Bitmap lo_bmp = (Bitmap)picDrawing.Image.Clone();
            if (mo_previous_bitmap != null && lo_bmp.ImageComp(mo_previous_bitmap))
            {
                ls_info1 = "Auto Save Skipped.";
                M3_txtInfo_Append(ls_info1);
            }
            else
            {
                mi_Undo_index += 1;
                li_index = mi_Undo_index % 4;
                if (li_index == 0) { li_index = 4; }
                switch (li_index)
                {
                    case 1:
                        M1_Store_Image(picUndo1, ls_datetime, ls_filename);
                        break;
                    case 2:
                        M1_Store_Image(picUndo2, ls_datetime, ls_filename);
                        break;
                    case 3:
                        M1_Store_Image(picUndo3, ls_datetime, ls_filename);
                        break;
                    default:
                        M1_Store_Image(picUndo4, ls_datetime, ls_filename);
                        break;
                }
                ls_info1 = "Auto Save" + " (" + li_index.ToString() + ")";
                ls_info2 = "%TMP% " + ls_filename;
                M3_txtInfo_Append(ls_info1, ls_info2);
            }
            mo_previous_bitmap = (Bitmap)picDrawing.Image.Clone();
        }

        private void M3_txtInfo_Append(string ps_info1)
        {
            M3_txtInfo_Append(ps_info1, "", "", "");
        }

        private void M3_txtInfo_Append(string ps_info1, string ps_info2)
        {
            M3_txtInfo_Append(ps_info1, ps_info2, "", "");
        }

        private void M3_txtInfo_Append(string ps_info1, string ps_info2, string ps_info3)
        {
            M3_txtInfo_Append(ps_info1, ps_info2, ps_info3, "");
        }

        private void M3_txtInfo_Append(string ps_info1, string ps_info2, string ps_info3, string ps_info4)
        {
            string ls_datetime = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            txtInfo.AppendText(ls_datetime + Environment.NewLine);
            if (ps_info1 != "") {
                txtInfo.AppendText(ps_info1 + Environment.NewLine);
            }
            if (ps_info2 != "")
            {
                txtInfo.AppendText(ps_info2 + Environment.NewLine);
            }
            if (ps_info3 != "")
            {
                txtInfo.AppendText(ps_info3 + Environment.NewLine);
            }
            if (ps_info4 != "")
            {
                txtInfo.AppendText(ps_info4 + Environment.NewLine);
            }
        }

        private void M1_Store_Image(PictureBox picBox, string ps_datetime, string ps_filename)
        {
            string ls_tmpfile = System.IO.Path.GetTempFileName();
            string ls_tmppath = System.IO.Path.GetTempPath();
            string ls_fullpath = System.IO.Path.Combine(ls_tmppath, ps_filename);
            picDrawing.Image.Save(ls_tmpfile, System.Drawing.Imaging.ImageFormat.Png);
            System.IO.File.Copy(ls_tmpfile, ls_fullpath);
            System.IO.File.Delete(ls_tmpfile);
            picBox.ImageLocation = ls_fullpath;
            int li_index = Int32.Parse(picBox.Name.Substring(picBox.Name.Length - 1, 1));
            M2_Set_Tooltip(li_index - 1, ps_filename);
        }

        private void M2_Set_Tooltip(int pi_Last, string ps_filename)
        {
            string ls_Last = " *** This is Last ***";
            ms_UndoToolTip[pi_Last] = ps_filename;
            ms_UndoToolTip[0] = ms_UndoToolTip[0].Replace(ls_Last, "");
            ms_UndoToolTip[1] = ms_UndoToolTip[1].Replace(ls_Last, "");
            ms_UndoToolTip[2] = ms_UndoToolTip[2].Replace(ls_Last, "");
            ms_UndoToolTip[3] = ms_UndoToolTip[3].Replace(ls_Last, "");
            ms_UndoToolTip[pi_Last] = ms_UndoToolTip[pi_Last] + ls_Last; 
            mo_tooltip.SetToolTip(picUndo1, ms_UndoToolTip[0]);
            mo_tooltip.SetToolTip(picUndo2, ms_UndoToolTip[1]);
            mo_tooltip.SetToolTip(picUndo3, ms_UndoToolTip[2]);
            mo_tooltip.SetToolTip(picUndo4, ms_UndoToolTip[3]);
        }

        private void M0_Restore_Image(PictureBox po_PicBox)
        {
            if (po_PicBox.Image != null ) {
                DialogResult result = MessageBox.Show("Are you sure you want to restore the image?",
                    "Question", MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
                if (result == DialogResult.OK)
                {
                    picDrawing.Image = po_PicBox.Image;
                    Bitmap bmp = new Bitmap(picDrawing.Image);
                    mo_canvas = bmp;
                    bmp.MakeTransparent(Color.Black);
                    picDrawing.Image = bmp;
                    mo_canvas = (Bitmap)picDrawing.Image;
                    AutoClosingMessageBox.Show("Restored.", "Notice", 1000);
                }
            }
        }

        private void picUndo1_Click(object sender, EventArgs e)
        {
            M0_Restore_Image(picUndo1);
        }

        private void picUndo2_Click(object sender, EventArgs e)
        {
            M0_Restore_Image(picUndo2);
        }

        private void picUndo3_Click(object sender, EventArgs e)
        {
            M0_Restore_Image(picUndo3);
        }

        private void picUndo4_Click(object sender, EventArgs e)
        {
            M0_Restore_Image(picUndo4);
        }

        private void cmbMins_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbMins.Text == "") {
                timStoreImage.Enabled = false;
                return;
            }
            timStoreImage.Enabled = true;
            timStoreImage.Interval = Int32.Parse(cmbMins.Text) * 1000 * 60;
        }

        private void btnUp_Click(object sender, EventArgs e)
        {
            M0_btnMove_Click(0, -16);
        }

        private void btnL_Click(object sender, EventArgs e)
        {
            M0_btnMove_Click(-16, 0);
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            M0_btnMove_Click(16, 0);
        }

        private void btnDown_Click(object sender, EventArgs e)
        {
            M0_btnMove_Click(0, 16);
        }

        private void M0_btnMove_Click(int dx, int dy)
        {
            if (picDrawing.Image == null) { return; }
            mo_canvas = new Bitmap(picBackground.Width, picBackground.Height);
            Graphics g = Graphics.FromImage(mo_canvas);
            Image img = picDrawing.Image;
            g.DrawImage(img, dx, dy, img.Width, img.Height);
            img.Dispose();
            g.Dispose();
            mo_canvas.MakeTransparent(Color.Black);
            picDrawing.Image = mo_canvas;
        }

        private void contextMenuStrip1_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }

        private void clearPalleteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Control source = contextMenuStrip1.SourceControl;
            if (source != null)
            {
                string ls_SourceName = source.Name;
                string ls_SourceType = ls_SourceName.Substring(0, 9);
                int i = Int32.Parse(ls_SourceName.Substring(9, 1));
                if (ls_SourceType == "picPallet" )
                {
                    ((PictureBox)source).Image = null;
                    mo_tooltip.SetToolTip(source, "");
                    ms_picPallet[i-1] = "";
                    ms_imgPallet[i-1] = "";
                }
            }
        }

        private void cmbFOpacity_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.Opacity = Double.Parse(cmbFOpacity.Text);
        }
    }

    public static class ImageEx
    {
        /// <summary>  
        /// 画像を高速に比較します。  
        /// </summary>  
        /// <param name="image2">比較する画像  
        /// <returns></returns>  
        static public bool ImageComp(this Image image1, Image image2)
        {
            Bitmap img1 = (Bitmap)image1;
            Bitmap img2 = (Bitmap)image2;
            //if (img1.Width != img2.Width || img1.Height != img2.Height) return false;
            BitmapData bd1 = img1.LockBits(new Rectangle(0, 0, img1.Width, img1.Height), System.Drawing.Imaging.ImageLockMode.ReadOnly, img1.PixelFormat);
            BitmapData bd2 = img2.LockBits(new Rectangle(0, 0, img2.Width, img2.Height), System.Drawing.Imaging.ImageLockMode.ReadOnly, img2.PixelFormat);
            //if ((bd1.Stride * img1.Height) != (bd2.Stride * img2.Height)) return false;
            int bsize = bd1.Stride * img1.Height;
            byte[] byte1 = new byte[bsize];
            byte[] byte2 = new byte[bsize];
            Marshal.Copy(bd1.Scan0, byte1, 0, bsize);
            Marshal.Copy(bd2.Scan0, byte2, 0, bsize);
            img1.UnlockBits(bd1);
            img2.UnlockBits(bd2);
            System.Security.Cryptography.MD5CryptoServiceProvider md5 =
                new System.Security.Cryptography.MD5CryptoServiceProvider();
            byte[] hash1 = md5.ComputeHash(byte1);
            byte[] hash2 = md5.ComputeHash(byte2);
            return hash1.SequenceEqual(hash2);
        }
    }

    public class AutoClosingMessageBox
    {
        int text_max_length = 200; //最大の文字列長の指定
        System.Threading.Timer _timeoutTimer;
        string _caption;

        AutoClosingMessageBox(string text, string caption, int timeout)
        {
            if (text.Length > text_max_length) //内容の長さを制限する追加部分
            {
                text = text.Substring(0, text_max_length);
            }
            //text = ( text.length > text_max_length ) ? text.Substring( 0, text_max_length ) : text; //三項目演算での記述方法　? の左側が true の時 : の左側が代入されます。 falseの時は右側
            _caption = caption;
            _timeoutTimer = new System.Threading.Timer(OnTimerElapsed, null, timeout, System.Threading.Timeout.Infinite);
            MessageBox.Show(text, caption);
        }

        public static void Show(string text, string caption, int timeout)
        {
            new AutoClosingMessageBox(text, caption, timeout);
        }

        void OnTimerElapsed(object state)
        {
            IntPtr mbWnd = FindWindow(null, _caption);
            if (mbWnd != IntPtr.Zero)
            {
                SendMessage(mbWnd, WM_CLOSE, IntPtr.Zero, IntPtr.Zero);
            }
            _timeoutTimer.Dispose();
        }

        const int WM_CLOSE = 0x0010;
        [System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true)]
        static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
        [System.Runtime.InteropServices.DllImport("user32.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto)]
        static extern IntPtr SendMessage(IntPtr hWnd, UInt32 Msg, IntPtr wParam, IntPtr lParam);
    }

}
