﻿namespace EBICHAN
{
    partial class GEBICMN00
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GEBICMN00));
            this.txtFolder = new System.Windows.Forms.TextBox();
            this.numSeconds = new System.Windows.Forms.NumericUpDown();
            this.btnFolder = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.txtPrefix = new System.Windows.Forms.TextBox();
            this.timTick = new System.Windows.Forms.Timer(this.components);
            this.picDrawing = new System.Windows.Forms.PictureBox();
            this.chkCursor = new System.Windows.Forms.CheckBox();
            this.cmbDrawing = new System.Windows.Forms.ComboBox();
            this.lblDrawing = new System.Windows.Forms.Label();
            this.btnQuit = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.lblOpacity = new System.Windows.Forms.Label();
            this.cmbOpacity = new System.Windows.Forms.ComboBox();
            this.cmbBackColor = new System.Windows.Forms.ComboBox();
            this.timTeaBreak = new System.Windows.Forms.Timer(this.components);
            this.btnUndo = new System.Windows.Forms.Button();
            this.btnHTML = new System.Windows.Forms.Button();
            this.cmbExt = new System.Windows.Forms.ComboBox();
            this.lblExt = new System.Windows.Forms.Label();
            this.chkImgDate = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.numSeconds)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDrawing)).BeginInit();
            this.SuspendLayout();
            // 
            // txtFolder
            // 
            this.txtFolder.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtFolder.Location = new System.Drawing.Point(1, 1);
            this.txtFolder.Name = "txtFolder";
            this.txtFolder.Size = new System.Drawing.Size(533, 19);
            this.txtFolder.TabIndex = 1;
            this.txtFolder.Text = "d:\\default_folder";
            // 
            // numSeconds
            // 
            this.numSeconds.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.numSeconds.Location = new System.Drawing.Point(535, 21);
            this.numSeconds.Maximum = new decimal(new int[] {
            600,
            0,
            0,
            0});
            this.numSeconds.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numSeconds.Name = "numSeconds";
            this.numSeconds.Size = new System.Drawing.Size(43, 19);
            this.numSeconds.TabIndex = 5;
            this.numSeconds.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numSeconds.ValueChanged += new System.EventHandler(this.numSeconds_ValueChanged);
            // 
            // btnFolder
            // 
            this.btnFolder.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFolder.BackColor = System.Drawing.Color.Transparent;
            this.btnFolder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFolder.Location = new System.Drawing.Point(535, 1);
            this.btnFolder.Name = "btnFolder";
            this.btnFolder.Size = new System.Drawing.Size(43, 20);
            this.btnFolder.TabIndex = 2;
            this.btnFolder.Text = "...";
            this.btnFolder.UseVisualStyleBackColor = false;
            this.btnFolder.Click += new System.EventHandler(this.btnFolder_Click);
            // 
            // btnStart
            // 
            this.btnStart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnStart.BackColor = System.Drawing.Color.Transparent;
            this.btnStart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStart.Location = new System.Drawing.Point(578, 1);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(43, 20);
            this.btnStart.TabIndex = 3;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnStop
            // 
            this.btnStop.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnStop.BackColor = System.Drawing.Color.Transparent;
            this.btnStop.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStop.Location = new System.Drawing.Point(578, 21);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(43, 20);
            this.btnStop.TabIndex = 6;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = false;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // txtPrefix
            // 
            this.txtPrefix.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPrefix.Location = new System.Drawing.Point(1, 21);
            this.txtPrefix.Name = "txtPrefix";
            this.txtPrefix.Size = new System.Drawing.Size(533, 19);
            this.txtPrefix.TabIndex = 4;
            this.txtPrefix.Text = "file name prefix";
            // 
            // timTick
            // 
            this.timTick.Tick += new System.EventHandler(this.timTick_Tick);
            // 
            // picDrawing
            // 
            this.picDrawing.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.picDrawing.BackColor = System.Drawing.Color.Transparent;
            this.picDrawing.Location = new System.Drawing.Point(1, 87);
            this.picDrawing.Name = "picDrawing";
            this.picDrawing.Size = new System.Drawing.Size(618, 28);
            this.picDrawing.TabIndex = 7;
            this.picDrawing.TabStop = false;
            this.picDrawing.MouseDown += new System.Windows.Forms.MouseEventHandler(this.picDrawing_MouseDown);
            this.picDrawing.MouseMove += new System.Windows.Forms.MouseEventHandler(this.picDrawing_MouseMove);
            this.picDrawing.MouseUp += new System.Windows.Forms.MouseEventHandler(this.picDrawing_MouseUp);
            // 
            // chkCursor
            // 
            this.chkCursor.AutoSize = true;
            this.chkCursor.BackColor = System.Drawing.Color.Transparent;
            this.chkCursor.Checked = true;
            this.chkCursor.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkCursor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chkCursor.Location = new System.Drawing.Point(6, 44);
            this.chkCursor.Name = "chkCursor";
            this.chkCursor.Size = new System.Drawing.Size(55, 16);
            this.chkCursor.TabIndex = 7;
            this.chkCursor.Text = "Cursor";
            this.chkCursor.UseVisualStyleBackColor = false;
            // 
            // cmbDrawing
            // 
            this.cmbDrawing.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDrawing.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbDrawing.FormattingEnabled = true;
            this.cmbDrawing.Location = new System.Drawing.Point(237, 41);
            this.cmbDrawing.Name = "cmbDrawing";
            this.cmbDrawing.Size = new System.Drawing.Size(75, 20);
            this.cmbDrawing.TabIndex = 12;
            // 
            // lblDrawing
            // 
            this.lblDrawing.AutoSize = true;
            this.lblDrawing.BackColor = System.Drawing.Color.Transparent;
            this.lblDrawing.Location = new System.Drawing.Point(185, 44);
            this.lblDrawing.Name = "lblDrawing";
            this.lblDrawing.Size = new System.Drawing.Size(46, 12);
            this.lblDrawing.TabIndex = 11;
            this.lblDrawing.Text = "Drawing";
            // 
            // btnQuit
            // 
            this.btnQuit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnQuit.BackColor = System.Drawing.Color.Transparent;
            this.btnQuit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQuit.Font = new System.Drawing.Font("MS UI Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnQuit.Location = new System.Drawing.Point(578, 41);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(43, 20);
            this.btnQuit.TabIndex = 16;
            this.btnQuit.Text = "Quit";
            this.btnQuit.UseVisualStyleBackColor = false;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.Transparent;
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClear.Location = new System.Drawing.Point(359, 41);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(43, 20);
            this.btnClear.TabIndex = 14;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // lblOpacity
            // 
            this.lblOpacity.AutoSize = true;
            this.lblOpacity.BackColor = System.Drawing.Color.Transparent;
            this.lblOpacity.Location = new System.Drawing.Point(61, 45);
            this.lblOpacity.Name = "lblOpacity";
            this.lblOpacity.Size = new System.Drawing.Size(44, 12);
            this.lblOpacity.TabIndex = 8;
            this.lblOpacity.Text = "Opacity";
            // 
            // cmbOpacity
            // 
            this.cmbOpacity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbOpacity.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbOpacity.FormattingEnabled = true;
            this.cmbOpacity.Location = new System.Drawing.Point(111, 41);
            this.cmbOpacity.Name = "cmbOpacity";
            this.cmbOpacity.Size = new System.Drawing.Size(48, 20);
            this.cmbOpacity.TabIndex = 9;
            this.cmbOpacity.SelectedIndexChanged += new System.EventHandler(this.cmbOpacity_SelectedIndexChanged);
            // 
            // cmbBackColor
            // 
            this.cmbBackColor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbBackColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBackColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbBackColor.FormattingEnabled = true;
            this.cmbBackColor.Location = new System.Drawing.Point(491, 41);
            this.cmbBackColor.Name = "cmbBackColor";
            this.cmbBackColor.Size = new System.Drawing.Size(87, 20);
            this.cmbBackColor.TabIndex = 15;
            this.cmbBackColor.SelectedIndexChanged += new System.EventHandler(this.cmbBackColor_SelectedIndexChanged);
            // 
            // btnUndo
            // 
            this.btnUndo.BackColor = System.Drawing.Color.Transparent;
            this.btnUndo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUndo.Location = new System.Drawing.Point(316, 41);
            this.btnUndo.Name = "btnUndo";
            this.btnUndo.Size = new System.Drawing.Size(43, 20);
            this.btnUndo.TabIndex = 13;
            this.btnUndo.Text = "Undo";
            this.btnUndo.UseVisualStyleBackColor = false;
            this.btnUndo.Click += new System.EventHandler(this.btnUndo_Click);
            // 
            // btnHTML
            // 
            this.btnHTML.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnHTML.BackColor = System.Drawing.Color.Transparent;
            this.btnHTML.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHTML.Font = new System.Drawing.Font("MS UI Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnHTML.Location = new System.Drawing.Point(578, 61);
            this.btnHTML.Name = "btnHTML";
            this.btnHTML.Size = new System.Drawing.Size(43, 20);
            this.btnHTML.TabIndex = 19;
            this.btnHTML.Text = "HTML";
            this.btnHTML.UseVisualStyleBackColor = false;
            this.btnHTML.Click += new System.EventHandler(this.btnHTML_Click);
            // 
            // cmbExt
            // 
            this.cmbExt.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbExt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbExt.FormattingEnabled = true;
            this.cmbExt.Location = new System.Drawing.Point(237, 63);
            this.cmbExt.Name = "cmbExt";
            this.cmbExt.Size = new System.Drawing.Size(48, 20);
            this.cmbExt.TabIndex = 18;
            // 
            // lblExt
            // 
            this.lblExt.AutoSize = true;
            this.lblExt.BackColor = System.Drawing.Color.Transparent;
            this.lblExt.Location = new System.Drawing.Point(176, 66);
            this.lblExt.Name = "lblExt";
            this.lblExt.Size = new System.Drawing.Size(55, 12);
            this.lblExt.TabIndex = 19;
            this.lblExt.Text = "Extension";
            // 
            // chkImgDate
            // 
            this.chkImgDate.AutoSize = true;
            this.chkImgDate.BackColor = System.Drawing.Color.Transparent;
            this.chkImgDate.Checked = true;
            this.chkImgDate.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkImgDate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chkImgDate.Location = new System.Drawing.Point(6, 63);
            this.chkImgDate.Name = "chkImgDate";
            this.chkImgDate.Size = new System.Drawing.Size(103, 16);
            this.chkImgDate.TabIndex = 17;
            this.chkImgDate.Text = "Datetime Stamp";
            this.chkImgDate.UseVisualStyleBackColor = false;
            // 
            // GEBICMN00
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackColor = System.Drawing.Color.MistyRose;
            this.ClientSize = new System.Drawing.Size(624, 121);
            this.Controls.Add(this.chkImgDate);
            this.Controls.Add(this.lblExt);
            this.Controls.Add(this.cmbExt);
            this.Controls.Add(this.btnHTML);
            this.Controls.Add(this.btnUndo);
            this.Controls.Add(this.cmbBackColor);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.cmbOpacity);
            this.Controls.Add(this.lblOpacity);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.lblDrawing);
            this.Controls.Add(this.cmbDrawing);
            this.Controls.Add(this.chkCursor);
            this.Controls.Add(this.txtPrefix);
            this.Controls.Add(this.btnFolder);
            this.Controls.Add(this.numSeconds);
            this.Controls.Add(this.txtFolder);
            this.Controls.Add(this.picDrawing);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "GEBICMN00";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "EBICHAN";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.GEBICMN00_FormClosing);
            this.Load += new System.EventHandler(this.GEBICMN00_Load);
            this.SizeChanged += new System.EventHandler(this.GEBICMN00_SizeChanged);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.GEBICMN00_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.numSeconds)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picDrawing)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtFolder;
        private System.Windows.Forms.NumericUpDown numSeconds;
        private System.Windows.Forms.Button btnFolder;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.TextBox txtPrefix;
        private System.Windows.Forms.Timer timTick;
        private System.Windows.Forms.PictureBox picDrawing;
        private System.Windows.Forms.CheckBox chkCursor;
        private System.Windows.Forms.ComboBox cmbDrawing;
        private System.Windows.Forms.Label lblDrawing;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lblOpacity;
        private System.Windows.Forms.ComboBox cmbOpacity;
        private System.Windows.Forms.ComboBox cmbBackColor;
        private System.Windows.Forms.Timer timTeaBreak;
        private System.Windows.Forms.Button btnUndo;
        private System.Windows.Forms.Button btnHTML;
        private System.Windows.Forms.ComboBox cmbExt;
        private System.Windows.Forms.Label lblExt;
        private System.Windows.Forms.CheckBox chkImgDate;
    }
}

