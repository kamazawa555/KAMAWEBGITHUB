﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EBICHAN
{
    public partial class GEBICMN00 : Form
    {
        string ms_previous_datetime = "";
        Bitmap mo_previous_image;
        ToolTip mo_tooltip;
        int mi_mouse_x1, mi_mouse_x2;
        int mi_mouse_y1, mi_mouse_y2;
        Boolean mb_Drawing;
        Image mo_undo_image;

        public GEBICMN00()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            M0_btnStart_Click();
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            M0_btnStop_Click();
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            M0_btnQuit_Click();
        }

        private void btnFolder_Click(object sender, EventArgs e)
        {
            M0_btnFolder_Click();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            M0_btnClear_Click();
        }

        private void btnUndo_Click(object sender, EventArgs e)
        {
            M0_btnUndo_Click();
        }

        private void btnHTML_Click(object sender, EventArgs e)
        {
            M0_btnHTML_Click();
        }

        private void GEBICMN00_SizeChanged(object sender, EventArgs e)
        {
            M0_Form_SizeChanged();
        }

        private void timTick_Tick(object sender, EventArgs e)
        {
            M0_timTick_Tick();
        }

        private void timTeaBreak_Tick(object sender, EventArgs e)
        {
            M0_timTeaBreak_Tick();
        }

        private void picDrawing_MouseDown(object sender, EventArgs e)
        {
            if (cmbDrawing.Text == "None")
            {
                return;
            }
            mo_undo_image = picDrawing.Image;
            btnUndo.Enabled = true;
            btnUndo.Visible = true;
            mb_Drawing = true;
            System.Drawing.Point sp = System.Windows.Forms.Cursor.Position;
            System.Drawing.Point cp = picDrawing.PointToClient(sp);
            mi_mouse_x1 = cp.X;
            mi_mouse_y1 = cp.Y;
        }

        private void picDrawing_MouseUp(object sender, EventArgs e)
        {
            if (cmbDrawing.Text == "None") {
                return;
            }
            System.Drawing.Point sp = System.Windows.Forms.Cursor.Position;
            System.Drawing.Point cp = picDrawing.PointToClient(sp);
            mi_mouse_x2 = cp.X;
            mi_mouse_y2 = cp.Y;
            if ( mi_mouse_x2 < mi_mouse_x1)  {
                Swap<int>(ref mi_mouse_x1, ref mi_mouse_x2);
            }
            if (mi_mouse_y2 < mi_mouse_y1)
            {
                Swap<int>(ref mi_mouse_y1, ref mi_mouse_y2);
            }
            int width = mi_mouse_x2 - mi_mouse_x1;
            int height = mi_mouse_y2 - mi_mouse_y1;
            Bitmap img = new Bitmap(picDrawing.Image);
            Graphics g = Graphics.FromImage(img);
            Pen pen_green = new Pen(Color.Green, 3);
            Pen pen_red = new Pen(Color.Red, 3);
            switch (cmbDrawing.Text)
            {
                case "Ellipse":
                    g.DrawEllipse(pen_green, mi_mouse_x1, mi_mouse_y1, width, height);
                    break;
                case "Rectangle":
                    g.DrawRectangle(pen_red, mi_mouse_x1, mi_mouse_y1, width, height);
                    break;
                default:                    
                    break;
            }
            pen_green.Dispose();
            pen_red.Dispose();
            g.Dispose();
            picDrawing.Image = img;
            mb_Drawing = false;
        }

        private void picDrawing_MouseMove(object sender, EventArgs e)
        {
            if ((cmbDrawing.Text == "Bubbles") && (mb_Drawing == true))
            {
                System.Random r = new System.Random();
                System.Drawing.Point sp = System.Windows.Forms.Cursor.Position;
                System.Drawing.Point cp = picDrawing.PointToClient(sp);
                int li_mouse_x = cp.X;
                int li_mouse_y = cp.Y;
                Bitmap img = new Bitmap(picDrawing.Image);
                Graphics g = Graphics.FromImage(img);
                Pen pen_blue = new Pen(Color.Blue, 2);
                for ( int i = 1; i< 2; i++) {
                    int wh = 8 + r.Next(5);
                    int wdf = r.Next(-3, 4);
                    int hdf = r.Next(-3, 4);
                    g.DrawEllipse(pen_blue, li_mouse_x - wh / 2 + wdf, li_mouse_y - wh / 2 + hdf, wh, wh);
                }
                pen_blue.Dispose();
                g.Dispose();
                picDrawing.Image = img;
            }
        }

        private void cmbOpacity_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch ( btnStart.Enabled)
            {
                case false:
                    this.Opacity = Single.Parse(cmbOpacity.Text);
                    break;
                default:
                    this.Opacity = Single.Parse(cmbOpacity.Text);
                    System.Threading.Thread.Sleep(500);
                    this.Opacity = 1;
                    break;
            }
        }

        private void GEBICMN00_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            switch (e.KeyCode) {
                case Keys.Escape:
                    if (btnStart.Enabled == false)
                    {
                        M0_btnStop_Click();
                    }
                    break;
                case Keys.F1:
                    if (ModifierKeys.HasFlag(Keys.Control))
                    {
                        if (btnStart.Enabled == true)
                        {
                            M0_btnStart_Click();
                        }
                    }
                    break;
                case Keys.Z:
                    if (ModifierKeys.HasFlag(Keys.Control))
                    {
                        if (btnUndo.Enabled == true)
                        {
                            M0_btnUndo_Click();
                        }
                    }
                    break;
                default:
                    break;
            }
        }

        private void GEBICMN00_Load(object sender, EventArgs e)
        {
            M0_Initialize_Form();
        }

        private void GEBICMN00_FormClosing(object sender, EventArgs e)
        {
            Properties.Settings.Default.WindowState = this.WindowState;
            Properties.Settings.Default.ApplicationTop = this.Top;
            Properties.Settings.Default.ApplicationLeft = this.Left;
            Properties.Settings.Default.ApplicationWidth = this.Width; 
            Properties.Settings.Default.ApplicationHeight = this.Height;
            Properties.Settings.Default.Folder = txtFolder.Text;
            Properties.Settings.Default.Prefix = txtPrefix.Text;
            Properties.Settings.Default.Seconds = numSeconds.Value;
            Properties.Settings.Default.Cursor = chkCursor.Checked;
            Properties.Settings.Default.Opacity = cmbOpacity.SelectedIndex;
            Properties.Settings.Default.ImageDate = chkCursor.Checked;
            Properties.Settings.Default.Extension = cmbExt.SelectedIndex;
            Properties.Settings.Default.Save();
        }

        private void M0_Initialize_Form()
        {
            if (Properties.Settings.Default.WindowState == FormWindowState.Minimized)
            {
                this.WindowState = FormWindowState.Normal;
                this.Top = 100;
                this.Left = 100;
                this.Width = 640;
                this.Height = 155;
            }
            else
            { 
                this.WindowState = Properties.Settings.Default.WindowState;
                this.Top = Properties.Settings.Default.ApplicationTop;
                this.Left = Properties.Settings.Default.ApplicationLeft;
                this.Width = Properties.Settings.Default.ApplicationWidth;
                this.Height = Properties.Settings.Default.ApplicationHeight;
            }
            txtFolder.Text = Properties.Settings.Default.Folder;
            txtPrefix.Text = Properties.Settings.Default.Prefix;
            numSeconds.Value = Properties.Settings.Default.Seconds;
            chkCursor.Checked = Properties.Settings.Default.Cursor;
            btnStop.Enabled = false;
            btnStop.Visible = false;
            btnUndo.Enabled = false;
            btnUndo.Visible = false;
            this.KeyPreview = true;
            mo_tooltip = new ToolTip(this.components);
            mo_tooltip.InitialDelay = 300;
            mo_tooltip.ReshowDelay = 300;
            mo_tooltip.AutoPopDelay = 5000;
            mo_tooltip.ShowAlways = true;
            mo_tooltip.SetToolTip(txtFolder, "Output Folder");
            mo_tooltip.SetToolTip(btnFolder, "Open Folder Dialog");
            mo_tooltip.SetToolTip(txtPrefix, "File Name Prefix");
            mo_tooltip.SetToolTip(numSeconds, "Timer Tick Seconds");
            mo_tooltip.SetToolTip(btnStart, "Start Timer");
            mo_tooltip.SetToolTip(btnStop, "Stop Timer");
            mo_tooltip.SetToolTip(btnQuit, "Quit Application");
            mo_tooltip.SetToolTip(btnUndo, "Undo Last Drawing");
            mo_tooltip.SetToolTip(btnClear, "Clear Drawing Canvas");
            mo_tooltip.SetToolTip(chkCursor, "Include Mouse Cursor to the Screen Shot");
            mo_tooltip.SetToolTip(cmbDrawing, "Drawing - You can Specify Important Points");
            mo_tooltip.SetToolTip(cmbOpacity, "Opacity - This parameter is used during Timer Working.");
            mo_tooltip.SetToolTip(cmbBackColor, "BackColor - It is Random. But you can change it anytime.");
            picDrawing.Width = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Width;
            picDrawing.Height = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Height;
            picDrawing.Image = new Bitmap(picDrawing.Width, picDrawing.Height);
            cmbDrawing.Items.Clear();
            cmbDrawing.Items.Add("None");
            cmbDrawing.Items.Add("Rectangle");
            cmbDrawing.Items.Add("Ellipse");
            cmbDrawing.Items.Add("Bubbles");
            cmbDrawing.SelectedIndex = 0;
            cmbOpacity.Items.Clear();
            cmbOpacity.Items.Add("0.1");
            cmbOpacity.Items.Add("0.2");
            cmbOpacity.Items.Add("0.3");
            cmbOpacity.Items.Add("0.4");
            cmbOpacity.Items.Add("0.5");
            cmbOpacity.Items.Add("0.6");
            cmbOpacity.Items.Add("0.7");
            cmbOpacity.Items.Add("0.8");
            cmbOpacity.Items.Add("0.9");
            cmbOpacity.Items.Add("1.0");
            cmbOpacity.SelectedIndex = Properties.Settings.Default.Opacity;
            cmbExt.Items.Clear();
            cmbExt.Items.Add(".jpg");
            cmbExt.Items.Add(".png");
            cmbExt.SelectedIndex = Properties.Settings.Default.Extension;
            chkImgDate.Checked = Properties.Settings.Default.ImageDate;
            cmbBackColor.Items.Clear();
            foreach (string name in Enum.GetNames(typeof(KnownColor)))
            {
                if ((ColorTranslator.FromHtml(name).GetBrightness() >= 0.85) && 
                         (ColorTranslator.FromHtml(name).GetBrightness() <= 0.98) )
                {
                    cmbBackColor.Items.Add(name);
                }                
            }
            System.Random r = new System.Random();
            cmbBackColor.SelectedIndex = r.Next(cmbBackColor.Items.Count);
            mo_undo_image = picDrawing.Image;
        }

        private void M0_btnStart_Click()
        {
            txtFolder.Enabled = false;
            txtPrefix.Enabled = false;
            btnFolder.Enabled = false;
            btnFolder.Visible = false;
            btnStart.Enabled = false;
            btnStart.Visible = false;
            btnStop.Enabled = true;
            btnStop.Visible = true;
            timTick.Interval = (int)numSeconds.Value * 1000;
            timTick.Start();
            timTeaBreak.Interval = (int)numSeconds.Value * 60000;
            timTeaBreak.Start();
            this.Opacity = Single.Parse(cmbOpacity.Text);
            AutoClosingMessageBox.Show("Auto Screen Shot is started.", "Notice", 1500);
        }

        private void M0_btnStop_Click()
        {
            timTick.Stop();
            txtFolder.Enabled = true;
            txtPrefix.Enabled = true;
            btnFolder.Enabled = true;
            btnFolder.Visible = true;
            btnStart.Enabled = true;
            btnStart.Visible = true;
            btnStop.Enabled = false;
            btnStop.Visible = false;
            this.Opacity = 1;
            AutoClosingMessageBox.Show("Auto Screen Shot is stopped.", "Notice", 1500);
        }

        private void M0_btnQuit_Click()
        {
            this.Close();
        }

        private void M0_btnFolder_Click()
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            fbd.Description = "Select Folder";
            fbd.RootFolder = Environment.SpecialFolder.Desktop;
            fbd.SelectedPath = @"C:\";
            fbd.ShowNewFolderButton = true;
            if (fbd.ShowDialog(this) == DialogResult.OK)
            {
                txtFolder.Text = fbd.SelectedPath;
            }
        }

        private void M0_btnClear_Click()
        {
            DialogResult result = MessageBox.Show("Are you sure you want to clear canvas ?",
                "Confirmation", MessageBoxButtons.OKCancel);
            if (result == DialogResult.OK)
            {
                mo_undo_image = picDrawing.Image;
                picDrawing.Image = new Bitmap(picDrawing.Width, picDrawing.Height);
                btnUndo.Enabled = false;
                btnUndo.Visible = false;
            }
        }

        private void M0_btnUndo_Click()
        {
            picDrawing.Image = mo_undo_image;
            btnUndo.Enabled = false;
            btnUndo.Visible = false;
        }

        private void M0_btnHTML_Click()
        {
            string ls_folder = txtFolder.Text;
            string ls_prefix = txtPrefix.Text;
            string ls_html_path = System.IO.Path.Combine(ls_folder, ls_prefix + ".html");
            AutoClosingMessageBox.Show("[" + ls_html_path + "] will be created.", "Notice", 2000);
            M1_Make_HTML(ls_folder, ls_prefix, ls_html_path);
        }

        private void M1_Make_HTML(string ps_folder, string ps_prefix, string ps_html)
        {
            string[] ls_files = System.IO.Directory.GetFiles(ps_folder, "*.jpg", System.IO.SearchOption.TopDirectoryOnly);
            string ls_file;
            string ls_line;
            string ls_header = "<HTML><HEAD><TITLE>" + ps_prefix + "</TITLE></HEAD><BODY><CENTER>";
            string ls_footer= "</CENTER></BODY></HTML>";
            System.IO.StreamWriter sw = new System.IO.StreamWriter(ps_html, false, System.Text.Encoding.GetEncoding("shift_jis"));
            sw.WriteLine(ls_header);
            for (int i = 0; i < ls_files.Count(); i++)
            {
                ls_file = System.IO.Path.GetFileName(ls_files[i]);
                ls_line = "<A HREF=\"" + ls_file + "\" TARGET=\"_blank\">";
                sw.WriteLine(ls_line);
                ls_line = "<IMG SRC=\"" + ls_file + "\" WIDTH=\"80%\" BORDER=\"0\" /><BR>";
                sw.WriteLine(ls_line);
                ls_line = ls_file + "</A><BR><BR><BR>";
                sw.WriteLine(ls_line);
            }
            sw.WriteLine(ls_footer);
            sw.Close();
        }

        private void M0_Form_SizeChanged()
        {

        }

        private void M0_timTick_Tick()
        {
            string ls_folder = txtFolder.Text;
            string ls_prefix = txtPrefix.Text;
            M1_Get_Screen(ls_folder, ls_prefix);
            System.GC.Collect();
        }

        private void M0_timTeaBreak_Tick()
        {
            AutoClosingMessageBox.Show("Please take a tea break.", "Advice", 10000);
        }

        private void M1_Get_Screen(string ps_folder, string ps_prefix)
        {
            string ls_datetime = DateTime.Now.ToString("yyyyMMdd_HHmmss");
            string ls_ext = cmbExt.Text;
            string ls_filepath = System.IO.Path.Combine(ps_folder, ps_prefix + "_" + ls_datetime + ls_ext);
            if (ls_datetime != ms_previous_datetime)
            {
                Bitmap lo_bmp = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);
                Graphics g = Graphics.FromImage(lo_bmp);
                g.CopyFromScreen(new Point(0, 0), new Point(0, 0), lo_bmp.Size);
                if (chkCursor.Checked == true)
                {
                    M2_Draw_Cursor(lo_bmp, g);
                }
                if (mo_previous_image != null && lo_bmp.ImageComp(mo_previous_image))
                {
                    M2_Make_Same_Message(ls_filepath);
                }
                else
                {
                    mo_previous_image = (Bitmap)lo_bmp.Clone();
                    if (chkImgDate.Checked == true)
                    {
                        M2_Draw_ImageDate(lo_bmp, g, ls_datetime);
                    }
                    M2_Make_Screen_Shot(lo_bmp, ls_filepath, ls_datetime);
                }
                g.Dispose();
            }
        }

        private void M2_Draw_Cursor(Bitmap po_bmp, Graphics po_g)
        {
            Point curPoint = Cursor.Position;
            Point hotSpot = this.Cursor.HotSpot;
            Point position = new Point((curPoint.X - hotSpot.X), (curPoint.Y - hotSpot.Y));
            Cursor.Current.Draw(po_g, new Rectangle(position, this.Cursor.Size));
        }

        private void M2_Draw_ImageDate(Bitmap po_bmp, Graphics po_g, String ps_string)
        {
            Rectangle rect = new Rectangle(0, 0, 160, 20);
            Brush b = new SolidBrush(this.BackColor);
            po_g.FillRectangle(b, rect);
            Font fnt = new Font("Arial", 9);
            po_g.DrawString( ps_string, fnt, Brushes.Black, 10, 0);
            fnt.Dispose();
        }

        private void M2_Make_Screen_Shot(Bitmap po_bmp, string ps_filepath, string ps_datetime)
        {
            M3_Make_Screen_Shot_Save_and_Move(po_bmp, ps_filepath);
            ms_previous_datetime = ps_datetime;
        }

        private void M3_Make_Screen_Shot_Save_and_Move(Bitmap po_bmp, string ps_filepath)
        {
            string ls_tmp = System.IO.Path.GetTempFileName();
            switch (cmbExt.Text)
            {
                case ".png":
                    po_bmp.Save(ls_tmp, System.Drawing.Imaging.ImageFormat.Png);
                    break;
                default:
                    po_bmp.Save(ls_tmp, System.Drawing.Imaging.ImageFormat.Jpeg);
                    break;
            }
            System.IO.File.Copy(ls_tmp, ps_filepath);
            System.IO.File.Delete(ls_tmp);
        }

        private void M3_Text()
        {
            Image img;
            using (Image imgSrc = Image.FromFile(@"C:\JPEG\test.bmp"))
            {
                img = new Bitmap(imgSrc);
            }
            using (img)
            {
                img.Save(@"C:\JPEG\test.bmp", ImageFormat.Bmp); //OK
            }
        }

private void cmbBackColor_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.BackColor = ColorTranslator.FromHtml(cmbBackColor.Text);
        }

        private void numSeconds_ValueChanged(object sender, EventArgs e)
        {
            timTick.Interval = (int)numSeconds.Value * 1000;
        }



        private void M2_Make_Same_Message(string ps_filepath)
        {
            Bitmap canvas = new Bitmap(220, 20);
            Graphics g = Graphics.FromImage(canvas);
            Rectangle rect = new Rectangle(0, 0, canvas.Width, canvas.Height);
            Brush b = new SolidBrush(this.BackColor);
            g.FillRectangle(b, rect);
            Font fnt = new Font("Arial", 9);
            g.DrawString("Same as " + ms_previous_datetime, fnt, Brushes.Black, 10, 0);
            fnt.Dispose();
            g.Dispose();
            canvas.Save(ps_filepath, System.Drawing.Imaging.ImageFormat.Jpeg);
        }

        static void Swap<T>(ref T lhs, ref T rhs)
        {
            T temp;
            temp = lhs;
            lhs = rhs;
            rhs = temp;
        }
    }

    public static class ImageEx
    {
        /// <summary>  
        /// 画像を高速に比較します。  
        /// </summary>  
        /// <param name="image2">比較する画像  
        /// <returns></returns>  
        static public bool ImageComp(this Image image1, Image image2)
        {
            Bitmap img1 = (Bitmap)image1;
            Bitmap img2 = (Bitmap)image2;
            //if (img1.Width != img2.Width || img1.Height != img2.Height) return false;
            BitmapData bd1 = img1.LockBits(new Rectangle(0, 0, img1.Width, img1.Height), System.Drawing.Imaging.ImageLockMode.ReadOnly, img1.PixelFormat);
            BitmapData bd2 = img2.LockBits(new Rectangle(0, 0, img2.Width, img2.Height), System.Drawing.Imaging.ImageLockMode.ReadOnly, img2.PixelFormat);
            //if ((bd1.Stride * img1.Height) != (bd2.Stride * img2.Height)) return false;
            int bsize = bd1.Stride * img1.Height;
            byte[] byte1 = new byte[bsize];
            byte[] byte2 = new byte[bsize];
            Marshal.Copy(bd1.Scan0, byte1, 0, bsize);
            Marshal.Copy(bd2.Scan0, byte2, 0, bsize);
            img1.UnlockBits(bd1);
            img2.UnlockBits(bd2);
            System.Security.Cryptography.MD5CryptoServiceProvider md5 =
                new System.Security.Cryptography.MD5CryptoServiceProvider();
            byte[] hash1 = md5.ComputeHash(byte1);
            byte[] hash2 = md5.ComputeHash(byte2);
            return hash1.SequenceEqual(hash2);
        }
    }

    public class AutoClosingMessageBox
    {
        int text_max_length = 200; //最大の文字列長の指定
        System.Threading.Timer _timeoutTimer;
        string _caption;

        AutoClosingMessageBox(string text, string caption, int timeout)
        {
            if (text.Length> text_max_length) //内容の長さを制限する追加部分
            {
                text = text.Substring(0, text_max_length);
            }
            //text = ( text.length > text_max_length ) ? text.Substring( 0, text_max_length ) : text; //三項目演算での記述方法　? の左側が true の時 : の左側が代入されます。 falseの時は右側
            _caption = caption;
            _timeoutTimer = new System.Threading.Timer(OnTimerElapsed, null, timeout, System.Threading.Timeout.Infinite);
            MessageBox.Show(text, caption);
        }

        public static void Show(string text, string caption, int timeout)
        {
            new AutoClosingMessageBox(text, caption, timeout);
        }

        void OnTimerElapsed(object state)
        {
            IntPtr mbWnd = FindWindow(null, _caption);
            if (mbWnd != IntPtr.Zero)
            {
                SendMessage(mbWnd, WM_CLOSE, IntPtr.Zero, IntPtr.Zero);
            }
            _timeoutTimer.Dispose();
        }

        const int WM_CLOSE = 0x0010;
        [System.Runtime.InteropServices.DllImport("user32.dll", SetLastError = true)]
        static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
        [System.Runtime.InteropServices.DllImport("user32.dll", CharSet = System.Runtime.InteropServices.CharSet.Auto)]
        static extern IntPtr SendMessage(IntPtr hWnd, UInt32 Msg, IntPtr wParam, IntPtr lParam);
    }


}
