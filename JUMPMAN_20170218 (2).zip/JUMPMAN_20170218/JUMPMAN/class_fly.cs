﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JUMPMAN
{
    class class_fly
    {
        int m_idx;
        double m_x0, m_y0;          // 現在の位置(x,y)
        double m_v0;                // 現在の速度
        double m_ux0, m_uy0;        // 進行方向を向く単位ベクトル(x,y)
        double m_x1, m_y1;          // 次ステップにおける位置(x,y) 
        double m_v1;                // 次ステップでの速度
        double m_ux1, m_uy1;        // 次ステップでの進行方向を向く単位ベクトル(x,y)
        double m_max_speed;         // 最大速度

        int m_max_fly;            // 系内の最大Fly数

        public class_fly(int idx, int max_fly)
        {
            m_idx = idx;
            m_max_fly = max_fly;
            m_max_speed = 3.0;     // 最大速度
        }

        public void init(int width, int height)
        {
            //初期位置と速度
            m_x0 = width * M3_GET_RANDOM_01();
            m_y0 = height * M3_GET_RANDOM_01();
            m_v0 = 0.0;
            m_ux0 = 10.0 * M3_GET_RANDOM_11();
            m_uy0 = 10.0 * M3_GET_RANDOM_11();
            //ここでの距離は厳密である必要がないためget_approx_distainceで近似する。
            //double rr = m_ux0 * m_ux0 + m_uy0 * m_uy0 + 0.01;
            //rr = Math.Sqrt(rr);
            double rr = get_approx_distance(m_ux0, m_uy0);
            m_ux0 = m_ux0 / rr;
            m_uy0 = m_uy0 / rr;
        }

        public void set_parameter(
            double max_speed     // 最大速度
            )
        {
            m_max_speed = max_speed;       // 最大速度
        }


        public void cal_next_position()
        {
            rule_alone();
        }

        protected void rule_alone()
        {
            // 速度決定
            m_v1 = (0.2 * M3_GET_RANDOM_01() + 0.8) * m_max_speed;
            // 方向決定
            double tvx = m_uy0;
            double tvy = -1.0 * m_ux0;
            double rr = 0.5 * M3_GET_RANDOM_11();
            m_ux1 = m_ux0 + tvx * rr;
            m_uy1 = m_uy0 + tvy * rr;
            //ここでの距離は厳密である必要がないためget_approx_distainceで近似する。
            //double r = m_ux1 * m_ux1 + m_uy1 * m_uy1 + 0.001;
            //r = Math.Sqrt(r);
            double r = get_approx_distance(m_ux1, m_uy1);
            m_ux1 = m_ux1 / r;
            m_uy1 = m_uy1 / r;
            // 次ステップにおける位置決定
            m_x1 = m_v1 * m_ux1 + m_x0;
            m_y1 = m_v1 * m_uy1 + m_y0;
        }

        public void move_to_next_position()
        {

            m_x0 = m_x1;      // 現在の位置(x)
            m_y0 = m_y1;      // 現在の位置(y)
            m_v0 = m_v1;      // 現在の速度
            m_ux0 = m_ux1;    // 進行方向を向く単位ベクトル X
            m_uy0 = m_uy1;    // 進行方向を向く単位ベクトル Y
        }

        public double get_x() { return (m_x0); }
        public double get_y() { return (m_y0); }
        public double get_vx() { return (m_ux0); }
        public double get_vy() { return (m_uy0); }

        public double get_approx_distance(double dx, double dy)
        {
            double approx;
            if (dx < 0) { dx = -dx; }
            if (dy < 0) { dy = -dy; }
            if (dx < dy)
            {
                approx = dy + 0.375 * dx;
                //approx = dy + ((int)dx >> 2) + ((int)dx >> 3);
            }
            else
            {
                approx = dx + 0.375 * dy;
                //approx = dx + ((int)dy >> 2) + ((int)dy >> 3);
            }
            return approx;
        }

        public int M3_GET_RANDOM(int nm)
        {
            byte[] bs = new byte[sizeof(int)];
            System.Security.Cryptography.RNGCryptoServiceProvider rng =
                new System.Security.Cryptography.RNGCryptoServiceProvider();
            rng.GetBytes(bs);
            //Int32に変換してnm未満の整数を返却する
            int i = System.BitConverter.ToInt32(bs, 0);
            return (Math.Abs(i % nm));
        }

        public double M3_GET_RANDOM_01()
        {
            //double r = new System.Random().Next(100);
            double r = M3_GET_RANDOM(100);
            return (double)r / 100;
        }

        public double M3_GET_RANDOM_11()
        {
            double ret = 1.0 - 2.0 * M3_GET_RANDOM_01();
            return ret;
        }


    }
}
