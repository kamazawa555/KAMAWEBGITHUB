﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JUMPMAN
{
    public partial class GGJMMN00 : Form
    {
        public GGJMMN00()
        {
            InitializeComponent();
        }

        private void cmdJUMPMAN1_Click(object sender, EventArgs e)
        {
            GGJMPL10 form = new GGJMPL10();
            form.ShowDialog();
            this.Close();
        }

        private void cmdJUMPMAN2_Click(object sender, EventArgs e)
        {
            GGJMPL20 form = new GGJMPL20();
            form.ShowDialog();
            this.Close();
        }

        private void cmdJUMPMAN3_Click(object sender, EventArgs e)
        {
            GGJMPL30 form = new GGJMPL30();
            form.ShowDialog();
            this.Close();
        }

        private void cmdFLY_Click(object sender, EventArgs e)
        {
            GGFLPL10 form = new GGFLPL10();
            form.ShowDialog();
            this.Close();
        }

        private void cmdFISH_Click(object sender, EventArgs e)
        {
            GGFSPL10 form = new GGFSPL10();
            form.ShowDialog();
            this.Close();
        }

        private void cmdJUMPSBC_Click(object sender, EventArgs e)
        {
            GGJMPL11 form = new GGJMPL11();
            form.ShowDialog();
            this.Close();
        }

        private void cmdESELIV_Click(object sender, EventArgs e)
        {
            GGESPL10 form = new GGESPL10();
            form.ShowDialog();
            this.Close();
        }
    }
}
