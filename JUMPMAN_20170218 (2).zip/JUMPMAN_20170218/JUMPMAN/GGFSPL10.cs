﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JUMPMAN
{
    public partial class GGFSPL10 : Form
    {
        //変数
        Timer mo_Timer = new System.Windows.Forms.Timer();
        Bitmap mo_double_buffer;
        Graphics mo_dg;
        Boolean mb_now_doing;
        int mi_INTERVAL = 20;
        const int CMI_MAXFISH = 200;
        double md_KAMA_EFFECT = 0.50;
        double md_KAMA_EFFECT_diff = 0.01;

        private class_fish[] m_fish;

        int mi_cron;
        int mi_clicked;
        float mf_frame_rate;

        int mi_tms1;
        int mi_tms2;

        int mi_mode;
        const int CMI_MODE_LOAD = 0;
        const int CMI_MODE_TITLE = 1;
        const int CMI_MODE_GAME = 2;
        const int CMI_MODE_GAMEOVER = 3;

        int mi_WIDTH = 640;
        int mi_HEIGHT = 480;
        Boolean mb_GAMEOVER_JUSTNOW;

        int[] m_fish_x;         // 描画用座標
        int[] m_fish_y;         // 描画用座標
        double[] m_fish_vx;     // 描画用速度
        double[] m_fish_vy;     // 描画用速度
        double[] m_fish_prevx;  // 描画用速度（前回）
        double[] m_fish_prevy;  // 描画用速度（前回）

        public GGFSPL10()
        {
            InitializeComponent();
            M0_FORM_LOAD();
        }

        protected void M0_FORM_LOAD()
        {
            mi_WIDTH = picDRAW.Width;
            mi_HEIGHT = picDRAW.Height;
            mo_double_buffer = new Bitmap(mi_WIDTH, mi_HEIGHT);
            mo_dg = Graphics.FromImage(mo_double_buffer);
            M1_LOAD();
            this.Refresh();
        }

        protected void TimerEventProcessor(object sender, EventArgs e)
        {
            this.M1_SET_INTERVAL();
            this.M1_DO_IT();
            this.M1_PAINT();
        }

        protected void M1_SET_INTERVAL()
        {
            if (mi_mode == CMI_MODE_GAME)
            {
                mi_cron++;
                if (mi_cron >= 500)
                {
                    mi_tms2 = System.Environment.TickCount & int.MaxValue;
                    mf_frame_rate = (float)(mi_cron) / (float)(mi_tms2 - mi_tms1) * 1000;
                    if (mf_frame_rate < 20)
                    {
                        mi_INTERVAL = mi_INTERVAL - 2;
                        if (mi_INTERVAL < 0) { mi_INTERVAL = 0; }
                    }
                    else if (mf_frame_rate < 25)
                    {
                        mi_INTERVAL = mi_INTERVAL - 1;
                        if (mi_INTERVAL < 0) { mi_INTERVAL = 0; }
                    }
                    else if (mf_frame_rate >= 40)
                    {
                        mi_INTERVAL = mi_INTERVAL + 2;
                    }
                    else if (mf_frame_rate >= 35)
                    {
                        mi_INTERVAL = mi_INTERVAL + 1;
                    }
                    mi_cron = 0;
                    mi_tms1 = System.Environment.TickCount & int.MaxValue;
                }
            }
        }

        protected void M1_DO_IT()
        {
            if (mb_now_doing == true) { return; }
            mb_now_doing = true;
            if (mi_mode == CMI_MODE_LOAD) { mi_mode = CMI_MODE_TITLE; }
            else if (mi_mode == CMI_MODE_TITLE) { M1_TITLE(); }
            else if (mi_mode == CMI_MODE_GAMEOVER) { M1_GAME_OVER(); }
            else if (mi_mode == CMI_MODE_GAME)
            {
                //Clear Screen
                mo_dg.FillRectangle(Brushes.Navy, 0, 0, mi_WIDTH, mi_HEIGHT);
                M2_CALC_NEXT_POSITION();    // 次ステップの位置を計算
                M2_MOVE_TO_NEXT_POSITION(); // 次ステップの位置へ移動               
                M2_DRAW_FISH();             // 描画
            }
            mb_now_doing = false;
        }

        protected void M2_CALC_NEXT_POSITION()
        {
            int neighborhood = -1;
            for (int i = 0; i < CMI_MAXFISH; i++)
            {
                // 近くの魚を取得する
                neighborhood = m_fish[i].get_neighborhood();
                if (neighborhood < 0)
                { 
                    // 近くに魚がいなければ
                    m_fish[i].cal_next_position();
                }
                else if (neighborhood >= 0)
                {
                    // 近くに魚がいれば
                    m_fish[i].cal_next_position(neighborhood, m_fish[neighborhood]);
                }
            }
        }

        protected void M2_MOVE_TO_NEXT_POSITION()
        {
            for (int i = 0; i < CMI_MAXFISH; i++)
            {
                m_fish[i].move_to_next_position();
            }
            for (int i = 0; i < CMI_MAXFISH; i++)
            {
                for (int j = 0; j < CMI_MAXFISH; j++)
                {
                    if (j != i)
                    {
                        m_fish[i].set_relative_position(j, m_fish[j]);
                    }
                }
                m_fish[i].cal_relative_position();
            }
        }

        public void M3_SET_DRAW_POSITION( int idx, double x, double y, double vx, double vy)
        {
            int xx = (int)x;
            int yy = (int)y;

            // 位置補正
            if (xx > mi_WIDTH)
            {
                int nx = xx / mi_WIDTH;
                xx -= mi_WIDTH * nx;
            }
            else if (xx < 0)
            {
                int nx = xx / mi_WIDTH - 1;
                xx -= mi_WIDTH * nx;
            }
            if (yy > mi_HEIGHT)
            {
                int ny = yy / mi_HEIGHT;
                yy -= mi_HEIGHT * ny;
            }
            else if (yy < 0)
            {
                int ny = yy / mi_HEIGHT - 1;
                yy -= mi_HEIGHT * ny;
            }
            m_fish_x[idx] = xx;
            m_fish_y[idx] = yy;
            m_fish_prevx[idx] = m_fish_vx[idx];
            m_fish_prevy[idx] = m_fish_vy[idx];
            m_fish_vx[idx] = vx;
            m_fish_vy[idx] = vy;
        }


        protected void M2_DRAW_FISH()
        {
            int gx1, gx2, gx3;
            int gy1, gy2, gy3;
            double length = 5.0;
            Pen fishpen = Pens.LightSkyBlue;
            //描画用座標の設定
            for (int i = 0; i < CMI_MAXFISH; i++)
            {
                M3_SET_DRAW_POSITION(i, m_fish[i].get_x(), m_fish[i].get_y(), m_fish[i].get_vx(), m_fish[i].get_vy());
            }
            //描画
            for (int i = 0; i < CMI_MAXFISH; i++)
            {
                length = m_fish[i].get_length();
                double tvx = m_fish_vx[i];
                double tvy = -1.0 * m_fish_vy[i];
                gx1 = (int)m_fish_x[i];
                gy1 = (int)m_fish_y[i];
                gx2 = (int)(-length * m_fish_vx[i]) + gx1;
                gy2 = (int)(-length * m_fish_vy[i]) + gy1;
                if ( gx2 > 0 && gy2 > 0 )
                {
                    mo_dg.DrawLine(fishpen, gx1, gy1, gx2, gy2);
                    gx3 = gx2 - (int)(0.3 * length * m_fish_prevx[i]);
                    gy3 = gy2 - (int)(0.3 * length * m_fish_prevy[i]);
                    if ( gx3 > 0 && gy3 > 0 )
                    {
                        mo_dg.DrawLine(fishpen, gx2, gy2, gx3, gy3);
                    }
                }

            }
        }

        protected void M1_PAINT()
        {
            picDRAW.Image = mo_double_buffer;
        }

        protected void M1_LOAD()
        {
            mo_dg.FillRectangle(Brushes.Black, mo_dg.VisibleClipBounds);
            Font fnt = new Font("Sans", 11);
            mo_dg.DrawString("Now Loading...", fnt, Brushes.White, 110, mi_HEIGHT / 2);
            this.picDRAW.MouseUp += new System.Windows.Forms.MouseEventHandler(this.picDRAW_MouseUp);
            this.picDRAW.MouseDown += new System.Windows.Forms.MouseEventHandler(this.picDRAW_MouseDown);
            this.picDRAW.MouseMove += new System.Windows.Forms.MouseEventHandler(this.picDRAW_MouseMove);
            m_fish = new class_fish[CMI_MAXFISH];
            m_fish_x = new int[CMI_MAXFISH];
            m_fish_y = new int[CMI_MAXFISH];
            m_fish_vx= new double[CMI_MAXFISH];
            m_fish_vy = new double[CMI_MAXFISH];
            m_fish_prevx = new double[CMI_MAXFISH];
            m_fish_prevy = new double[CMI_MAXFISH];
            mo_Timer.Tick += new EventHandler(this.TimerEventProcessor);
            mo_Timer.Interval = mi_INTERVAL;
            mo_Timer.Start();
            mi_mode = CMI_MODE_LOAD;
        }

        protected void M1_TITLE()
        {
            if (mo_dg == null)
            {
                //SKIP
            }
            else
            {
                int left = 360;
                mo_dg.FillRectangle(Brushes.Navy, mo_dg.VisibleClipBounds);
                Font f1 = new Font("Dialog", 12);
                mo_dg.DrawString("2015  KAMA Presents", f1, Brushes.White, left + 60, 130);
                Font f2 = new Font("Dialog", 80);
                mo_dg.DrawString("FISH", f2, Brushes.White, left, 170);
                Font f3 = new Font("Dialog", 16);
                mo_dg.DrawString("FISH COUNT : " + CMI_MAXFISH.ToString(), f3, Brushes.White, left + 40, mi_HEIGHT / 2 + 50);
                md_KAMA_EFFECT = md_KAMA_EFFECT + md_KAMA_EFFECT_diff;
                if (md_KAMA_EFFECT > 1.00 || md_KAMA_EFFECT < 0.10 ) {
                    md_KAMA_EFFECT_diff = -md_KAMA_EFFECT_diff;
                }
                mo_dg.DrawString("KAMA EFFECT :" + md_KAMA_EFFECT.ToString("F2"), f3, Brushes.White, left + 40, mi_HEIGHT / 2 + 80);
                mo_dg.DrawString("INTERVAL : " + mi_INTERVAL.ToString(), f3, Brushes.White, left + 40, mi_HEIGHT / 2 + 110);
                Font f4 = new Font("Dialog", 20);
                mo_dg.DrawString("Mouse Click to Start", f4, Brushes.White, left + 15, mi_HEIGHT - 100);
                mo_dg.DrawString("If Swiming, 5 times Click to End", f4, Brushes.White, left - 50, mi_HEIGHT - 70);
            }
        }

        protected void M1_GAME_OVER()
        {
            if (mb_GAMEOVER_JUSTNOW == false)
            {
                mb_GAMEOVER_JUSTNOW = true;
                System.Threading.Thread.Sleep(1000);
            }
            int left = 360;
            mo_dg.FillRectangle(Brushes.Navy, mo_dg.VisibleClipBounds);
            Font f1 = new Font("Dialog", 22);
            mo_dg.DrawString("End. 5 times Clicked.", f1, Brushes.White, left, mi_HEIGHT / 2 - 50);
            Font f3 = new Font("Dialog", 16);
            mo_dg.DrawString("FISH COUNT : " + CMI_MAXFISH.ToString(), f3, Brushes.White, left + 40, mi_HEIGHT / 2 + 50);
            mo_dg.DrawString("KAMA EFFECT :" + md_KAMA_EFFECT.ToString("F2"), f3, Brushes.White, left + 40, mi_HEIGHT / 2 + 80);
            mo_dg.DrawString("INTERVAL : " + mi_INTERVAL.ToString(), f3, Brushes.White, left + 40, mi_HEIGHT / 2 + 110);
            Font f4 = new Font("Dialog", 12);
            if ( mf_frame_rate == 0 || mf_frame_rate >= 100 )
            {
                mo_dg.DrawString("Frame rate is not calculated.", f4, Brushes.White, 10, mi_HEIGHT - 20);
            }
            else
            {
                mo_dg.DrawString(mf_frame_rate.ToString() + " Frames/Sec", f4, Brushes.White, 10, mi_HEIGHT - 20);
            }
        }

        protected void M2_PUT_FISH()
        {

        }

        protected void picDRAW_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (mi_mode == CMI_MODE_TITLE)
            {
                mo_dg.FillRectangle(Brushes.Navy, mo_dg.VisibleClipBounds);
                Font f3 = new Font("Dialog", 16);
                int left = 360;
                mo_dg.DrawString("FISH COUNT : " + CMI_MAXFISH.ToString(), f3, Brushes.White, left + 40, mi_HEIGHT / 2 + 50);
                mo_dg.DrawString("KAMA EFFECT :" + md_KAMA_EFFECT.ToString("F2"), f3, Brushes.White, left + 40, mi_HEIGHT / 2 + 80);
                mo_dg.DrawString("INTERVAL : " + mi_INTERVAL.ToString(), f3, Brushes.White, left + 40, mi_HEIGHT / 2 + 110);
                System.Threading.Thread.Sleep(1000);
                mi_mode = CMI_MODE_GAME;
                mi_clicked = 0;
                mi_tms1 = System.Environment.TickCount & int.MaxValue;
                mb_GAMEOVER_JUSTNOW = false;
                //
                for (int i = 0; i < CMI_MAXFISH; i++)
                {
                    m_fish[i] = new class_fish(i, CMI_MAXFISH, md_KAMA_EFFECT);
                    m_fish[i].init(mi_WIDTH, mi_HEIGHT);
                    m_fish_x[i] = 0;
                    m_fish_y[i] = 0;
                    m_fish_vx[i] = 0;
                    m_fish_vy[i] = 0;
                }
            }
            else if (mi_mode == CMI_MODE_GAMEOVER)
            {
                mi_mode = CMI_MODE_TITLE;
            }
            else if (mi_mode == CMI_MODE_GAME)
            {
                mi_clicked++;
                if (mi_clicked >= 5) {
                    mi_mode = CMI_MODE_GAMEOVER;
                }
            }
        }

        protected void picDRAW_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
        {

        }

        protected void picDRAW_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
        {

        }
    }
}
