﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JUMPMAN
{
    public partial class GGFLPL10 : Form
    {
        //変数
        Timer mo_Timer = new System.Windows.Forms.Timer();
        Bitmap mo_double_buffer;
        Graphics mo_dg;
        Boolean mb_now_doing;
        int mi_INTERVAL = 20;
        const int CMI_MAXFLY = 700;

        private class_fly[] m_fly;

        int mi_cron;
        int mi_clicked;
        float mf_frame_rate;

        int mi_tms1;
        int mi_tms2;

        int mi_mode;
        const int CMI_MODE_LOAD = 0;
        const int CMI_MODE_TITLE = 1;
        const int CMI_MODE_GAME = 2;
        const int CMI_MODE_GAMEOVER = 3;

        int mi_WIDTH = 640;
        int mi_HEIGHT = 480;
        Boolean mb_GAMEOVER_JUSTNOW;

        int[] m_fly_x;         // 描画用座標
        int[] m_fly_y;         // 描画用座標
        double[] m_fly_vx;     // 描画用速度
        double[] m_fly_vy;     // 描画用速度

        public GGFLPL10()
        {
            InitializeComponent();
            M0_FORM_LOAD();
        }

        protected void M0_FORM_LOAD()
        {
            mi_WIDTH = picDRAW.Width;
            mi_HEIGHT = picDRAW.Height;
            mo_double_buffer = new Bitmap(mi_WIDTH, mi_HEIGHT);
            mo_dg = Graphics.FromImage(mo_double_buffer);
            M1_LOAD();
            this.Refresh();
        }

        protected void TimerEventProcessor(object sender, EventArgs e)
        {
            this.M1_SET_INTERVAL();
            this.M1_DO_IT();
            this.M1_PAINT();
        }

        protected void M1_SET_INTERVAL()
        {
            if (mi_mode == CMI_MODE_GAME)
            {
                mi_cron++;
                if (mi_cron >= 500)
                {
                    mi_tms2 = System.Environment.TickCount & int.MaxValue;
                    mf_frame_rate = (float)(mi_cron) / (float)(mi_tms2 - mi_tms1) * 1000;
                    if (mf_frame_rate < 20)
                    {
                        mi_INTERVAL = mi_INTERVAL - 2;
                        if (mi_INTERVAL < 0) { mi_INTERVAL = 0; }
                    }
                    else if (mf_frame_rate < 25)
                    {
                        mi_INTERVAL = mi_INTERVAL - 1;
                        if (mi_INTERVAL < 0) { mi_INTERVAL = 0; }
                    }
                    else if (mf_frame_rate >= 40)
                    {
                        mi_INTERVAL = mi_INTERVAL + 2;
                    }
                    else if (mf_frame_rate >= 35)
                    {
                        mi_INTERVAL = mi_INTERVAL + 1;
                    }
                    mi_cron = 0;
                    mi_tms1 = System.Environment.TickCount & int.MaxValue;
                }
            }
        }

        protected void M1_DO_IT()
        {
            if (mb_now_doing == true) { return; }
            mb_now_doing = true;
            if (mi_mode == CMI_MODE_LOAD) { mi_mode = CMI_MODE_TITLE; }
            else if (mi_mode == CMI_MODE_TITLE) { M1_TITLE(); }
            else if (mi_mode == CMI_MODE_GAMEOVER) { M1_GAME_OVER(); }
            else if (mi_mode == CMI_MODE_GAME)
            {
                //Clear Screen
                mo_dg.FillRectangle(Brushes.SkyBlue, 0, 0, mi_WIDTH, mi_HEIGHT);
                M2_CALC_NEXT_POSITION();    // 次ステップの位置を計算
                M2_MOVE_TO_NEXT_POSITION(); // 次ステップの位置へ移動               
            }
            mb_now_doing = false;
        }

        protected void M2_CALC_NEXT_POSITION()
        {
            for (int i = 0; i < CMI_MAXFLY; i++)
            {
                m_fly[i].cal_next_position();
            }
        }

        protected void M2_MOVE_TO_NEXT_POSITION()
        {
            for (int i = 0; i < CMI_MAXFLY; i++)
            {
                m_fly[i].move_to_next_position();
            }
        }

        public void M3_SET_DRAW_POSITION(int idx, double x, double y, double vx, double vy)
        {
            int xx = (int)x;
            int yy = (int)y;

            // 位置補正
            if (xx > mi_WIDTH)
            {
                int nx = xx / mi_WIDTH;
                xx -= mi_WIDTH * nx;
            }
            else if (xx < 0)
            {
                int nx = xx / mi_WIDTH - 1;
                xx -= mi_WIDTH * nx;
            }
            if (yy > mi_HEIGHT)
            {
                int ny = yy / mi_HEIGHT;
                yy -= mi_HEIGHT * ny;
            }
            else if (yy < 0)
            {
                int ny = yy / mi_HEIGHT - 1;
                yy -= mi_HEIGHT * ny;
            }
            m_fly_x[idx] = xx;
            m_fly_y[idx] = yy;
            m_fly_vx[idx] = vx;
            m_fly_vy[idx] = vy;
        }

        protected void M1_PAINT()
        {
            picDRAW.Image = mo_double_buffer;
        }

        protected void M1_LOAD()
        {
            mo_dg.FillRectangle(Brushes.Black, mo_dg.VisibleClipBounds);
            Font fnt = new Font("Sans", 11);
            mo_dg.DrawString("Now Loading...", fnt, Brushes.Black, 110, mi_HEIGHT / 2);
            this.picDRAW.MouseDown += new System.Windows.Forms.MouseEventHandler(this.picDRAW_MouseDown);
            m_fly = new class_fly[CMI_MAXFLY];
            m_fly_x = new int[CMI_MAXFLY];
            m_fly_y = new int[CMI_MAXFLY];
            m_fly_vx = new double[CMI_MAXFLY];
            m_fly_vy = new double[CMI_MAXFLY];
            mo_Timer.Tick += new EventHandler(this.TimerEventProcessor);
            mo_Timer.Interval = mi_INTERVAL;
            mo_Timer.Start();
            mi_mode = CMI_MODE_LOAD;
        }

        protected void M1_TITLE()
        {
            if (mo_dg == null)
            {
                //SKIP
            }
            else
            {
                int left = 360;
                mo_dg.FillRectangle(Brushes.SkyBlue, mo_dg.VisibleClipBounds);
                Font f1 = new Font("Dialog", 12);
                mo_dg.DrawString("2015  KAMA Presents", f1, Brushes.Black, left + 60, 130);
                Font f2 = new Font("Dialog", 80);
                mo_dg.DrawString("FLY", f2, Brushes.Black, left + 20, 170);
                Font f3 = new Font("Dialog", 16);
                mo_dg.DrawString("FLY COUNT : " + CMI_MAXFLY.ToString(), f3, Brushes.Black, left + 40, mi_HEIGHT / 2 + 50);
                mo_dg.DrawString("INTERVAL : " + mi_INTERVAL.ToString(), f3, Brushes.Black, left + 40, mi_HEIGHT / 2 + 80);
                Font f4 = new Font("Dialog", 20);
                mo_dg.DrawString("Mouse Click to Start", f4, Brushes.Black, left + 15, mi_HEIGHT - 100);
                mo_dg.DrawString("If Flying, 5 times Click to End", f4, Brushes.Black, left - 50, mi_HEIGHT - 70);
            }
        }

        protected void M1_GAME_OVER()
        {
            if (mb_GAMEOVER_JUSTNOW == false)
            {
                mb_GAMEOVER_JUSTNOW = true;
                System.Threading.Thread.Sleep(1000);
            }
            int left = 360;
            mo_dg.FillRectangle(Brushes.SkyBlue, mo_dg.VisibleClipBounds);
            Font f1 = new Font("Dialog", 22);
            mo_dg.DrawString("End. 5 times Clicked.", f1, Brushes.Black, left, mi_HEIGHT / 2 - 50);
            Font f3 = new Font("Dialog", 16);
            mo_dg.DrawString("FLY COUNT : " + CMI_MAXFLY.ToString(), f3, Brushes.Black, left + 40, mi_HEIGHT / 2 + 50);
            mo_dg.DrawString("INTERVAL : " + mi_INTERVAL.ToString(), f3, Brushes.Black, left + 40, mi_HEIGHT / 2 + 80);
            Font f4 = new Font("Dialog", 12);
            if (mf_frame_rate == 0 || mf_frame_rate >= 100)
            {
                mo_dg.DrawString("Frame rate is not calculated.", f4, Brushes.Black, 10, mi_HEIGHT - 20);
            }
            else
            {
                mo_dg.DrawString(mf_frame_rate.ToString() + " Frames/Sec", f4, Brushes.Black, 10, mi_HEIGHT - 20);
            }
        }

        protected void picDRAW_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (mi_mode == CMI_MODE_TITLE)
            {
                mo_dg.FillRectangle(Brushes.SkyBlue, mo_dg.VisibleClipBounds);
                Font f3 = new Font("Dialog", 16);
                int left = 360;
                mo_dg.DrawString("FLY COUNT : " + CMI_MAXFLY.ToString(), f3, Brushes.Black, left + 40, mi_HEIGHT / 2 + 50);
                mo_dg.DrawString("INTERVAL : " + mi_INTERVAL.ToString(), f3, Brushes.Black, left + 40, mi_HEIGHT / 2 + 80);
                System.Threading.Thread.Sleep(1000);
                mi_mode = CMI_MODE_GAME;
                mi_clicked = 0;
                mi_tms1 = System.Environment.TickCount & int.MaxValue;
                mb_GAMEOVER_JUSTNOW = false;
                //
                for (int i = 0; i < CMI_MAXFLY; i++)
                {
                    m_fly[i] = new class_fly(i, CMI_MAXFLY);
                    m_fly[i].init(mi_WIDTH, mi_HEIGHT);
                    m_fly_x[i] = 0;
                    m_fly_y[i] = 0;
                    m_fly_vx[i] = 0;
                    m_fly_vy[i] = 0;
                }
            }
            else if (mi_mode == CMI_MODE_GAMEOVER)
            {
                mi_mode = CMI_MODE_TITLE;
            }
            else if (mi_mode == CMI_MODE_GAME)
            {
                mi_clicked++;
                if (mi_clicked >= 5)
                {
                    mi_mode = CMI_MODE_GAMEOVER;
                }
            }
        }
    }
}
