﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JUMPMAN
{
    public partial class GGJMPL20 : Form
    {
        //IMAGEファイルパス
        //String ms_IMAGE_FILEPATH = "C:\\DEVELOP\\IMAGE\\";
        String ms_IMAGE_FILEPATH = System.Windows.Forms.Application.StartupPath + "\\";

        //変数
        Timer mo_Timer = new System.Windows.Forms.Timer();
        Bitmap mo_double_buffer;
        Graphics mo_dg;
        Boolean mb_now_doing;

        int mi_INTERVAL = 20;
        const int CMI_MAXENEMY = 15;

        int mi_cron;
        int mi_wait;
        int mi_score;
        int mi_level;
        int mi_rate;
        float mf_frame_rate;
        int mi_gx;
        int mi_gy;
        int mi_dx;
        int mi_dy;
        int mi_dxd;
        int mi_mx;
        int mi_my;

        //Jump Man Status
        int mi_jpmn = 1;
        int mi_jpmnd = 0;
        int mi_jpms = 2;

        int mi_tms1;
        int mi_tms2;

        //Enemy status, coordinates
        int[] mi_es = new int[CMI_MAXENEMY];
        int[] mi_eg = new int[CMI_MAXENEMY];
        int[] mi_ex = new int[CMI_MAXENEMY];
        int[] mi_ey = new int[CMI_MAXENEMY];
        int[] mi_ez1 = new int[CMI_MAXENEMY];
        int[] mi_ez2 = new int[CMI_MAXENEMY];
        double[] mf_ed = new double[CMI_MAXENEMY];

        Image mo_ImgOfJumpmn;
        Image mo_ImgOfJumpm1a;
        Image mo_ImgOfJumpm1b;
        Image mo_ImgOfJumpm1c;
        Image mo_ImgOfJumpm2a;
        Image mo_ImgOfJumpm2b;
        Image mo_ImgOfJumpm3a;
        Image mo_ImgOfJumpm3b;
        Image mo_ImgOfJumpm4a;
        Image mo_ImgOfJumpm4b;
        Image mo_ImgOfJumpm5a;
        Image mo_ImgOfJumpm5b;
        Image mo_ImgOfFly1;
        Image mo_ImgOfFly2;
        Image mo_ImgOfTitle;
        private readonly dynamic _wmp1 = Activator.CreateInstance(Type.GetTypeFromProgID("WMPlayer.OCX.7"));
        private readonly dynamic _wmp2 = Activator.CreateInstance(Type.GetTypeFromProgID("WMPlayer.OCX.7"));

        int mi_mode;
        const int CMI_MODE_LOAD = 0;
        const int CMI_MODE_TITLE = 1;
        const int CMI_MODE_GAME = 2;
        const int CMI_MODE_GAMEOVER = 3;
        const int CMI_MODE_WAIT = 4;

        const int CMI_WIDTH = 320;
        const int CMI_HEIGHT = 240;
        Boolean mb_GAMEOVER_JUSTNOW;

        public GGJMPL20()
        {
            InitializeComponent();
            M0_FORM_LOAD();
        }

        public void M0_FORM_LOAD()
        {
            mo_double_buffer = new Bitmap(CMI_WIDTH, CMI_HEIGHT);
            mo_dg = Graphics.FromImage(mo_double_buffer);
            wbMANUAL.Url = new Uri(ms_IMAGE_FILEPATH + "JumpMan2.html");
            M1_LOAD();
            _wmp1.URL = ms_IMAGE_FILEPATH + "pyon2.wav";
            _wmp1.controls.play();
            _wmp2.URL = ms_IMAGE_FILEPATH + "bug.wav";
            _wmp2.controls.play();

            this.Refresh();
        }

        public void TimerEventProcessor(object sender, EventArgs e)
        {
            this.M1_SET_INTERVAL();
            this.M1_DO_IT();
            this.M1_PAINT();
        }

        public void M1_SET_INTERVAL()
        {
            if (mi_mode == CMI_MODE_GAME)
            {
                mi_cron++;
                if (mi_cron >= 500)
                {
                    mi_tms2 = System.Environment.TickCount & int.MaxValue;
                    mf_frame_rate = (float)(mi_cron) / (float)(mi_tms2 - mi_tms1) * 1000;
                    if (mf_frame_rate < 20)
                    {
                        mi_INTERVAL = mi_INTERVAL - 2;
                        if (mi_INTERVAL < 0) { mi_INTERVAL = 0; }
                    }
                    else if (mf_frame_rate < 25)
                    {
                        mi_INTERVAL = mi_INTERVAL - 1;
                        if (mi_INTERVAL < 0) { mi_INTERVAL = 0; }
                    }
                    else if (mf_frame_rate >= 40)
                    {
                        mi_INTERVAL = mi_INTERVAL + 2;
                    }
                    else if (mf_frame_rate >= 35)
                    {
                        mi_INTERVAL = mi_INTERVAL + 1;
                    }
                    mi_level++;
                    mi_cron = 0;
                    mi_tms1 = System.Environment.TickCount & int.MaxValue;
                }
            }
        }

        public void M1_DO_IT()
        {
            if (mb_now_doing == true) { return; }
            mb_now_doing = true;
            if (mi_mode == CMI_MODE_LOAD) { mi_mode = CMI_MODE_TITLE; }
            else if (mi_mode == CMI_MODE_TITLE) { M1_TITLE(); }
            else if (mi_mode == CMI_MODE_GAMEOVER) { M1_GAME_OVER(); }
            else if (mi_mode == CMI_MODE_GAME)
            {
                //Clear Screen
                mo_dg.FillRectangle(Brushes.Green, 0, CMI_HEIGHT - 16, CMI_WIDTH, 16);
                mo_dg.FillRectangle(Brushes.Gray, 0, 0, CMI_WIDTH, CMI_HEIGHT - 16);
                mo_dg.FillRectangle(Brushes.Black, 32, 0, CMI_WIDTH - 64, CMI_HEIGHT - 16);
                //Move Jumpman
                M2_MOVE_JUMPMAN();
                //Move Enemy 
                if ((mi_cron % mi_rate) == 0)
                {
                    int li_kazu = new System.Random().Next(255);
                    li_kazu = li_kazu % mi_level / 2;
                    for (int i = 0; i <= li_kazu; i++)
                    {
                        M2_PUT_ENEMY();
                    }
                }
                for (int i = 0; i < CMI_MAXENEMY; i++)
                {
                    if (mi_es[i] != 0)
                    {
                        switch (mi_es[i])
                        {
                            case 1:
                                mi_ey[i] = mi_ey[i] + 1;
                                break;
                            case 2:
                                mi_ey[i] = mi_ey[i] + 1;
                                mf_ed[i] = mf_ed[i] + (double)(0.1);
                                if (mf_ed[i] > Math.PI * 2) { mf_ed[i] = 0; }
                                mi_ex[i] = mi_ex[i] + (int)(Math.Cos(mf_ed[i]) * 4);
                                break;
                            case 3:
                                mi_ey[i] = mi_ey[i] + 1;
                                mi_ex[i] = mi_ex[i] + (int)(mf_ed[i]);
                                if (mi_ex[i] < 32)
                                {
                                    mi_ex[i] = 32;
                                    mf_ed[i] = -mf_ed[i];
                                }
                                else if (mi_ex[i] > (CMI_WIDTH - 64))
                                {
                                    mi_ex[i] = CMI_WIDTH - 64;
                                    mf_ed[i] = -mf_ed[i];
                                }
                                break;
                            case 4:
                                if (mi_ez2[i] >= 10)
                                {
                                    mi_ez2[i] = 0;
                                    if (mi_ez1[i] == 0)
                                    {
                                        mi_ez1[i] = 1;
                                    }
                                    else
                                    {
                                        mi_ez1[i] = 0;
                                    }
                                }
                                else
                                {
                                    mi_ez2[i] = mi_ez2[i] + 1;
                                }
                                switch (mi_ez1[i])
                                {
                                    case 0:
                                        mi_ey[i] = mi_ey[i] + 1;
                                        break;
                                    case 1:
                                        mi_ex[i] = mi_ex[i] + (int)(mf_ed[i] * 2);
                                        break;
                                }
                                if (mi_ex[i] < 32)
                                {
                                    mi_ex[i] = 32;
                                    mf_ed[i] = -mf_ed[i];
                                }
                                else if (mi_ex[i] > (CMI_WIDTH - 64))
                                {
                                    mi_ex[i] = (CMI_WIDTH - 64);
                                    mf_ed[i] = -mf_ed[i];
                                }
                                break;
                        }
                        switch (mi_eg[i])
                        {
                            case 1:
                                mo_dg.DrawImage(mo_ImgOfFly1, mi_ex[i], mi_ey[i], mo_ImgOfFly1.Width, mo_ImgOfFly1.Height);
                                mi_eg[i] = 2;
                                break;
                            case 2:
                                mo_dg.DrawImage(mo_ImgOfFly2, mi_ex[i], mi_ey[i], mo_ImgOfFly2.Width, mo_ImgOfFly2.Height);
                                mi_eg[i] = 1;
                                break;
                        }
                        //Check Crash(Jump Man)
                        if (mi_es[i] != 0 && Math.Abs(mi_gx - mi_ex[i]) < 12 && Math.Abs(mi_gy - mi_ey[i]) < 12)
                        {
                            mi_es[i] = 0;
                            mi_score++;
                            _wmp2.controls.play();
                        }
                        if (mi_ey[i] >= (CMI_HEIGHT - 40))
                        {
                            mi_mode = CMI_MODE_WAIT;
                            mi_tms2 = System.Environment.TickCount & int.MaxValue;
                            mf_frame_rate = (float)(mi_cron) / (float)(mi_tms2 - mi_tms1) * 1000;
                        }
                    }
                }
            }
            else if (mi_mode == CMI_MODE_WAIT)
            {
                M1_GAME_OVER();
                mi_wait++;
                if (mi_wait > 30)
                {
                    mi_mode = CMI_MODE_GAMEOVER;
                    mi_wait = 0;
                }
            }
            mb_now_doing = false;
        }

        public void M2_MOVE_JUMPMAN()
        {
            if (mi_dxd < 0)
            {
                mi_dx = mi_dxd;
                mi_dxd = mi_dxd + 1;
            }
            else if (mi_dxd > 0)
            {
                mi_dx = mi_dxd;
                mi_dxd = mi_dxd - 1;
            }
            else if (mi_mx > (mi_gx + 2))
            {
                mi_dx = 4;
            }
            else if (mi_mx < (mi_gx - 2))
            {
                mi_dx = -4;
            }
            else
            {
                mi_dx = 0;
            }
            mi_gx = mi_gx + mi_dx;
            if (mi_jpms == 5)
            {
                mi_gx = 32;
                mi_dy = 0;
            }
            else if (mi_jpms == 4)
            {
                mi_gx = CMI_WIDTH - 64;
                mi_dy = 0;
            }
            else if (mi_gx < 32 && mi_gy > 32)
            {
                mi_gx = 32;
                mi_dy = 0;
                mi_jpms = 5; //左の壁に張り付く
                mi_jpmnd = 0;
            }
            else if (mi_gx > (CMI_WIDTH - 64) && mi_gy > 32)
            {
                mi_gx = CMI_WIDTH - 64;
                mi_dy = 0;
                mi_jpms = 4; //右の壁に張り付く
                mi_jpmnd = 0;
            }
            else
            {
                if (mi_gx < 32) { mi_gx = 32; }
                if (mi_gx > (CMI_WIDTH - 64)) { mi_gx = CMI_WIDTH - 64; }
                mi_dy = mi_dy + 1;
                mi_gy = mi_gy + mi_dy;
                if (mi_gy > (CMI_HEIGHT - 48))
                {
                    mi_dy = 0;
                    mi_gy = CMI_HEIGHT - 48;
                    if (mi_jpms != 2)
                    {
                        mi_jpms = 2;  //地面にいる
                    }
                }
                else
                {
                    //空中にいる
                    if (mi_jpms >= 6)
                    {
                        //壁からのジャンプ中
                        if (mi_jpmnd >= 5)
                        {
                            mi_jpms = 1;
                            mi_jpmnd = 0;
                        }
                    }
                    else
                    {
                        //普通に空中にいる
                        mi_jpms = 1;
                    }
                    mi_jpmnd = mi_jpmnd + 1;
                }
            }
            switch (mi_jpms)
            {
                case 1:
                    if (mi_dy < -2)
                    {
                        mo_ImgOfJumpmn = mo_ImgOfJumpm1a;
                    }
                    else if (mi_dy > 2)
                    {
                        mo_ImgOfJumpmn = mo_ImgOfJumpm1c;
                    }
                    else
                    {
                        mo_ImgOfJumpmn = mo_ImgOfJumpm1b;
                    }
                    break;
                case 2:
                    if (mi_dx > 0)
                    {
                        mi_jpmnd = mi_jpmnd + 1;
                        if (mi_jpmnd >= 5)
                        {
                            if (mi_jpmn == 1)
                            {
                                mi_jpmn = 2;
                                mo_ImgOfJumpmn = mo_ImgOfJumpm2b;
                            }
                            else
                            {
                                mi_jpmn = 1;
                                mo_ImgOfJumpmn = mo_ImgOfJumpm2a;
                            }
                            mi_jpmnd = 0;
                        }
                    }
                    else if (mi_dx < 0)
                    {
                        mi_jpmnd = mi_jpmnd + 1;
                        if (mi_jpmnd >= 5)
                        {
                            if (mi_jpmn == 1)
                            {
                                mi_jpmn = 2;
                                mo_ImgOfJumpmn = mo_ImgOfJumpm3b;
                            }
                            else
                            {
                                mi_jpmn = 1;
                                mo_ImgOfJumpmn = mo_ImgOfJumpm3a;
                            }
                            mi_jpmnd = 0;
                        }
                    }
                    else
                    {
                        mi_jpmnd = mi_jpmnd + 1;
                        if (mi_jpmnd >= 10)
                        {
                            if (mi_jpmn == 1)
                            {
                                mi_jpmn = 2;
                                mo_ImgOfJumpmn = mo_ImgOfJumpm2b;
                            }
                            else
                            {
                                mi_jpmn = 1;
                                mo_ImgOfJumpmn = mo_ImgOfJumpm3b;
                            }
                            mi_jpmnd = 0;
                        }
                    }
                    break;
                case 4:
                    mo_ImgOfJumpmn = mo_ImgOfJumpm4a;
                    break;
                case 5:
                    mo_ImgOfJumpmn = mo_ImgOfJumpm5a;
                    break;
                case 6:
                    mo_ImgOfJumpmn = mo_ImgOfJumpm4b;
                    break;
                case 7:
                    mo_ImgOfJumpmn = mo_ImgOfJumpm5b;
                    break;
            }
            //JUMP MAN表示
            mo_dg.DrawImage(mo_ImgOfJumpmn, mi_gx, mi_gy, mo_ImgOfJumpmn.Width, mo_ImgOfJumpmn.Height);
        }

        public void M1_PAINT()
        {
            picDRAW.Image = mo_double_buffer;
        }

        public void M1_LOAD()
        {
            mo_dg.FillRectangle(Brushes.Black, mo_dg.VisibleClipBounds);
            Font fnt = new Font("Sans", 11);
            mo_dg.DrawString("Now Loading...", fnt, Brushes.White, 110, CMI_HEIGHT / 2);

            mo_ImgOfJumpm1a = Image.FromFile(ms_IMAGE_FILEPATH + "jumpman2_1a.gif");
            mo_ImgOfJumpm1b = Image.FromFile(ms_IMAGE_FILEPATH + "jumpman2_1b.gif");
            mo_ImgOfJumpm1c = Image.FromFile(ms_IMAGE_FILEPATH + "jumpman2_1c.gif");
            mo_ImgOfJumpm2a = Image.FromFile(ms_IMAGE_FILEPATH + "jumpman2_2a.gif");
            mo_ImgOfJumpm2b = Image.FromFile(ms_IMAGE_FILEPATH + "jumpman2_2b.gif");
            mo_ImgOfJumpm3a = Image.FromFile(ms_IMAGE_FILEPATH + "jumpman2_3a.gif");
            mo_ImgOfJumpm3b = Image.FromFile(ms_IMAGE_FILEPATH + "jumpman2_3b.gif");
            mo_ImgOfJumpm4a = Image.FromFile(ms_IMAGE_FILEPATH + "jumpman2_4a.gif");
            mo_ImgOfJumpm4b = Image.FromFile(ms_IMAGE_FILEPATH + "jumpman2_4b.gif");
            mo_ImgOfJumpm5a = Image.FromFile(ms_IMAGE_FILEPATH + "jumpman2_5a.gif");
            mo_ImgOfJumpm5b = Image.FromFile(ms_IMAGE_FILEPATH + "jumpman2_5b.gif");
            mo_ImgOfFly1 = Image.FromFile(ms_IMAGE_FILEPATH + "fly1.gif");
            mo_ImgOfFly2 = Image.FromFile(ms_IMAGE_FILEPATH + "fly2.gif");
            mo_ImgOfTitle = Image.FromFile(ms_IMAGE_FILEPATH + "jumpman2_logo.gif");
            this.picDRAW.MouseUp += new System.Windows.Forms.MouseEventHandler(this.picDRAW_MouseUp);
            this.picDRAW.MouseDown += new System.Windows.Forms.MouseEventHandler(this.picDRAW_MouseDown);
            this.picDRAW.MouseMove += new System.Windows.Forms.MouseEventHandler(this.picDRAW_MouseMove);
            mo_Timer.Tick += new EventHandler(this.TimerEventProcessor);
            mo_Timer.Interval = mi_INTERVAL;
            mo_Timer.Start();
            mi_mode = CMI_MODE_LOAD;
        }

        public void M1_TITLE()
        {
            if (mo_dg == null)
            {
                //SKIP
            }
            else
            {
                mo_dg.FillRectangle(Brushes.Black, mo_dg.VisibleClipBounds);
                Font f1 = new Font("Dialog", 12);
                mo_dg.DrawString("2003-2015  KAMA Presents", f1, Brushes.White, 55, 40);
                mo_dg.DrawImage(mo_ImgOfTitle, 0, 70, mo_ImgOfTitle.Width, mo_ImgOfTitle.Height);
                Font f2 = new Font("Dialog", 20);
                mo_dg.DrawString("Press Mouse Button", f2, Brushes.White, 35, CMI_HEIGHT - 50);
            }
        }

        public void M1_GAME_OVER()
        {
            if (mb_GAMEOVER_JUSTNOW == false)
            {
                mb_GAMEOVER_JUSTNOW = true;
                System.Threading.Thread.Sleep(1000);
            }
            mo_dg.FillRectangle(Brushes.Black, mo_dg.VisibleClipBounds);
            Font f1 = new Font("Sans", 28);
            mo_dg.DrawString("GAME OVER", f1, Brushes.White, 40, CMI_HEIGHT / 2 - 50);
            Font f2 = new Font("Dialog", 16);
            mo_dg.DrawString("SCORE : " + mi_score.ToString(), f2, Brushes.White, 100, CMI_HEIGHT / 2 + 30);
            Font f3 = new Font("Dialog", 12);
            mo_dg.DrawString(mf_frame_rate.ToString() + " Frames/Sec", f3, Brushes.White, 10, CMI_HEIGHT - 20);
        }

        public void M2_PUT_ENEMY()
        {
            int r;
            int nm;
            for (int j = 0; j < CMI_MAXENEMY; j++)
            {
                if (mi_es[j] == 0)
                {
                    nm = mi_level;
                    if (nm > 4) { nm = 4; }
                    r = M3_GET_RANDOM(nm);
                    mi_es[j] = (int)(r) + 1;
                    switch (mi_es[j])
                    {
                        case 1:
                            mf_ed[j] = 0;
                            r = M3_GET_RANDOM(CMI_WIDTH - 96);
                            mi_ex[j] = (int)(r) + 32;
                            break;
                        case 2:
                            mf_ed[j] = 0;
                            r = M3_GET_RANDOM(CMI_WIDTH - 128);
                            mi_ex[j] = (int)(r) + 64;
                            break;
                        case 3:
                            r = new System.Random().Next(3);
                            mf_ed[j] = (int)(r) * 2 - 1;
                            r = M3_GET_RANDOM(CMI_WIDTH - 96);
                            mi_ex[j] = (int)(r) + 32;
                            break;
                        case 4:
                            r = new System.Random().Next(3);
                            mf_ed[j] = (int)(r) * 2 - 1;
                            r = M3_GET_RANDOM(CMI_WIDTH - 96);
                            mi_ex[j] = (int)(r) + 32;
                            mi_ez1[j] = 0;
                            mi_ez2[j] = 0;
                            break;
                    }
                    mi_eg[j] = 1;
                    mi_ey[j] = -32;
                    j = CMI_MAXENEMY;
                }
            }
        }

        public void picDRAW_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (mi_mode == CMI_MODE_TITLE)
            {
                mo_dg.FillRectangle(Brushes.Black, mo_dg.VisibleClipBounds);
                mi_mode = CMI_MODE_GAME;
                mi_gx = (CMI_WIDTH / 2) - 16;
                mi_gy = CMI_HEIGHT - 48;
                mo_ImgOfJumpmn = mo_ImgOfJumpm1b;
                mi_score = 0;
                mi_level = 1;
                mi_rate = 40;
                mi_tms1 = System.Environment.TickCount & int.MaxValue;
                for (int i = 0; i < CMI_MAXENEMY; i++)
                {
                    mi_es[i] = 0;
                    mi_eg[i] = 1;
                    mi_ex[i] = CMI_WIDTH;
                    mi_ey[i] = -32;
                    mf_ed[i] = 0;
                }
                mb_GAMEOVER_JUSTNOW = false;
            }
            else if (mi_mode == CMI_MODE_GAMEOVER)
            {
                mi_mode = CMI_MODE_TITLE;
            }
            else if (mi_mode == CMI_MODE_GAME)
            {
                M2_GET_JUMPMAN_POSITION();
                if (mi_jpms == 4)
                {
                    //右の壁から左にジャンプ
                    mi_dy = -12;
                    mi_dxd = -14;
                    mi_jpms = 6;
                    mi_jpmnd = 0;
                    _wmp1.controls.play();
                }
                else if (mi_jpms == 5)
                {
                    //左の壁から右にジャンプ
                    mi_dy = -12;
                    mi_dxd = 14;
                    mi_jpms = 7;
                    mi_jpmnd = 0;
                    _wmp1.controls.play();
                }
                else if (mi_gy > 32)
                {
                    //ノーマルジャンプ
                    mi_dy = -16;
                    mi_jpms = 1;
                    mi_jpmnd = 0;
                    _wmp1.controls.play();
                }
            }
        }

        private void picDRAW_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            M2_GET_JUMPMAN_POSITION();
        }

        private void picDRAW_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            M2_GET_JUMPMAN_POSITION();
        }

        public void M2_GET_JUMPMAN_POSITION()
        {
            System.Drawing.Point sp = System.Windows.Forms.Cursor.Position;
            System.Drawing.Point cp = this.PointToClient(sp);
            mi_mx = (cp.X - picDRAW.Left) - 16;
            mi_my = (cp.Y - picDRAW.Top) - 16;
        }

        public int M3_GET_RANDOM(int nm)
        {
            byte[] bs = new byte[sizeof(int)];
            System.Security.Cryptography.RNGCryptoServiceProvider rng =
                new System.Security.Cryptography.RNGCryptoServiceProvider();
            rng.GetBytes(bs);
            //Int32に変換してnm未満の整数を返却する
            int i = System.BitConverter.ToInt32(bs, 0);
            return (Math.Abs(i % nm));
        }









    }
}
