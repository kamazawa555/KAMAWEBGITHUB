﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JUMPMAN
{
    class class_fish
    {
        int m_idx;
        double m_x0, m_y0;          // 現在の位置(x,y)
        double m_v0;                // 現在の速度
        double m_ux0, m_uy0;        // 進行方向を向く単位ベクトル(x,y)
        double m_x1, m_y1;          // 次ステップにおける位置(x,y) 
        double m_v1;                // 次ステップでの速度
        double m_ux1, m_uy1;        // 次ステップでの進行方向を向く単位ベクトル(x,y)
        double m_length;            // 体長

        double m_r_view;       // 視界範囲
        double m_r_repulsive;  // 嫌悪範囲
        double m_r_parallel;   // 平行動作範囲
        double m_r_attraction; // 誘引範囲
        double m_r_evasion;    // 逃げ範囲
        double m_max_speed;    // 最大速度

        int m_max_fish;            // 系内の最大Fish数
        int m_effectable_max_fish; // 系内の最大Fish数のうち、群れの形成に影響を与える最大数
        double[] m_dist;           // 他の個体までの距離 
        double[] m_diff_x;         // 相対位置単位ベクトルX
        double[] m_diff_y;         // 相対位置単位ベクトルY
        int[] m_order;             // 距離が近い順の個体番号 
        int m_in_att_area;         // 誘引範囲内に存在する個体数
        int[] m_key;               // 並び替え専用キー

        public class_fish( int idx, int max_fish, double kama_effect )
        {
            m_idx = idx;
            m_max_fish = max_fish;
            m_effectable_max_fish = (int)(max_fish * kama_effect);
            m_dist = new double[max_fish];
            m_diff_x = new double[max_fish];
            m_diff_y = new double[max_fish];
            m_order = new int[max_fish];
            m_key = new int[max_fish];

            m_r_view = 235.0;       // 視界範囲
            m_r_repulsive = 40.0;   // 嫌悪範囲
            m_r_parallel = 125.0;   // 平行動作範囲
            m_r_attraction = 235.0; // 誘引範囲
            m_r_evasion = 90.0;     // 逃げ範囲
            m_max_speed = 10.0;     // 最大速度
            m_length = 11.0 + 3.0 * M3_GET_RANDOM_11();    // 体長
        }

        public void init(int width, int height)
        {
            //初期位置と速度
            m_x0 = width * M3_GET_RANDOM_01();
            m_y0 = height * M3_GET_RANDOM_01();
            m_v0 = 0.0;
            m_ux0 = 10.0 * M3_GET_RANDOM_11();
            m_uy0 = 10.0 * M3_GET_RANDOM_11();
            //ここでの距離は厳密である必要がないためget_approx_distainceで近似する。
            //double rr = m_ux0 * m_ux0 + m_uy0 * m_uy0 + 0.01;
            //rr = Math.Sqrt(rr);
            double rr = get_approx_distance(m_ux0, m_uy0);
            m_ux0 = m_ux0 / rr;
            m_uy0 = m_uy0 / rr;

            for (int i = 0; i < m_max_fish; i++)
            {
                m_dist[i] = 99999.9;
                m_diff_x[i] = 1.0;
                m_diff_y[i] = 0.0;
                m_order[i] = i;
                m_key[i] = i;
            }
            m_in_att_area = 0;
        }

        public void set_parameter(
            double r_view,       // 視界範囲
            double r_repulsive,  // 嫌悪範囲
            double r_parallel,   // 平行動作範囲
            double r_attraction, // 誘引範囲
            double r_evasion,    // 回避範囲
            double max_speed     // 最大速度
            )
        {
            m_r_view = r_view;             // 視界範囲
            m_r_repulsive = r_repulsive;   // 嫌悪範囲
            m_r_parallel = r_parallel;     // 平行動作範囲
            m_r_attraction = r_attraction; // 誘引範囲
            m_r_evasion = r_evasion;       // 回避範囲
            m_max_speed = max_speed;       // 最大速度
        }

        public int get_neighborhood()
        {
            int rtn = -1;
            if (m_in_att_area <= 0) { return (rtn); }

            // 近いものほど影響を受けやすい。
            // ただし最大でもm_effectable_max_fishあれば十分である。
            int now_m_in_att_area = m_in_att_area;
            if (now_m_in_att_area > m_effectable_max_fish) { now_m_in_att_area = m_effectable_max_fish; }
            double eps = 0.0001;
            double sum = 0.0;
            for (int j = 0; j < now_m_in_att_area; j++)
            {
                int itm = m_order[j];
                sum += m_r_attraction / (m_dist[itm] + eps);
            }
            double d_sum = sum * M3_GET_RANDOM_01();
            sum = 0.0;
            for (int j = 0; j < now_m_in_att_area; j++)
            {
                int itm = m_order[j];
                sum += m_r_attraction / (m_dist[itm] + eps);
                if (sum >= d_sum)
                {
                    rtn = itm;
                }
            }
            // 念のための処理
            if (rtn == -1) { rtn = m_order[0]; }
            return (rtn);
        }

        public void cal_next_position()
        {
            rule_alone();
        }

        public void cal_next_position(int idx, class_fish fish)
        {
            double rr = m_dist[idx];
            if (rr < m_r_repulsive)
            {
                rule_rep(idx, fish);
            }
            else if (rr < m_r_parallel)
            {
                rule_par(idx, fish);
            }
            else if (rr < m_r_attraction)
            {
                rule_att(idx, fish);
            }
            else
            {
                rule_alone();
            }
        }

        public void cal_relative_position()
        {
            // 自分自身は一番遠く
            m_dist[m_idx] = 999999.9;
            // 近い順にソート。m_distでソートした結果のindexをm_orderに
            double[] temp_dist = new double[m_max_fish];
            Array.Copy(m_dist, 0, temp_dist, 0, m_max_fish);
            int[] temp_key = new int[temp_dist.Length];
            Array.Copy(m_key, 0, temp_key, 0, m_max_fish);
            Array.Sort(temp_dist, temp_key);
            Array.Copy(temp_key, 0, m_order, 0, m_max_fish);

            // 誘引範囲内に存在するfishの数をカウント
            m_in_att_area = 0;
            double rapid_last2_dist = temp_dist[m_max_fish - 2];
            if (rapid_last2_dist <= m_r_attraction)
            {
                // 自分自身を除く全Fishが影響範囲にいる
                m_in_att_area = m_max_fish - 1;
            }
            else
            {
                for (int i = 0; i < m_max_fish; i++)
                {
                    int itm = m_order[i];
                    if (itm < 0) { continue; }
                    else if (m_dist[itm] <= m_r_attraction)
                    {
                        m_in_att_area += 1;
                    }
                    else { break; }
                }
            }
        }

        protected void rule_rep(int idx, class_fish fish)
        {
            // 速度決定
            m_v1 = (0.3 * M3_GET_RANDOM_01() + 0.7) * m_max_speed;
            // 方向決定
            double tvx = m_diff_x[idx];
            double tvy = m_diff_y[idx];
            if (tvx * m_ux0 + tvy * m_uy0 > 0.0)
            {
                // 相手に向かっているならば
                m_v1 = (0.5 * M3_GET_RANDOM_01()) * m_max_speed;
                if (tvx * m_uy0 - tvy * m_ux0 < 0.0)
                {
                    // 相手が自分の左にいるならば右回りを選択
                    tvx = m_uy0;
                    tvy = -1.0 * m_ux0;
                }
                else
                {
                    // 左周りを選択
                    tvx = -1.0 * m_uy0;
                    tvy = m_ux0;
                }
            }
            else
            {
                if (tvx * m_ux0 + tvy * m_uy0 < -0.2)
                {   // 自分よりもかなり後ろならば
                    // 最大速度で現在方向へ逃げる
                    tvx = m_ux0;
                    tvy = m_uy0;
                    m_v1 = m_max_speed;
                }
                else
                {
                    // ベクトルを相手のいない方向へ向ける
                    tvx = -tvx;
                    tvy = -tvy;
                }
            }
            double rr = 2.0 * M3_GET_RANDOM_01() + 0.5;
            // フラツキ要素
            double vv_tx = m_uy0;
            double vv_ty = -1.0 * m_ux0;
            double r3 = 0.2 * M3_GET_RANDOM_11();
            // 次の方向ベクトル計算
            m_ux1 = m_ux0 + tvx * rr + vv_tx * r3;
            m_uy1 = m_uy0 + tvy * rr + vv_ty * r3;
            //ここでの距離は厳密である必要がないためget_approx_distainceで近似する。
            //double r = m_ux1 * m_ux1 + m_uy1 * m_uy1 + 0.001;
            //r = Math.Sqrt(r);
            double r = get_approx_distance(m_ux1, m_uy1);
            m_ux1 = m_ux1 / r;
            m_uy1 = m_uy1 / r;
            // 次ステップにおける位置決定
            m_x1 = m_v1 * m_ux1 + m_x0;
            m_y1 = m_v1 * m_uy1 + m_y0;
        }

        protected void rule_par(int idx, class_fish fish)
        {
            // 速度決定
            m_v1 = (0.55 * M3_GET_RANDOM_01() + 0.45) * m_max_speed;
            // 方向決定
            double tvx = fish.m_ux0;
            double tvy = fish.m_uy0;
            if (tvx * m_ux0 + tvy * m_uy0 < 0.0)
            {
                // 相手と反対向きならば
                m_v1 = 0.5 * m_max_speed;

                if (tvx * m_uy0 - tvy * m_ux0 > 0.0)
                {
                    // 右回りの方が近いならば
                    tvx = m_uy0;
                    tvy = -1.0 * m_ux0;
                }
                else
                {
                    tvx = -1.0 * m_uy0;
                    tvy = m_ux0;
                }
            }
            double rr = 1.0 * M3_GET_RANDOM_01() + 0.75;
            // フラツキ要素
            double vv_tx = m_uy0;
            double vv_ty = -1.0 * m_ux0;
            double r3 = 0.75 * M3_GET_RANDOM_11();
            // 次の方向ベクトル計算
            m_ux1 = m_ux0 + tvx * rr + vv_tx * r3;
            m_uy1 = m_uy0 + tvy * rr + vv_ty * r3;
            //ここでの距離は厳密である必要がないためget_approx_distainceで近似する。
            //double r = m_ux1 * m_ux1 + m_uy1 * m_uy1 + 0.001;
            //r = Math.Sqrt(r);
            double r = get_approx_distance(m_ux1, m_uy1);
            m_ux1 = m_ux1 / r;
            m_uy1 = m_uy1 / r;
            // 次位置決定
            m_x1 = m_v1 * m_ux1 + m_x0;
            m_y1 = m_v1 * m_uy1 + m_y0;
        }

        protected void rule_att(int idx, class_fish fish)
        {
            m_v1 = (0.2 * M3_GET_RANDOM_01() + 0.8) * m_max_speed;
            // 方向決定
            double tvx = m_diff_x[idx];
            double tvy = m_diff_y[idx];
            // 速度決定
            if (tvx * m_ux0 + tvy * m_uy0 < 0.0)
            {
                // 相手から離れているならば
                m_v1 = 0.5 * m_max_speed;
                if (tvx * m_uy0 - tvy * m_ux0 > 0.0)
                {
                    // 相手が自分の右にいるならば右回りを選択
                    tvx = m_uy0;
                    tvy = -1.0 * m_ux0;
                }
                else
                {
                    // 左周りを選択
                    tvx = -1.0 * m_uy0;
                    tvy = m_ux0;
                }
            }
            double rr = 1.0 * M3_GET_RANDOM_01() + 0.5;
            // フラツキ要素
            double vv_tx = m_uy0;
            double vv_ty = -1.0 * m_ux0;
            double r3 = 0.2 * M3_GET_RANDOM_11();
            // 次の方向ベクトル計算
            m_ux1 = m_ux0 + tvx * rr + vv_tx * r3;
            m_uy1 = m_uy0 + tvy * rr + vv_ty * r3;
            //ここでの距離は厳密である必要がないためget_approx_distainceで近似する。
            //double r = m_ux1 * m_ux1 + m_uy1 * m_uy1 + 0.001;
            //r = Math.Sqrt(r);
            double r = get_approx_distance(m_ux1, m_uy1);
            m_ux1 = m_ux1 / r;
            m_uy1 = m_uy1 / r;
            // 次位置決定
            m_x1 = m_v1 * m_ux1 + m_x0;
            m_y1 = m_v1 * m_uy1 + m_y0;
        }

        protected void rule_alone()
        {
            // 速度決定
            m_v1 = (0.2 * M3_GET_RANDOM_01() + 0.8) * m_max_speed;
            // 方向決定
            double tvx = m_uy0;
            double tvy = -1.0 * m_ux0;
            double rr = 3.0 * M3_GET_RANDOM_11();
            m_ux1 = m_ux0 + tvx * rr;
            m_uy1 = m_uy0 + tvy * rr;
            //ここでの距離は厳密である必要がないためget_approx_distainceで近似する。
            //double r = m_ux1 * m_ux1 + m_uy1 * m_uy1 + 0.001;
            //r = Math.Sqrt(r);
            double r = get_approx_distance(m_ux1, m_uy1);
            m_ux1 = m_ux1 / r;
            m_uy1 = m_uy1 / r;
            // 次ステップにおける位置決定
            m_x1 = m_v1 * m_ux1 + m_x0;
            m_y1 = m_v1 * m_uy1 + m_y0;
        }

        public void move_to_next_position()
        {

            m_x0 = m_x1;      // 現在の位置(x)
            m_y0 = m_y1;      // 現在の位置(y)
            m_v0 = m_v1;      // 現在の速度
            m_ux0 = m_ux1;    // 進行方向を向く単位ベクトル X
            m_uy0 = m_uy1;    // 進行方向を向く単位ベクトル Y
        }
        
        public void set_relative_position(int idx, class_fish fish)
        {
            // 相対距離及び、位置ベクトル計算
            if (idx == m_idx)
            {
                m_diff_x[idx] = 1.0;
                m_diff_y[idx] = 0.0;
                m_dist[idx] = 999999.9;
                return;
            }
            else
            {
                double dx = fish.m_x0 - m_x0;
                double dy = fish.m_y0 - m_y0;
                //ここでの距離は厳密である必要がないためget_approx_distainceで近似する。
                //m_dist[idx] = Math.Sqrt(Math.Pow(dx, 2) + Math.Pow(dy, 2) + 0.001);
                m_dist[idx] = get_approx_distance(dx, dy);
                m_diff_x[idx] = dx / m_dist[idx];
                m_diff_y[idx] = dy / m_dist[idx];
            }
        }

        public double get_x() { return (m_x0); }
        public double get_y() { return (m_y0); }
        public double get_vx() { return (m_ux0); }
        public double get_vy() { return (m_uy0); }
        public double get_length() { return (m_length); }

        public double get_approx_distance(double dx, double dy)
        {
            double approx;
            if (dx < 0) { dx = -dx; }
            if (dy < 0) { dy = -dy; }
            if (dx < dy)
            {
                approx = dy + 0.375 * dx;
                //approx = dy + ((int)dx >> 2) + ((int)dx >> 3);
            }
            else
            {
                approx = dx + 0.375 * dy;
                //approx = dx + ((int)dy >> 2) + ((int)dy >> 3);
            }
            return approx;
        }

        public int M3_GET_RANDOM(int nm)
        {
            byte[] bs = new byte[sizeof(int)];
            System.Security.Cryptography.RNGCryptoServiceProvider rng =
                new System.Security.Cryptography.RNGCryptoServiceProvider();
            rng.GetBytes(bs);
            //Int32に変換してnm未満の整数を返却する
            int i = System.BitConverter.ToInt32(bs, 0);
            return (Math.Abs(i % nm));
        }

        public double M3_GET_RANDOM_01()
        {
            //double r = new System.Random().Next(100);
            double r = M3_GET_RANDOM(100);
            return (double)r / 100;
        }

        public double M3_GET_RANDOM_11()
        {
            double ret = 1.0 - 2.0 * M3_GET_RANDOM_01();
            return ret;
        }

    }
}
