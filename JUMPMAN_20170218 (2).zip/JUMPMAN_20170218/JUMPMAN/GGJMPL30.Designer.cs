﻿namespace JUMPMAN
{
    partial class GGJMPL30
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picDRAW = new System.Windows.Forms.PictureBox();
            this.wbMANUAL = new System.Windows.Forms.WebBrowser();
            ((System.ComponentModel.ISupportInitialize)(this.picDRAW)).BeginInit();
            this.SuspendLayout();
            // 
            // picDRAW
            // 
            this.picDRAW.Location = new System.Drawing.Point(12, 12);
            this.picDRAW.Name = "picDRAW";
            this.picDRAW.Size = new System.Drawing.Size(320, 240);
            this.picDRAW.TabIndex = 0;
            this.picDRAW.TabStop = false;
            // 
            // wbMANUAL
            // 
            this.wbMANUAL.Location = new System.Drawing.Point(350, 12);
            this.wbMANUAL.MinimumSize = new System.Drawing.Size(20, 20);
            this.wbMANUAL.Name = "wbMANUAL";
            this.wbMANUAL.Size = new System.Drawing.Size(444, 240);
            this.wbMANUAL.TabIndex = 1;
            // 
            // GGJMPL30
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(814, 271);
            this.Controls.Add(this.wbMANUAL);
            this.Controls.Add(this.picDRAW);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "GGJMPL30";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GGJM30 : Jump Man 3";
            ((System.ComponentModel.ISupportInitialize)(this.picDRAW)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picDRAW;
        private System.Windows.Forms.WebBrowser wbMANUAL;
    }
}