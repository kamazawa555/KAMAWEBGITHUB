﻿namespace JUMPMAN
{
    partial class GGJMMN00
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.cmdJUMPMAN1 = new System.Windows.Forms.Button();
            this.cmdJUMPMAN2 = new System.Windows.Forms.Button();
            this.cmdJUMPMAN3 = new System.Windows.Forms.Button();
            this.cmdFISH = new System.Windows.Forms.Button();
            this.cmdFLY = new System.Windows.Forms.Button();
            this.cmdJUMPSBC = new System.Windows.Forms.Button();
            this.cmdESELIV = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cmdJUMPMAN1
            // 
            this.cmdJUMPMAN1.Location = new System.Drawing.Point(40, 12);
            this.cmdJUMPMAN1.Name = "cmdJUMPMAN1";
            this.cmdJUMPMAN1.Size = new System.Drawing.Size(97, 26);
            this.cmdJUMPMAN1.TabIndex = 1;
            this.cmdJUMPMAN1.Text = "Jump Man";
            this.cmdJUMPMAN1.UseVisualStyleBackColor = true;
            this.cmdJUMPMAN1.Click += new System.EventHandler(this.cmdJUMPMAN1_Click);
            // 
            // cmdJUMPMAN2
            // 
            this.cmdJUMPMAN2.Location = new System.Drawing.Point(40, 44);
            this.cmdJUMPMAN2.Name = "cmdJUMPMAN2";
            this.cmdJUMPMAN2.Size = new System.Drawing.Size(203, 26);
            this.cmdJUMPMAN2.TabIndex = 10;
            this.cmdJUMPMAN2.Text = "Jump Man 2";
            this.cmdJUMPMAN2.UseVisualStyleBackColor = true;
            this.cmdJUMPMAN2.Click += new System.EventHandler(this.cmdJUMPMAN2_Click);
            // 
            // cmdJUMPMAN3
            // 
            this.cmdJUMPMAN3.Location = new System.Drawing.Point(40, 76);
            this.cmdJUMPMAN3.Name = "cmdJUMPMAN3";
            this.cmdJUMPMAN3.Size = new System.Drawing.Size(203, 26);
            this.cmdJUMPMAN3.TabIndex = 20;
            this.cmdJUMPMAN3.Text = "Jump Man 3";
            this.cmdJUMPMAN3.UseVisualStyleBackColor = true;
            this.cmdJUMPMAN3.Click += new System.EventHandler(this.cmdJUMPMAN3_Click);
            // 
            // cmdFISH
            // 
            this.cmdFISH.Location = new System.Drawing.Point(40, 162);
            this.cmdFISH.Name = "cmdFISH";
            this.cmdFISH.Size = new System.Drawing.Size(203, 26);
            this.cmdFISH.TabIndex = 30;
            this.cmdFISH.Text = "FISH";
            this.cmdFISH.UseVisualStyleBackColor = true;
            this.cmdFISH.Click += new System.EventHandler(this.cmdFISH_Click);
            // 
            // cmdFLY
            // 
            this.cmdFLY.Location = new System.Drawing.Point(40, 194);
            this.cmdFLY.Name = "cmdFLY";
            this.cmdFLY.Size = new System.Drawing.Size(203, 26);
            this.cmdFLY.TabIndex = 40;
            this.cmdFLY.Text = "FLY";
            this.cmdFLY.UseVisualStyleBackColor = true;
            this.cmdFLY.Click += new System.EventHandler(this.cmdFLY_Click);
            // 
            // cmdJUMPSBC
            // 
            this.cmdJUMPSBC.Location = new System.Drawing.Point(146, 12);
            this.cmdJUMPSBC.Name = "cmdJUMPSBC";
            this.cmdJUMPSBC.Size = new System.Drawing.Size(97, 26);
            this.cmdJUMPSBC.TabIndex = 2;
            this.cmdJUMPSBC.Text = "Jump Man SBC";
            this.cmdJUMPSBC.UseVisualStyleBackColor = true;
            this.cmdJUMPSBC.Click += new System.EventHandler(this.cmdJUMPSBC_Click);
            // 
            // cmdESELIV
            // 
            this.cmdESELIV.Location = new System.Drawing.Point(40, 108);
            this.cmdESELIV.Name = "cmdESELIV";
            this.cmdESELIV.Size = new System.Drawing.Size(203, 26);
            this.cmdESELIV.TabIndex = 21;
            this.cmdESELIV.Text = "ESE LIVELION";
            this.cmdESELIV.UseVisualStyleBackColor = true;
            this.cmdESELIV.Click += new System.EventHandler(this.cmdESELIV_Click);
            // 
            // GGJMMN00
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 232);
            this.Controls.Add(this.cmdESELIV);
            this.Controls.Add(this.cmdJUMPSBC);
            this.Controls.Add(this.cmdFLY);
            this.Controls.Add(this.cmdFISH);
            this.Controls.Add(this.cmdJUMPMAN3);
            this.Controls.Add(this.cmdJUMPMAN2);
            this.Controls.Add(this.cmdJUMPMAN1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "GGJMMN00";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GGJMMN00 : Jump Man Series";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button cmdJUMPMAN1;
        private System.Windows.Forms.Button cmdJUMPMAN2;
        private System.Windows.Forms.Button cmdJUMPMAN3;
        private System.Windows.Forms.Button cmdFISH;
        private System.Windows.Forms.Button cmdFLY;
        private System.Windows.Forms.Button cmdJUMPSBC;
        private System.Windows.Forms.Button cmdESELIV;
    }
}

