﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JUMPMAN
{
    public partial class GGESPL10 : Form
    {
        //IMAGEファイルパス
        //String ms_IMAGE_FILEPATH = "C:\\DEVELOP\\IMAGE\\";
        String ms_IMAGE_FILEPATH = System.Windows.Forms.Application.StartupPath + "\\";

        //変数
        Timer mo_Timer = new System.Windows.Forms.Timer();
        Bitmap mo_double_buffer;
        Graphics mo_dg;
        Boolean mb_now_doing;

        int mi_INTERVAL = 20;
        const int CMI_MAXENEMY = 50;
        const int CMI_MAXSHOOT = 10;

        int mi_tms1;
        int mi_tms2;
        int mi_star = -160;
        int mi_cron;
        int mi_wait;
        int mi_score;
        int mi_level;
        int mi_rate;
        float mf_frame_rate;
        int mi_gx;
        int mi_gy;
        int mi_dx;
        int mi_dd;

        //Enemy status, coordinates
        int[] mi_es = new int[CMI_MAXENEMY];
        int[] mi_ex = new int[CMI_MAXENEMY];
        int[] mi_ey = new int[CMI_MAXENEMY];
        double[] mf_ed = new double[CMI_MAXENEMY];
        // Shoot status, coordinates
        int[] mi_ss = new int[CMI_MAXSHOOT];
        int[] mi_sx = new int[CMI_MAXSHOOT];
        int[] mi_sy = new int[CMI_MAXSHOOT];
        // Explosion status, coordinates
        int[] mi_bs = new int[CMI_MAXSHOOT];
        int[] mi_bx = new int[CMI_MAXSHOOT];
        int[] mi_by = new int[CMI_MAXSHOOT];

        Image mo_ImgOfLivelion_L;
        Image mo_ImgOfLivelion_R;
        Image mo_ImgOfLivelion;
        Image mo_ImgOfRay;
        Image mo_ImgOfExplosion;
        Image mo_ImgOfEnemy_A;
        Image mo_ImgOfEnemy_B;
        Image mo_ImgOfEnemy_C;
        Image mo_ImgOfTitle;
        Image mo_ImgOfStar;

        private readonly dynamic _wmp1 = Activator.CreateInstance(Type.GetTypeFromProgID("WMPlayer.OCX.7"));
        private readonly dynamic _wmp2 = Activator.CreateInstance(Type.GetTypeFromProgID("WMPlayer.OCX.7"));
        private readonly dynamic _wmp3 = Activator.CreateInstance(Type.GetTypeFromProgID("WMPlayer.OCX.7"));

        int mi_mode;
        const int CMI_MODE_LOAD = 0;
        const int CMI_MODE_TITLE = 1;
        const int CMI_MODE_GAME = 2;
        const int CMI_MODE_GAMEOVER = 3;
        const int CMI_MODE_WAIT = 4;

        const int CMI_WIDTH = 320;
        const int CMI_HEIGHT = 320;
        Boolean mb_GAMEOVER_JUSTNOW;

        public GGESPL10()
        {
            InitializeComponent();
            M0_FORM_LOAD();
        }

        public void M0_FORM_LOAD()
        {
            mo_double_buffer = new Bitmap(CMI_WIDTH, CMI_HEIGHT);
            mo_dg = Graphics.FromImage(mo_double_buffer);
            wbMANUAL.Url = new Uri(ms_IMAGE_FILEPATH + "eseliv.html");
            M1_LOAD();
            _wmp1.URL = ms_IMAGE_FILEPATH + "laser.wav";
            _wmp1.controls.play();
            _wmp2.URL = ms_IMAGE_FILEPATH + "blown.wav";
            _wmp2.controls.play();
            _wmp3.URL = ms_IMAGE_FILEPATH + "explo.wav";
            _wmp3.controls.play();
            this.Refresh();
        }

        public void TimerEventProcessor(object sender, EventArgs e)
        {
            this.M1_SET_INTERVAL();
            this.M1_DO_IT();
            this.M1_PAINT();
        }

        public void M1_SET_INTERVAL()
        {
            if (mi_mode == CMI_MODE_GAME)
            {
                mi_cron++;
                if (mi_cron >= 500)
                {
                    mi_tms2 = System.Environment.TickCount & int.MaxValue;
                    mf_frame_rate = (float)(mi_cron) / (float)(mi_tms2 - mi_tms1) * 1000;
                    if (mf_frame_rate < 20)
                    {
                        mi_INTERVAL = mi_INTERVAL - 2;
                        if (mi_INTERVAL < 0) { mi_INTERVAL = 0; }
                    }
                    else if (mf_frame_rate < 25)
                    {
                        mi_INTERVAL = mi_INTERVAL - 1;
                        if (mi_INTERVAL < 0) { mi_INTERVAL = 0; }
                    }
                    else if (mf_frame_rate >= 40)
                    {
                        mi_INTERVAL = mi_INTERVAL + 2;
                    }
                    else if (mf_frame_rate >= 35)
                    {
                        mi_INTERVAL = mi_INTERVAL + 1;
                    }
                    mi_level++;
                    mi_cron = 0;
                    mi_tms1 = System.Environment.TickCount & int.MaxValue;
                }
            }
        }

        public void M1_DO_IT()
        {
            if (mb_now_doing == true) { return; }
            mb_now_doing = true;
            if (mi_mode == CMI_MODE_LOAD) { mi_mode = CMI_MODE_TITLE; }
            else if (mi_mode == CMI_MODE_TITLE) { M1_TITLE(); }
            else if (mi_mode == CMI_MODE_GAMEOVER) { M1_GAME_OVER(); }
            else if (mi_mode == CMI_MODE_GAME)
            {
                //Clear Screen
                mo_dg.DrawImage(mo_ImgOfStar, 0, mi_star, mo_ImgOfStar.Width, mo_ImgOfStar.Height);
                mi_star++;
                if (mi_star == 0)
                {
                    mi_star = -160;
                }
                // Move Starship
                if (mi_gx < 0)
                {
                    mi_gx = 0;
                    mo_ImgOfLivelion = mo_ImgOfLivelion_R;
                    mi_dx = -mi_dx;
                }
                else if (mi_gx > CMI_WIDTH - 32)
                {
                    mi_gx = CMI_WIDTH - 32;
                    mo_ImgOfLivelion = mo_ImgOfLivelion_L;
                    mi_dx = -mi_dx;
                }
                mi_gx = mi_gx + mi_dx * mi_dd;
                mo_dg.DrawImage(mo_ImgOfLivelion, mi_gx, mi_gy, mo_ImgOfLivelion.Width, mo_ImgOfLivelion.Height);

                // Move Enemy 
                if ((mi_cron % mi_rate) == 0)
                {
                    int kazu;
                    kazu = new System.Random().Next(255);
                    kazu = kazu % mi_level / 2;
                    for (int i = 0; i <= kazu; i++)
                    {
                        M2_PUT_ENEMY();
                    }
                }
                for (int i = 0; i < CMI_MAXENEMY; i++)
                {
                    if (mi_es[i] != 0)
                    {
                        switch (mi_es[i])
                        {
                            case 1:
                                // Asteroid
                                mi_ey[i] = mi_ey[i] + 3;
                                break;
                            case 3:
                                // Hunter
                                mi_ey[i] = mi_ey[i] + 2;
                                if (mi_gx > mi_ex[i])
                                {
                                    mf_ed[i] = 1;
                                }
                                else if (mi_gx < mi_ex[i])
                                {
                                    mf_ed[i] = -1;
                                }
                                for (int j = 0; j < CMI_MAXSHOOT; j++)
                                {
                                    if (mi_ss[j] == 1 &&
                                    Math.Abs(mi_sx[j] - mi_ex[i]) < 20)
                                    {
                                        if (mi_sx[j] > mi_ex[i])
                                        {
                                            mf_ed[i] = -1;
                                        }
                                        else
                                        {
                                            mf_ed[i] = 1;
                                        }
                                    }
                                }
                                mi_ex[i] = mi_ex[i] + (int)(mf_ed[i]);
                                break;
                            case 2:
                                // Bomb
                                mi_ey[i] = mi_ey[i] + 1;
                                mf_ed[i] = mf_ed[i] + (float)(0.1);
                                if (mf_ed[i] > Math.PI * 2) { mf_ed[i] = 0; }
                                mi_ex[i] = mi_ex[i] + (int)(Math.Cos(mf_ed[i]) * 4);
                                break;
                        }
                        // Check Crash
                        if (Math.Abs(mi_gx - mi_ex[i]) < 18 &&
                        Math.Abs(mi_gy - mi_ey[i] - 20) < 26)
                        {
                            mi_mode = CMI_MODE_WAIT;
                            mi_tms2 = System.Environment.TickCount & int.MaxValue;
                            mf_frame_rate = (float)(mi_cron) / (float)(mi_tms2 - mi_tms1)
                                        * 1000;
                            _wmp3.controls.play();
                            mo_dg.DrawImage(mo_ImgOfExplosion, mi_gx - 4, mi_gy - 4, mo_ImgOfExplosion.Width, mo_ImgOfExplosion.Height);
                            mo_dg.DrawImage(mo_ImgOfExplosion, mi_gx + 4, mi_gy - 4, mo_ImgOfExplosion.Width, mo_ImgOfExplosion.Height);
                            mo_dg.DrawImage(mo_ImgOfExplosion, mi_gx - 4, mi_gy + 4, mo_ImgOfExplosion.Width, mo_ImgOfExplosion.Height);
                            mo_dg.DrawImage(mo_ImgOfExplosion, mi_gx + 4, mi_gy + 4, mo_ImgOfExplosion.Width, mo_ImgOfExplosion.Height);
                        }
                        // Check Destroyed
                        for (int j = 0; j < CMI_MAXSHOOT; j++)
                        {
                            if (mi_ss[j] == 1 &&
                            Math.Abs(mi_sx[j] - mi_ex[i]) < 16 &&
                            Math.Abs(mi_sy[j] - mi_ey[i] - 16) < 28)
                            {
                                mi_ss[j] = 0;
                                mi_es[i] = 0;
                                mf_ed[i] = 0;
                                mi_score++;
                                _wmp2.controls.play();
                                mi_bs[j] = 5;
                                mi_bx[j] = mi_ex[i];
                                mi_by[j] = mi_ey[i] + 16;
                            }
                        }
                        if (mi_ey[i] >= CMI_HEIGHT)
                        {
                            mi_ex[i] = CMI_WIDTH;
                            mi_es[i] = 0;
                            mi_ey[i] = 0;
                            mf_ed[i] = 0;
                        }
                        switch (mi_es[i])
                        {
                            case 1:
                                mo_dg.DrawImage(mo_ImgOfEnemy_A, mi_ex[i] - 2, mi_ey[i], mo_ImgOfEnemy_A.Width, mo_ImgOfEnemy_A.Height);
                                break;
                            case 2:
                                mo_dg.DrawImage(mo_ImgOfEnemy_B, mi_ex[i] - 2, mi_ey[i], mo_ImgOfEnemy_B.Width, mo_ImgOfEnemy_B.Height);
                                break;
                            case 3:
                                mo_dg.DrawImage(mo_ImgOfEnemy_C, mi_ex[i] - 2, mi_ey[i], mo_ImgOfEnemy_C.Width, mo_ImgOfEnemy_C.Height);
                                break;
                        }
                    }
                }

                // Move Ray
                for (int i = 0; i < CMI_MAXSHOOT; i++)
                {
                    if (mi_ss[i] == 1)
                    {
                        //mi_sy[i] = mi_sy[i] - 8;
                        mi_sy[i] = mi_sy[i] - 12;
                        if (mi_sy[i] < -32)
                        {
                            mi_ss[i] = 0;
                            mi_sx[i] = CMI_WIDTH;
                            mi_sy[i] = 0;
                        }
                        mo_dg.DrawImage(mo_ImgOfRay, mi_sx[i], mi_sy[i], mo_ImgOfRay.Width, mo_ImgOfRay.Height);
                    }
                }

                // Move Explosion
                for (int i = 0; i < CMI_MAXSHOOT; i++)
                {
                    if (mi_bs[i] >= 0)
                    {
                        mi_bs[i]--;
                        mo_dg.DrawImage(mo_ImgOfExplosion, mi_bx[i], mi_by[i], mo_ImgOfExplosion.Width, mo_ImgOfExplosion.Height);
                    }
                }
            }

            else if (mi_mode == CMI_MODE_WAIT)
            {
                M1_GAME_OVER();
                mi_wait++;
                if (mi_wait > 30)
                {
                    mi_mode = CMI_MODE_GAMEOVER;
                    mi_wait = 0;
                }
            }
            mb_now_doing = false;
        }

        public void M1_PAINT()
        {
            picDRAW.Image = mo_double_buffer;
        }

        public void M1_LOAD()
        {
            mo_dg.FillRectangle(Brushes.Black, mo_dg.VisibleClipBounds);
            Font fnt = new Font("Sans", 11);
            mo_dg.DrawString("Now Loading...", fnt, Brushes.White, 110, CMI_HEIGHT / 2);

            mo_ImgOfLivelion_L = Image.FromFile(ms_IMAGE_FILEPATH + "live_L.gif");
            mo_ImgOfLivelion_R = Image.FromFile(ms_IMAGE_FILEPATH + "live_R.gif");
            mo_ImgOfRay = Image.FromFile(ms_IMAGE_FILEPATH + "liveray.gif");
            mo_ImgOfExplosion = Image.FromFile(ms_IMAGE_FILEPATH + "Explosion.gif");
            mo_ImgOfEnemy_A = Image.FromFile(ms_IMAGE_FILEPATH + "MBLUE2.GIF");
            mo_ImgOfEnemy_B = Image.FromFile(ms_IMAGE_FILEPATH + "MRED2.GIF");
            mo_ImgOfEnemy_C = Image.FromFile(ms_IMAGE_FILEPATH + "MGRAY2.GIF");
            mo_ImgOfTitle = Image.FromFile(ms_IMAGE_FILEPATH + "livelog2.gif");
            mo_ImgOfStar = Image.FromFile(ms_IMAGE_FILEPATH + "livestar.gif");
            this.picDRAW.MouseUp += new System.Windows.Forms.MouseEventHandler(this.picDRAW_MouseUp);
            this.picDRAW.MouseDown += new System.Windows.Forms.MouseEventHandler(this.picDRAW_MouseDown);
            mo_Timer.Tick += new EventHandler(this.TimerEventProcessor);
            mo_Timer.Interval = mi_INTERVAL;
            mo_Timer.Start();
            mi_mode = CMI_MODE_LOAD;
        }

        public void M1_TITLE()
        {
            if (mo_dg == null)
            {
                //SKIP
            }
            else
            {
                //mo_dg.FillRectangle(Brushes.Black, mo_dg.VisibleClipBounds);
                mo_dg.DrawImage(mo_ImgOfStar, 0, mi_star, mo_ImgOfStar.Width, mo_ImgOfStar.Height);
                mi_star++;
                if (mi_star == 0)
                {
                    mi_star = -160;
                }
                Font f1 = new Font("Dialog", 12);
                mo_dg.DrawString("1997-2017  KAMA & S.B.C. Presents", f1, Brushes.White, 20, 40);
                mo_dg.DrawImage(mo_ImgOfTitle, 0, 70, mo_ImgOfTitle.Width, mo_ImgOfTitle.Height);
                Font f2 = new Font("Dialog", 20);
                mo_dg.DrawString("Press Mouse Button", f2, Brushes.White, 35, CMI_HEIGHT - 50);
            }
        }

        public void M1_GAME_OVER()
        {
            if (mb_GAMEOVER_JUSTNOW == false)
            {
                mb_GAMEOVER_JUSTNOW = true;
                System.Threading.Thread.Sleep(1000);
            }
            Font f1 = new Font("Sans", 28);
            mo_dg.DrawString("GAME OVER", f1, Brushes.White, 40, CMI_HEIGHT / 2 - 50);
            Font f2 = new Font("Dialog", 16);
            mo_dg.DrawString("SCORE : " + mi_score.ToString(), f2, Brushes.White, 100, CMI_HEIGHT / 2 + 30);
            Font f3 = new Font("Dialog", 12);
            mo_dg.DrawString(mf_frame_rate.ToString() + " Frames/Sec", f3, Brushes.White, 10, CMI_HEIGHT - 20);
        }

        public void M2_PUT_ENEMY()
        {
            int nm;
            for (int j = 0; j < CMI_MAXENEMY; j++)
            {
                if ( mi_es[j] == 0 )
               {
                    nm = mi_level;
                    if ( nm > 3 )
                    {
                        nm = 3;
                    }
                    mi_es[j] = (int)M3_GET_RANDOM(nm) + 1;
                    mi_ex[j] = (int)M3_GET_RANDOM(CMI_WIDTH - 32);
                    mi_ey[j] = -64;
                    j = CMI_MAXENEMY;
                }
            }
        }

        public void picDRAW_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (mi_mode == CMI_MODE_TITLE)
            {
                mo_dg.FillRectangle(Brushes.Black, mo_dg.VisibleClipBounds);
                mi_mode = CMI_MODE_GAME;
                mi_cron = 0;
                mi_gx = (CMI_WIDTH / 2) - 16;
                mi_gy = CMI_HEIGHT - 50;
                //mi_dx = -2;
                mi_dx = -4;
                mi_dd = 0;
                mi_score = 0;
                mi_level = 1;
                mi_rate = 20;
                mi_tms1 = System.Environment.TickCount & int.MaxValue;
                for (int i = 0; i < CMI_MAXENEMY; i++)
                {
                    mi_es[i] = 0;
                    mi_ex[i] = CMI_WIDTH;
                    mi_ey[i] = -32;
                    mf_ed[i] = 0;
                }
                for (int i = 0; i < CMI_MAXSHOOT; i++)
                {
                    mi_ss[i] = 0;
                    mi_sx[i] = CMI_WIDTH;
                    mi_sy[i] = -32;
                    mi_bs[i] = 0;
                    mi_bx[i] = CMI_WIDTH;
                    mi_by[i] = -32;
                }
                mo_ImgOfLivelion = mo_ImgOfLivelion_L;
                mb_GAMEOVER_JUSTNOW = false;
            }
            else if (mi_mode == CMI_MODE_GAMEOVER)
            {
                mi_mode = CMI_MODE_TITLE;
            }
            else if (mi_mode == CMI_MODE_GAME)
            {
                mi_dd = 1;
                M2_PUT_RAY();
            }
        }

        private void M2_PUT_RAY()
        {
            _wmp1.controls.play();
        	for (int i = 0; i < CMI_MAXSHOOT; i++)
        	{
        		if ( mi_ss[i] == 0 ) 
        		{
        			mi_ss[i] = 1;
                    //mi_sx[i] = mi_gx + mi_dx * 8;
                    mi_sx[i] = mi_gx + mi_dx * 4;
        			mi_sy[i] = mi_gy - 10;
        			i = CMI_MAXSHOOT;
        		}
        	}
        }

        private void picDRAW_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            mi_dd = 0;
        }

        public int M3_GET_RANDOM(int nm)
        {
            byte[] bs = new byte[sizeof(int)];
            System.Security.Cryptography.RNGCryptoServiceProvider rng =
                new System.Security.Cryptography.RNGCryptoServiceProvider();
            rng.GetBytes(bs);
            //Int32に変換してnm未満の整数を返却する
            int i = System.BitConverter.ToInt32(bs, 0);
            return (Math.Abs(i % nm));
        }
    }
}
