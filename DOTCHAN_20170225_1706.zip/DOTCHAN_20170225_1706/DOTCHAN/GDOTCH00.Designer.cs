﻿namespace DOTCHAN
{
    partial class GDOTCH00
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GDOTCH00));
            this.btnLoad = new System.Windows.Forms.Button();
            this.picOriginal = new System.Windows.Forms.PictureBox();
            this.btnCHANGE = new System.Windows.Forms.Button();
            this.cmbP1 = new System.Windows.Forms.ComboBox();
            this.cmbP2 = new System.Windows.Forms.ComboBox();
            this.grpDOT = new System.Windows.Forms.GroupBox();
            this.btnOpt = new System.Windows.Forms.Button();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.clearAllStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rearrangeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.picD88 = new System.Windows.Forms.PictureBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.zoomToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.clearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.picD87 = new System.Windows.Forms.PictureBox();
            this.picD86 = new System.Windows.Forms.PictureBox();
            this.picD85 = new System.Windows.Forms.PictureBox();
            this.picD84 = new System.Windows.Forms.PictureBox();
            this.picD83 = new System.Windows.Forms.PictureBox();
            this.picD82 = new System.Windows.Forms.PictureBox();
            this.picD81 = new System.Windows.Forms.PictureBox();
            this.picD80 = new System.Windows.Forms.PictureBox();
            this.picD79 = new System.Windows.Forms.PictureBox();
            this.picD78 = new System.Windows.Forms.PictureBox();
            this.picD77 = new System.Windows.Forms.PictureBox();
            this.picD76 = new System.Windows.Forms.PictureBox();
            this.picD75 = new System.Windows.Forms.PictureBox();
            this.picD74 = new System.Windows.Forms.PictureBox();
            this.picD73 = new System.Windows.Forms.PictureBox();
            this.picD72 = new System.Windows.Forms.PictureBox();
            this.picD71 = new System.Windows.Forms.PictureBox();
            this.picD70 = new System.Windows.Forms.PictureBox();
            this.picD69 = new System.Windows.Forms.PictureBox();
            this.picD68 = new System.Windows.Forms.PictureBox();
            this.picD67 = new System.Windows.Forms.PictureBox();
            this.picD66 = new System.Windows.Forms.PictureBox();
            this.picD65 = new System.Windows.Forms.PictureBox();
            this.picD64 = new System.Windows.Forms.PictureBox();
            this.picD63 = new System.Windows.Forms.PictureBox();
            this.picD62 = new System.Windows.Forms.PictureBox();
            this.picD61 = new System.Windows.Forms.PictureBox();
            this.picD60 = new System.Windows.Forms.PictureBox();
            this.picD59 = new System.Windows.Forms.PictureBox();
            this.picD58 = new System.Windows.Forms.PictureBox();
            this.picD57 = new System.Windows.Forms.PictureBox();
            this.picD56 = new System.Windows.Forms.PictureBox();
            this.picD55 = new System.Windows.Forms.PictureBox();
            this.picD54 = new System.Windows.Forms.PictureBox();
            this.picD53 = new System.Windows.Forms.PictureBox();
            this.picD52 = new System.Windows.Forms.PictureBox();
            this.picD51 = new System.Windows.Forms.PictureBox();
            this.picD50 = new System.Windows.Forms.PictureBox();
            this.picD49 = new System.Windows.Forms.PictureBox();
            this.picD48 = new System.Windows.Forms.PictureBox();
            this.picD47 = new System.Windows.Forms.PictureBox();
            this.picD46 = new System.Windows.Forms.PictureBox();
            this.picD45 = new System.Windows.Forms.PictureBox();
            this.picD44 = new System.Windows.Forms.PictureBox();
            this.picD43 = new System.Windows.Forms.PictureBox();
            this.picD42 = new System.Windows.Forms.PictureBox();
            this.picD41 = new System.Windows.Forms.PictureBox();
            this.picD40 = new System.Windows.Forms.PictureBox();
            this.picD39 = new System.Windows.Forms.PictureBox();
            this.picD38 = new System.Windows.Forms.PictureBox();
            this.picD37 = new System.Windows.Forms.PictureBox();
            this.picD36 = new System.Windows.Forms.PictureBox();
            this.picD35 = new System.Windows.Forms.PictureBox();
            this.picD34 = new System.Windows.Forms.PictureBox();
            this.picD33 = new System.Windows.Forms.PictureBox();
            this.picD32 = new System.Windows.Forms.PictureBox();
            this.picD31 = new System.Windows.Forms.PictureBox();
            this.picD30 = new System.Windows.Forms.PictureBox();
            this.picD29 = new System.Windows.Forms.PictureBox();
            this.picD28 = new System.Windows.Forms.PictureBox();
            this.picD27 = new System.Windows.Forms.PictureBox();
            this.picD26 = new System.Windows.Forms.PictureBox();
            this.picD25 = new System.Windows.Forms.PictureBox();
            this.picD24 = new System.Windows.Forms.PictureBox();
            this.picD23 = new System.Windows.Forms.PictureBox();
            this.picD22 = new System.Windows.Forms.PictureBox();
            this.picD21 = new System.Windows.Forms.PictureBox();
            this.picD20 = new System.Windows.Forms.PictureBox();
            this.picD19 = new System.Windows.Forms.PictureBox();
            this.picD18 = new System.Windows.Forms.PictureBox();
            this.picD17 = new System.Windows.Forms.PictureBox();
            this.picD16 = new System.Windows.Forms.PictureBox();
            this.picD15 = new System.Windows.Forms.PictureBox();
            this.picD14 = new System.Windows.Forms.PictureBox();
            this.picD13 = new System.Windows.Forms.PictureBox();
            this.picD12 = new System.Windows.Forms.PictureBox();
            this.picD11 = new System.Windows.Forms.PictureBox();
            this.picD10 = new System.Windows.Forms.PictureBox();
            this.picD09 = new System.Windows.Forms.PictureBox();
            this.picD08 = new System.Windows.Forms.PictureBox();
            this.picD07 = new System.Windows.Forms.PictureBox();
            this.picD06 = new System.Windows.Forms.PictureBox();
            this.picD05 = new System.Windows.Forms.PictureBox();
            this.picD04 = new System.Windows.Forms.PictureBox();
            this.picD03 = new System.Windows.Forms.PictureBox();
            this.picD02 = new System.Windows.Forms.PictureBox();
            this.picD01 = new System.Windows.Forms.PictureBox();
            this.cmbBackColor = new System.Windows.Forms.ComboBox();
            this.txtInfo = new System.Windows.Forms.TextBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            ((System.ComponentModel.ISupportInitialize)(this.picOriginal)).BeginInit();
            this.grpDOT.SuspendLayout();
            this.contextMenuStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picD88)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picD87)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD86)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD85)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD84)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD83)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD82)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD81)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD80)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD79)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD78)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD77)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD76)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD75)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD74)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD73)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD72)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD71)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD70)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD69)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD68)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD67)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD66)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD65)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD64)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD63)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD62)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD60)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD59)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD58)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD57)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD49)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD09)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD08)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD07)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD06)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD05)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD04)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD01)).BeginInit();
            this.SuspendLayout();
            // 
            // btnLoad
            // 
            this.btnLoad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLoad.Location = new System.Drawing.Point(2, 3);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(70, 25);
            this.btnLoad.TabIndex = 0;
            this.btnLoad.Text = "Load";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // picOriginal
            // 
            this.picOriginal.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.picOriginal.Location = new System.Drawing.Point(2, 34);
            this.picOriginal.Name = "picOriginal";
            this.picOriginal.Size = new System.Drawing.Size(269, 302);
            this.picOriginal.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picOriginal.TabIndex = 1;
            this.picOriginal.TabStop = false;
            this.picOriginal.DoubleClick += new System.EventHandler(this.picOriginal_DoubleClick);
            // 
            // btnCHANGE
            // 
            this.btnCHANGE.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCHANGE.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCHANGE.Location = new System.Drawing.Point(194, 397);
            this.btnCHANGE.Name = "btnCHANGE";
            this.btnCHANGE.Size = new System.Drawing.Size(77, 46);
            this.btnCHANGE.TabIndex = 25;
            this.btnCHANGE.Text = "DOT Change";
            this.btnCHANGE.UseVisualStyleBackColor = true;
            this.btnCHANGE.Click += new System.EventHandler(this.btnCHANGE_Click);
            // 
            // cmbP1
            // 
            this.cmbP1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbP1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbP1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbP1.FormattingEnabled = true;
            this.cmbP1.Location = new System.Drawing.Point(194, 345);
            this.cmbP1.Name = "cmbP1";
            this.cmbP1.Size = new System.Drawing.Size(77, 20);
            this.cmbP1.TabIndex = 23;
            // 
            // cmbP2
            // 
            this.cmbP2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbP2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbP2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbP2.FormattingEnabled = true;
            this.cmbP2.Location = new System.Drawing.Point(194, 371);
            this.cmbP2.Name = "cmbP2";
            this.cmbP2.Size = new System.Drawing.Size(77, 20);
            this.cmbP2.TabIndex = 24;
            // 
            // grpDOT
            // 
            this.grpDOT.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpDOT.Controls.Add(this.btnOpt);
            this.grpDOT.Controls.Add(this.picD88);
            this.grpDOT.Controls.Add(this.picD87);
            this.grpDOT.Controls.Add(this.picD86);
            this.grpDOT.Controls.Add(this.picD85);
            this.grpDOT.Controls.Add(this.picD84);
            this.grpDOT.Controls.Add(this.picD83);
            this.grpDOT.Controls.Add(this.picD82);
            this.grpDOT.Controls.Add(this.picD81);
            this.grpDOT.Controls.Add(this.picD80);
            this.grpDOT.Controls.Add(this.picD79);
            this.grpDOT.Controls.Add(this.picD78);
            this.grpDOT.Controls.Add(this.picD77);
            this.grpDOT.Controls.Add(this.picD76);
            this.grpDOT.Controls.Add(this.picD75);
            this.grpDOT.Controls.Add(this.picD74);
            this.grpDOT.Controls.Add(this.picD73);
            this.grpDOT.Controls.Add(this.picD72);
            this.grpDOT.Controls.Add(this.picD71);
            this.grpDOT.Controls.Add(this.picD70);
            this.grpDOT.Controls.Add(this.picD69);
            this.grpDOT.Controls.Add(this.picD68);
            this.grpDOT.Controls.Add(this.picD67);
            this.grpDOT.Controls.Add(this.picD66);
            this.grpDOT.Controls.Add(this.picD65);
            this.grpDOT.Controls.Add(this.picD64);
            this.grpDOT.Controls.Add(this.picD63);
            this.grpDOT.Controls.Add(this.picD62);
            this.grpDOT.Controls.Add(this.picD61);
            this.grpDOT.Controls.Add(this.picD60);
            this.grpDOT.Controls.Add(this.picD59);
            this.grpDOT.Controls.Add(this.picD58);
            this.grpDOT.Controls.Add(this.picD57);
            this.grpDOT.Controls.Add(this.picD56);
            this.grpDOT.Controls.Add(this.picD55);
            this.grpDOT.Controls.Add(this.picD54);
            this.grpDOT.Controls.Add(this.picD53);
            this.grpDOT.Controls.Add(this.picD52);
            this.grpDOT.Controls.Add(this.picD51);
            this.grpDOT.Controls.Add(this.picD50);
            this.grpDOT.Controls.Add(this.picD49);
            this.grpDOT.Controls.Add(this.picD48);
            this.grpDOT.Controls.Add(this.picD47);
            this.grpDOT.Controls.Add(this.picD46);
            this.grpDOT.Controls.Add(this.picD45);
            this.grpDOT.Controls.Add(this.picD44);
            this.grpDOT.Controls.Add(this.picD43);
            this.grpDOT.Controls.Add(this.picD42);
            this.grpDOT.Controls.Add(this.picD41);
            this.grpDOT.Controls.Add(this.picD40);
            this.grpDOT.Controls.Add(this.picD39);
            this.grpDOT.Controls.Add(this.picD38);
            this.grpDOT.Controls.Add(this.picD37);
            this.grpDOT.Controls.Add(this.picD36);
            this.grpDOT.Controls.Add(this.picD35);
            this.grpDOT.Controls.Add(this.picD34);
            this.grpDOT.Controls.Add(this.picD33);
            this.grpDOT.Controls.Add(this.picD32);
            this.grpDOT.Controls.Add(this.picD31);
            this.grpDOT.Controls.Add(this.picD30);
            this.grpDOT.Controls.Add(this.picD29);
            this.grpDOT.Controls.Add(this.picD28);
            this.grpDOT.Controls.Add(this.picD27);
            this.grpDOT.Controls.Add(this.picD26);
            this.grpDOT.Controls.Add(this.picD25);
            this.grpDOT.Controls.Add(this.picD24);
            this.grpDOT.Controls.Add(this.picD23);
            this.grpDOT.Controls.Add(this.picD22);
            this.grpDOT.Controls.Add(this.picD21);
            this.grpDOT.Controls.Add(this.picD20);
            this.grpDOT.Controls.Add(this.picD19);
            this.grpDOT.Controls.Add(this.picD18);
            this.grpDOT.Controls.Add(this.picD17);
            this.grpDOT.Controls.Add(this.picD16);
            this.grpDOT.Controls.Add(this.picD15);
            this.grpDOT.Controls.Add(this.picD14);
            this.grpDOT.Controls.Add(this.picD13);
            this.grpDOT.Controls.Add(this.picD12);
            this.grpDOT.Controls.Add(this.picD11);
            this.grpDOT.Controls.Add(this.picD10);
            this.grpDOT.Controls.Add(this.picD09);
            this.grpDOT.Controls.Add(this.picD08);
            this.grpDOT.Controls.Add(this.picD07);
            this.grpDOT.Controls.Add(this.picD06);
            this.grpDOT.Controls.Add(this.picD05);
            this.grpDOT.Controls.Add(this.picD04);
            this.grpDOT.Controls.Add(this.picD03);
            this.grpDOT.Controls.Add(this.picD02);
            this.grpDOT.Controls.Add(this.picD01);
            this.grpDOT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.grpDOT.Location = new System.Drawing.Point(277, 3);
            this.grpDOT.Name = "grpDOT";
            this.grpDOT.Size = new System.Drawing.Size(531, 440);
            this.grpDOT.TabIndex = 20;
            this.grpDOT.TabStop = false;
            this.grpDOT.Text = "DOT Image";
            // 
            // btnOpt
            // 
            this.btnOpt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOpt.ContextMenuStrip = this.contextMenuStrip2;
            this.btnOpt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOpt.Font = new System.Drawing.Font("MS UI Gothic", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnOpt.Location = new System.Drawing.Point(500, 0);
            this.btnOpt.Name = "btnOpt";
            this.btnOpt.Size = new System.Drawing.Size(30, 17);
            this.btnOpt.TabIndex = 30;
            this.btnOpt.Text = "Opt";
            this.btnOpt.UseVisualStyleBackColor = true;
            this.btnOpt.Click += new System.EventHandler(this.btnOpt_Click);
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clearAllStripMenuItem,
            this.rearrangeToolStripMenuItem});
            this.contextMenuStrip2.Name = "contextMenuStrip1";
            this.contextMenuStrip2.Size = new System.Drawing.Size(190, 48);
            // 
            // clearAllStripMenuItem
            // 
            this.clearAllStripMenuItem.Name = "clearAllStripMenuItem";
            this.clearAllStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.clearAllStripMenuItem.Text = "Clear All Dot Images";
            this.clearAllStripMenuItem.Click += new System.EventHandler(this.clearAllStripMenuItem_Click);
            // 
            // rearrangeToolStripMenuItem
            // 
            this.rearrangeToolStripMenuItem.Name = "rearrangeToolStripMenuItem";
            this.rearrangeToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.rearrangeToolStripMenuItem.Text = "Rearrange Dot Images";
            this.rearrangeToolStripMenuItem.Click += new System.EventHandler(this.rearrangeToolStripMenuItem_Click);
            // 
            // picD88
            // 
            this.picD88.ContextMenuStrip = this.contextMenuStrip1;
            this.picD88.Location = new System.Drawing.Point(458, 428);
            this.picD88.Name = "picD88";
            this.picD88.Size = new System.Drawing.Size(64, 5);
            this.picD88.TabIndex = 93;
            this.picD88.TabStop = false;
            this.picD88.Click += new System.EventHandler(this.picD88_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.zoomToolStripMenuItem,
            this.toolStripMenuItem2,
            this.clearToolStripMenuItem,
            this.toolStripMenuItem1,
            this.saveToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(106, 82);
            // 
            // zoomToolStripMenuItem
            // 
            this.zoomToolStripMenuItem.Name = "zoomToolStripMenuItem";
            this.zoomToolStripMenuItem.Size = new System.Drawing.Size(105, 22);
            this.zoomToolStripMenuItem.Text = "Zoom";
            this.zoomToolStripMenuItem.Click += new System.EventHandler(this.zoomToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(102, 6);
            // 
            // clearToolStripMenuItem
            // 
            this.clearToolStripMenuItem.Name = "clearToolStripMenuItem";
            this.clearToolStripMenuItem.Size = new System.Drawing.Size(105, 22);
            this.clearToolStripMenuItem.Text = "Clear";
            this.clearToolStripMenuItem.Click += new System.EventHandler(this.clearToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(102, 6);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(105, 22);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // picD87
            // 
            this.picD87.ContextMenuStrip = this.contextMenuStrip1;
            this.picD87.Location = new System.Drawing.Point(394, 428);
            this.picD87.Name = "picD87";
            this.picD87.Size = new System.Drawing.Size(64, 5);
            this.picD87.TabIndex = 92;
            this.picD87.TabStop = false;
            this.picD87.Click += new System.EventHandler(this.picD87_Click);
            // 
            // picD86
            // 
            this.picD86.ContextMenuStrip = this.contextMenuStrip1;
            this.picD86.Location = new System.Drawing.Point(330, 428);
            this.picD86.Name = "picD86";
            this.picD86.Size = new System.Drawing.Size(64, 5);
            this.picD86.TabIndex = 91;
            this.picD86.TabStop = false;
            this.picD86.Click += new System.EventHandler(this.picD86_Click);
            // 
            // picD85
            // 
            this.picD85.ContextMenuStrip = this.contextMenuStrip1;
            this.picD85.Location = new System.Drawing.Point(266, 428);
            this.picD85.Name = "picD85";
            this.picD85.Size = new System.Drawing.Size(64, 5);
            this.picD85.TabIndex = 90;
            this.picD85.TabStop = false;
            this.picD85.Click += new System.EventHandler(this.picD85_Click);
            // 
            // picD84
            // 
            this.picD84.ContextMenuStrip = this.contextMenuStrip1;
            this.picD84.Location = new System.Drawing.Point(202, 428);
            this.picD84.Name = "picD84";
            this.picD84.Size = new System.Drawing.Size(64, 5);
            this.picD84.TabIndex = 89;
            this.picD84.TabStop = false;
            this.picD84.Click += new System.EventHandler(this.picD84_Click);
            // 
            // picD83
            // 
            this.picD83.ContextMenuStrip = this.contextMenuStrip1;
            this.picD83.Location = new System.Drawing.Point(138, 428);
            this.picD83.Name = "picD83";
            this.picD83.Size = new System.Drawing.Size(64, 5);
            this.picD83.TabIndex = 88;
            this.picD83.TabStop = false;
            this.picD83.Click += new System.EventHandler(this.picD83_Click);
            // 
            // picD82
            // 
            this.picD82.ContextMenuStrip = this.contextMenuStrip1;
            this.picD82.Location = new System.Drawing.Point(74, 428);
            this.picD82.Name = "picD82";
            this.picD82.Size = new System.Drawing.Size(64, 5);
            this.picD82.TabIndex = 87;
            this.picD82.TabStop = false;
            this.picD82.Click += new System.EventHandler(this.picD82_Click);
            // 
            // picD81
            // 
            this.picD81.ContextMenuStrip = this.contextMenuStrip1;
            this.picD81.Location = new System.Drawing.Point(10, 428);
            this.picD81.Name = "picD81";
            this.picD81.Size = new System.Drawing.Size(64, 5);
            this.picD81.TabIndex = 86;
            this.picD81.TabStop = false;
            this.picD81.Click += new System.EventHandler(this.picD81_Click);
            // 
            // picD80
            // 
            this.picD80.ContextMenuStrip = this.contextMenuStrip1;
            this.picD80.Location = new System.Drawing.Point(458, 420);
            this.picD80.Name = "picD80";
            this.picD80.Size = new System.Drawing.Size(64, 5);
            this.picD80.TabIndex = 85;
            this.picD80.TabStop = false;
            this.picD80.Click += new System.EventHandler(this.picD80_Click);
            // 
            // picD79
            // 
            this.picD79.ContextMenuStrip = this.contextMenuStrip1;
            this.picD79.Location = new System.Drawing.Point(394, 420);
            this.picD79.Name = "picD79";
            this.picD79.Size = new System.Drawing.Size(64, 5);
            this.picD79.TabIndex = 84;
            this.picD79.TabStop = false;
            this.picD79.Click += new System.EventHandler(this.picD79_Click);
            // 
            // picD78
            // 
            this.picD78.ContextMenuStrip = this.contextMenuStrip1;
            this.picD78.Location = new System.Drawing.Point(330, 420);
            this.picD78.Name = "picD78";
            this.picD78.Size = new System.Drawing.Size(64, 5);
            this.picD78.TabIndex = 83;
            this.picD78.TabStop = false;
            this.picD78.Click += new System.EventHandler(this.picD78_Click);
            // 
            // picD77
            // 
            this.picD77.ContextMenuStrip = this.contextMenuStrip1;
            this.picD77.Location = new System.Drawing.Point(266, 420);
            this.picD77.Name = "picD77";
            this.picD77.Size = new System.Drawing.Size(64, 5);
            this.picD77.TabIndex = 82;
            this.picD77.TabStop = false;
            this.picD77.Click += new System.EventHandler(this.picD77_Click);
            // 
            // picD76
            // 
            this.picD76.ContextMenuStrip = this.contextMenuStrip1;
            this.picD76.Location = new System.Drawing.Point(202, 420);
            this.picD76.Name = "picD76";
            this.picD76.Size = new System.Drawing.Size(64, 5);
            this.picD76.TabIndex = 81;
            this.picD76.TabStop = false;
            this.picD76.Click += new System.EventHandler(this.picD76_Click);
            // 
            // picD75
            // 
            this.picD75.ContextMenuStrip = this.contextMenuStrip1;
            this.picD75.Location = new System.Drawing.Point(138, 420);
            this.picD75.Name = "picD75";
            this.picD75.Size = new System.Drawing.Size(64, 5);
            this.picD75.TabIndex = 80;
            this.picD75.TabStop = false;
            this.picD75.Click += new System.EventHandler(this.picD75_Click);
            // 
            // picD74
            // 
            this.picD74.ContextMenuStrip = this.contextMenuStrip1;
            this.picD74.Location = new System.Drawing.Point(74, 420);
            this.picD74.Name = "picD74";
            this.picD74.Size = new System.Drawing.Size(64, 5);
            this.picD74.TabIndex = 79;
            this.picD74.TabStop = false;
            this.picD74.Click += new System.EventHandler(this.picD74_Click);
            // 
            // picD73
            // 
            this.picD73.ContextMenuStrip = this.contextMenuStrip1;
            this.picD73.Location = new System.Drawing.Point(10, 420);
            this.picD73.Name = "picD73";
            this.picD73.Size = new System.Drawing.Size(64, 5);
            this.picD73.TabIndex = 78;
            this.picD73.TabStop = false;
            this.picD73.Click += new System.EventHandler(this.picD73_Click);
            // 
            // picD72
            // 
            this.picD72.ContextMenuStrip = this.contextMenuStrip1;
            this.picD72.Location = new System.Drawing.Point(458, 413);
            this.picD72.Name = "picD72";
            this.picD72.Size = new System.Drawing.Size(64, 5);
            this.picD72.TabIndex = 77;
            this.picD72.TabStop = false;
            this.picD72.Click += new System.EventHandler(this.picD72_Click);
            // 
            // picD71
            // 
            this.picD71.ContextMenuStrip = this.contextMenuStrip1;
            this.picD71.Location = new System.Drawing.Point(394, 413);
            this.picD71.Name = "picD71";
            this.picD71.Size = new System.Drawing.Size(64, 5);
            this.picD71.TabIndex = 76;
            this.picD71.TabStop = false;
            this.picD71.Click += new System.EventHandler(this.picD71_Click);
            // 
            // picD70
            // 
            this.picD70.ContextMenuStrip = this.contextMenuStrip1;
            this.picD70.Location = new System.Drawing.Point(330, 413);
            this.picD70.Name = "picD70";
            this.picD70.Size = new System.Drawing.Size(64, 5);
            this.picD70.TabIndex = 75;
            this.picD70.TabStop = false;
            this.picD70.Click += new System.EventHandler(this.picD70_Click);
            // 
            // picD69
            // 
            this.picD69.ContextMenuStrip = this.contextMenuStrip1;
            this.picD69.Location = new System.Drawing.Point(266, 413);
            this.picD69.Name = "picD69";
            this.picD69.Size = new System.Drawing.Size(64, 5);
            this.picD69.TabIndex = 74;
            this.picD69.TabStop = false;
            this.picD69.Click += new System.EventHandler(this.picD69_Click);
            // 
            // picD68
            // 
            this.picD68.ContextMenuStrip = this.contextMenuStrip1;
            this.picD68.Location = new System.Drawing.Point(202, 413);
            this.picD68.Name = "picD68";
            this.picD68.Size = new System.Drawing.Size(64, 5);
            this.picD68.TabIndex = 73;
            this.picD68.TabStop = false;
            this.picD68.Click += new System.EventHandler(this.picD68_Click);
            // 
            // picD67
            // 
            this.picD67.ContextMenuStrip = this.contextMenuStrip1;
            this.picD67.Location = new System.Drawing.Point(138, 413);
            this.picD67.Name = "picD67";
            this.picD67.Size = new System.Drawing.Size(64, 5);
            this.picD67.TabIndex = 72;
            this.picD67.TabStop = false;
            this.picD67.Click += new System.EventHandler(this.picD67_Click);
            // 
            // picD66
            // 
            this.picD66.ContextMenuStrip = this.contextMenuStrip1;
            this.picD66.Location = new System.Drawing.Point(74, 413);
            this.picD66.Name = "picD66";
            this.picD66.Size = new System.Drawing.Size(64, 5);
            this.picD66.TabIndex = 71;
            this.picD66.TabStop = false;
            this.picD66.Click += new System.EventHandler(this.picD66_Click);
            // 
            // picD65
            // 
            this.picD65.ContextMenuStrip = this.contextMenuStrip1;
            this.picD65.Location = new System.Drawing.Point(10, 413);
            this.picD65.Name = "picD65";
            this.picD65.Size = new System.Drawing.Size(64, 5);
            this.picD65.TabIndex = 70;
            this.picD65.TabStop = false;
            this.picD65.Click += new System.EventHandler(this.picD65_Click);
            // 
            // picD64
            // 
            this.picD64.ContextMenuStrip = this.contextMenuStrip1;
            this.picD64.Location = new System.Drawing.Point(458, 407);
            this.picD64.Name = "picD64";
            this.picD64.Size = new System.Drawing.Size(64, 5);
            this.picD64.TabIndex = 69;
            this.picD64.TabStop = false;
            this.picD64.Click += new System.EventHandler(this.picD64_Click);
            // 
            // picD63
            // 
            this.picD63.ContextMenuStrip = this.contextMenuStrip1;
            this.picD63.Location = new System.Drawing.Point(394, 407);
            this.picD63.Name = "picD63";
            this.picD63.Size = new System.Drawing.Size(64, 5);
            this.picD63.TabIndex = 68;
            this.picD63.TabStop = false;
            this.picD63.Click += new System.EventHandler(this.picD63_Click);
            // 
            // picD62
            // 
            this.picD62.ContextMenuStrip = this.contextMenuStrip1;
            this.picD62.Location = new System.Drawing.Point(330, 407);
            this.picD62.Name = "picD62";
            this.picD62.Size = new System.Drawing.Size(64, 5);
            this.picD62.TabIndex = 67;
            this.picD62.TabStop = false;
            this.picD62.Click += new System.EventHandler(this.picD62_Click);
            // 
            // picD61
            // 
            this.picD61.ContextMenuStrip = this.contextMenuStrip1;
            this.picD61.Location = new System.Drawing.Point(266, 407);
            this.picD61.Name = "picD61";
            this.picD61.Size = new System.Drawing.Size(64, 5);
            this.picD61.TabIndex = 66;
            this.picD61.TabStop = false;
            this.picD61.Click += new System.EventHandler(this.picD61_Click);
            // 
            // picD60
            // 
            this.picD60.ContextMenuStrip = this.contextMenuStrip1;
            this.picD60.Location = new System.Drawing.Point(202, 407);
            this.picD60.Name = "picD60";
            this.picD60.Size = new System.Drawing.Size(64, 5);
            this.picD60.TabIndex = 65;
            this.picD60.TabStop = false;
            this.picD60.Click += new System.EventHandler(this.picD60_Click);
            // 
            // picD59
            // 
            this.picD59.ContextMenuStrip = this.contextMenuStrip1;
            this.picD59.Location = new System.Drawing.Point(138, 407);
            this.picD59.Name = "picD59";
            this.picD59.Size = new System.Drawing.Size(64, 5);
            this.picD59.TabIndex = 64;
            this.picD59.TabStop = false;
            this.picD59.Click += new System.EventHandler(this.picD59_Click);
            // 
            // picD58
            // 
            this.picD58.ContextMenuStrip = this.contextMenuStrip1;
            this.picD58.Location = new System.Drawing.Point(74, 407);
            this.picD58.Name = "picD58";
            this.picD58.Size = new System.Drawing.Size(64, 5);
            this.picD58.TabIndex = 63;
            this.picD58.TabStop = false;
            this.picD58.Click += new System.EventHandler(this.picD58_Click);
            // 
            // picD57
            // 
            this.picD57.ContextMenuStrip = this.contextMenuStrip1;
            this.picD57.Location = new System.Drawing.Point(10, 407);
            this.picD57.Name = "picD57";
            this.picD57.Size = new System.Drawing.Size(64, 5);
            this.picD57.TabIndex = 62;
            this.picD57.TabStop = false;
            this.picD57.Click += new System.EventHandler(this.picD57_Click);
            // 
            // picD56
            // 
            this.picD56.ContextMenuStrip = this.contextMenuStrip1;
            this.picD56.Location = new System.Drawing.Point(458, 402);
            this.picD56.Name = "picD56";
            this.picD56.Size = new System.Drawing.Size(64, 5);
            this.picD56.TabIndex = 61;
            this.picD56.TabStop = false;
            this.picD56.Click += new System.EventHandler(this.picD56_Click);
            // 
            // picD55
            // 
            this.picD55.ContextMenuStrip = this.contextMenuStrip1;
            this.picD55.Location = new System.Drawing.Point(394, 402);
            this.picD55.Name = "picD55";
            this.picD55.Size = new System.Drawing.Size(64, 5);
            this.picD55.TabIndex = 60;
            this.picD55.TabStop = false;
            this.picD55.Click += new System.EventHandler(this.picD55_Click);
            // 
            // picD54
            // 
            this.picD54.ContextMenuStrip = this.contextMenuStrip1;
            this.picD54.Location = new System.Drawing.Point(330, 402);
            this.picD54.Name = "picD54";
            this.picD54.Size = new System.Drawing.Size(64, 5);
            this.picD54.TabIndex = 59;
            this.picD54.TabStop = false;
            this.picD54.Click += new System.EventHandler(this.picD54_Click);
            // 
            // picD53
            // 
            this.picD53.ContextMenuStrip = this.contextMenuStrip1;
            this.picD53.Location = new System.Drawing.Point(266, 402);
            this.picD53.Name = "picD53";
            this.picD53.Size = new System.Drawing.Size(64, 5);
            this.picD53.TabIndex = 58;
            this.picD53.TabStop = false;
            this.picD53.Click += new System.EventHandler(this.picD53_Click);
            // 
            // picD52
            // 
            this.picD52.ContextMenuStrip = this.contextMenuStrip1;
            this.picD52.Location = new System.Drawing.Point(202, 402);
            this.picD52.Name = "picD52";
            this.picD52.Size = new System.Drawing.Size(64, 5);
            this.picD52.TabIndex = 57;
            this.picD52.TabStop = false;
            this.picD52.Click += new System.EventHandler(this.picD52_Click);
            // 
            // picD51
            // 
            this.picD51.ContextMenuStrip = this.contextMenuStrip1;
            this.picD51.Location = new System.Drawing.Point(138, 402);
            this.picD51.Name = "picD51";
            this.picD51.Size = new System.Drawing.Size(64, 5);
            this.picD51.TabIndex = 56;
            this.picD51.TabStop = false;
            this.picD51.Click += new System.EventHandler(this.picD51_Click);
            // 
            // picD50
            // 
            this.picD50.ContextMenuStrip = this.contextMenuStrip1;
            this.picD50.Location = new System.Drawing.Point(74, 402);
            this.picD50.Name = "picD50";
            this.picD50.Size = new System.Drawing.Size(64, 5);
            this.picD50.TabIndex = 55;
            this.picD50.TabStop = false;
            this.picD50.Click += new System.EventHandler(this.picD50_Click);
            // 
            // picD49
            // 
            this.picD49.ContextMenuStrip = this.contextMenuStrip1;
            this.picD49.Location = new System.Drawing.Point(10, 402);
            this.picD49.Name = "picD49";
            this.picD49.Size = new System.Drawing.Size(64, 5);
            this.picD49.TabIndex = 54;
            this.picD49.TabStop = false;
            this.picD49.Click += new System.EventHandler(this.picD49_Click);
            // 
            // picD48
            // 
            this.picD48.ContextMenuStrip = this.contextMenuStrip1;
            this.picD48.Location = new System.Drawing.Point(458, 338);
            this.picD48.Name = "picD48";
            this.picD48.Size = new System.Drawing.Size(64, 64);
            this.picD48.TabIndex = 53;
            this.picD48.TabStop = false;
            this.picD48.Click += new System.EventHandler(this.picD48_Click);
            // 
            // picD47
            // 
            this.picD47.ContextMenuStrip = this.contextMenuStrip1;
            this.picD47.Location = new System.Drawing.Point(394, 338);
            this.picD47.Name = "picD47";
            this.picD47.Size = new System.Drawing.Size(64, 64);
            this.picD47.TabIndex = 52;
            this.picD47.TabStop = false;
            this.picD47.Click += new System.EventHandler(this.picD47_Click);
            // 
            // picD46
            // 
            this.picD46.ContextMenuStrip = this.contextMenuStrip1;
            this.picD46.Location = new System.Drawing.Point(330, 338);
            this.picD46.Name = "picD46";
            this.picD46.Size = new System.Drawing.Size(64, 64);
            this.picD46.TabIndex = 51;
            this.picD46.TabStop = false;
            this.picD46.Click += new System.EventHandler(this.picD46_Click);
            // 
            // picD45
            // 
            this.picD45.ContextMenuStrip = this.contextMenuStrip1;
            this.picD45.Location = new System.Drawing.Point(266, 338);
            this.picD45.Name = "picD45";
            this.picD45.Size = new System.Drawing.Size(64, 64);
            this.picD45.TabIndex = 50;
            this.picD45.TabStop = false;
            this.picD45.Click += new System.EventHandler(this.picD45_Click);
            // 
            // picD44
            // 
            this.picD44.ContextMenuStrip = this.contextMenuStrip1;
            this.picD44.Location = new System.Drawing.Point(202, 338);
            this.picD44.Name = "picD44";
            this.picD44.Size = new System.Drawing.Size(64, 64);
            this.picD44.TabIndex = 49;
            this.picD44.TabStop = false;
            this.picD44.Click += new System.EventHandler(this.picD44_Click);
            // 
            // picD43
            // 
            this.picD43.ContextMenuStrip = this.contextMenuStrip1;
            this.picD43.Location = new System.Drawing.Point(138, 338);
            this.picD43.Name = "picD43";
            this.picD43.Size = new System.Drawing.Size(64, 64);
            this.picD43.TabIndex = 48;
            this.picD43.TabStop = false;
            this.picD43.Click += new System.EventHandler(this.picD43_Click);
            // 
            // picD42
            // 
            this.picD42.ContextMenuStrip = this.contextMenuStrip1;
            this.picD42.Location = new System.Drawing.Point(74, 338);
            this.picD42.Name = "picD42";
            this.picD42.Size = new System.Drawing.Size(64, 64);
            this.picD42.TabIndex = 47;
            this.picD42.TabStop = false;
            this.picD42.Click += new System.EventHandler(this.picD42_Click);
            // 
            // picD41
            // 
            this.picD41.ContextMenuStrip = this.contextMenuStrip1;
            this.picD41.Location = new System.Drawing.Point(10, 338);
            this.picD41.Name = "picD41";
            this.picD41.Size = new System.Drawing.Size(64, 64);
            this.picD41.TabIndex = 46;
            this.picD41.TabStop = false;
            this.picD41.Click += new System.EventHandler(this.picD41_Click);
            // 
            // picD40
            // 
            this.picD40.ContextMenuStrip = this.contextMenuStrip1;
            this.picD40.Location = new System.Drawing.Point(458, 274);
            this.picD40.Name = "picD40";
            this.picD40.Size = new System.Drawing.Size(64, 64);
            this.picD40.TabIndex = 45;
            this.picD40.TabStop = false;
            this.picD40.Click += new System.EventHandler(this.picD40_Click);
            // 
            // picD39
            // 
            this.picD39.ContextMenuStrip = this.contextMenuStrip1;
            this.picD39.Location = new System.Drawing.Point(394, 274);
            this.picD39.Name = "picD39";
            this.picD39.Size = new System.Drawing.Size(64, 64);
            this.picD39.TabIndex = 44;
            this.picD39.TabStop = false;
            this.picD39.Click += new System.EventHandler(this.picD39_Click);
            // 
            // picD38
            // 
            this.picD38.ContextMenuStrip = this.contextMenuStrip1;
            this.picD38.Location = new System.Drawing.Point(330, 274);
            this.picD38.Name = "picD38";
            this.picD38.Size = new System.Drawing.Size(64, 64);
            this.picD38.TabIndex = 43;
            this.picD38.TabStop = false;
            this.picD38.Click += new System.EventHandler(this.picD38_Click);
            // 
            // picD37
            // 
            this.picD37.ContextMenuStrip = this.contextMenuStrip1;
            this.picD37.Location = new System.Drawing.Point(266, 274);
            this.picD37.Name = "picD37";
            this.picD37.Size = new System.Drawing.Size(64, 64);
            this.picD37.TabIndex = 42;
            this.picD37.TabStop = false;
            this.picD37.Click += new System.EventHandler(this.picD37_Click);
            // 
            // picD36
            // 
            this.picD36.ContextMenuStrip = this.contextMenuStrip1;
            this.picD36.Location = new System.Drawing.Point(202, 274);
            this.picD36.Name = "picD36";
            this.picD36.Size = new System.Drawing.Size(64, 64);
            this.picD36.TabIndex = 41;
            this.picD36.TabStop = false;
            this.picD36.Click += new System.EventHandler(this.picD36_Click);
            // 
            // picD35
            // 
            this.picD35.ContextMenuStrip = this.contextMenuStrip1;
            this.picD35.Location = new System.Drawing.Point(138, 274);
            this.picD35.Name = "picD35";
            this.picD35.Size = new System.Drawing.Size(64, 64);
            this.picD35.TabIndex = 40;
            this.picD35.TabStop = false;
            this.picD35.Click += new System.EventHandler(this.picD35_Click);
            // 
            // picD34
            // 
            this.picD34.ContextMenuStrip = this.contextMenuStrip1;
            this.picD34.Location = new System.Drawing.Point(74, 274);
            this.picD34.Name = "picD34";
            this.picD34.Size = new System.Drawing.Size(64, 64);
            this.picD34.TabIndex = 39;
            this.picD34.TabStop = false;
            this.picD34.Click += new System.EventHandler(this.picD34_Click);
            // 
            // picD33
            // 
            this.picD33.ContextMenuStrip = this.contextMenuStrip1;
            this.picD33.Location = new System.Drawing.Point(10, 274);
            this.picD33.Name = "picD33";
            this.picD33.Size = new System.Drawing.Size(64, 64);
            this.picD33.TabIndex = 38;
            this.picD33.TabStop = false;
            this.picD33.Click += new System.EventHandler(this.picD33_Click);
            // 
            // picD32
            // 
            this.picD32.ContextMenuStrip = this.contextMenuStrip1;
            this.picD32.Location = new System.Drawing.Point(458, 210);
            this.picD32.Name = "picD32";
            this.picD32.Size = new System.Drawing.Size(64, 64);
            this.picD32.TabIndex = 37;
            this.picD32.TabStop = false;
            this.picD32.Click += new System.EventHandler(this.picD32_Click);
            // 
            // picD31
            // 
            this.picD31.ContextMenuStrip = this.contextMenuStrip1;
            this.picD31.Location = new System.Drawing.Point(394, 210);
            this.picD31.Name = "picD31";
            this.picD31.Size = new System.Drawing.Size(64, 64);
            this.picD31.TabIndex = 36;
            this.picD31.TabStop = false;
            this.picD31.Click += new System.EventHandler(this.picD31_Click);
            // 
            // picD30
            // 
            this.picD30.ContextMenuStrip = this.contextMenuStrip1;
            this.picD30.Location = new System.Drawing.Point(330, 210);
            this.picD30.Name = "picD30";
            this.picD30.Size = new System.Drawing.Size(64, 64);
            this.picD30.TabIndex = 35;
            this.picD30.TabStop = false;
            this.picD30.Click += new System.EventHandler(this.picD30_Click);
            // 
            // picD29
            // 
            this.picD29.ContextMenuStrip = this.contextMenuStrip1;
            this.picD29.Location = new System.Drawing.Point(266, 210);
            this.picD29.Name = "picD29";
            this.picD29.Size = new System.Drawing.Size(64, 64);
            this.picD29.TabIndex = 34;
            this.picD29.TabStop = false;
            this.picD29.Click += new System.EventHandler(this.picD29_Click);
            // 
            // picD28
            // 
            this.picD28.ContextMenuStrip = this.contextMenuStrip1;
            this.picD28.Location = new System.Drawing.Point(202, 210);
            this.picD28.Name = "picD28";
            this.picD28.Size = new System.Drawing.Size(64, 64);
            this.picD28.TabIndex = 33;
            this.picD28.TabStop = false;
            this.picD28.Click += new System.EventHandler(this.picD28_Click);
            // 
            // picD27
            // 
            this.picD27.ContextMenuStrip = this.contextMenuStrip1;
            this.picD27.Location = new System.Drawing.Point(138, 210);
            this.picD27.Name = "picD27";
            this.picD27.Size = new System.Drawing.Size(64, 64);
            this.picD27.TabIndex = 32;
            this.picD27.TabStop = false;
            this.picD27.Click += new System.EventHandler(this.picD27_Click);
            // 
            // picD26
            // 
            this.picD26.ContextMenuStrip = this.contextMenuStrip1;
            this.picD26.Location = new System.Drawing.Point(74, 210);
            this.picD26.Name = "picD26";
            this.picD26.Size = new System.Drawing.Size(64, 64);
            this.picD26.TabIndex = 31;
            this.picD26.TabStop = false;
            this.picD26.Click += new System.EventHandler(this.picD26_Click);
            // 
            // picD25
            // 
            this.picD25.ContextMenuStrip = this.contextMenuStrip1;
            this.picD25.Location = new System.Drawing.Point(10, 210);
            this.picD25.Name = "picD25";
            this.picD25.Size = new System.Drawing.Size(64, 64);
            this.picD25.TabIndex = 30;
            this.picD25.TabStop = false;
            this.picD25.Click += new System.EventHandler(this.picD25_Click);
            // 
            // picD24
            // 
            this.picD24.ContextMenuStrip = this.contextMenuStrip1;
            this.picD24.Location = new System.Drawing.Point(458, 146);
            this.picD24.Name = "picD24";
            this.picD24.Size = new System.Drawing.Size(64, 64);
            this.picD24.TabIndex = 29;
            this.picD24.TabStop = false;
            this.picD24.Click += new System.EventHandler(this.picD24_Click);
            // 
            // picD23
            // 
            this.picD23.ContextMenuStrip = this.contextMenuStrip1;
            this.picD23.Location = new System.Drawing.Point(394, 146);
            this.picD23.Name = "picD23";
            this.picD23.Size = new System.Drawing.Size(64, 64);
            this.picD23.TabIndex = 28;
            this.picD23.TabStop = false;
            this.picD23.Click += new System.EventHandler(this.picD23_Click);
            // 
            // picD22
            // 
            this.picD22.ContextMenuStrip = this.contextMenuStrip1;
            this.picD22.Location = new System.Drawing.Point(330, 146);
            this.picD22.Name = "picD22";
            this.picD22.Size = new System.Drawing.Size(64, 64);
            this.picD22.TabIndex = 27;
            this.picD22.TabStop = false;
            this.picD22.Click += new System.EventHandler(this.picD22_Click);
            // 
            // picD21
            // 
            this.picD21.ContextMenuStrip = this.contextMenuStrip1;
            this.picD21.Location = new System.Drawing.Point(266, 146);
            this.picD21.Name = "picD21";
            this.picD21.Size = new System.Drawing.Size(64, 64);
            this.picD21.TabIndex = 26;
            this.picD21.TabStop = false;
            this.picD21.Click += new System.EventHandler(this.picD21_Click);
            // 
            // picD20
            // 
            this.picD20.ContextMenuStrip = this.contextMenuStrip1;
            this.picD20.Location = new System.Drawing.Point(202, 146);
            this.picD20.Name = "picD20";
            this.picD20.Size = new System.Drawing.Size(64, 64);
            this.picD20.TabIndex = 25;
            this.picD20.TabStop = false;
            this.picD20.Click += new System.EventHandler(this.picD20_Click);
            // 
            // picD19
            // 
            this.picD19.ContextMenuStrip = this.contextMenuStrip1;
            this.picD19.Location = new System.Drawing.Point(138, 146);
            this.picD19.Name = "picD19";
            this.picD19.Size = new System.Drawing.Size(64, 64);
            this.picD19.TabIndex = 24;
            this.picD19.TabStop = false;
            this.picD19.Click += new System.EventHandler(this.picD19_Click);
            // 
            // picD18
            // 
            this.picD18.ContextMenuStrip = this.contextMenuStrip1;
            this.picD18.Location = new System.Drawing.Point(74, 146);
            this.picD18.Name = "picD18";
            this.picD18.Size = new System.Drawing.Size(64, 64);
            this.picD18.TabIndex = 23;
            this.picD18.TabStop = false;
            this.picD18.Click += new System.EventHandler(this.picD18_Click);
            // 
            // picD17
            // 
            this.picD17.ContextMenuStrip = this.contextMenuStrip1;
            this.picD17.Location = new System.Drawing.Point(10, 146);
            this.picD17.Name = "picD17";
            this.picD17.Size = new System.Drawing.Size(64, 64);
            this.picD17.TabIndex = 22;
            this.picD17.TabStop = false;
            this.picD17.Click += new System.EventHandler(this.picD17_Click);
            // 
            // picD16
            // 
            this.picD16.ContextMenuStrip = this.contextMenuStrip1;
            this.picD16.Location = new System.Drawing.Point(458, 82);
            this.picD16.Name = "picD16";
            this.picD16.Size = new System.Drawing.Size(64, 64);
            this.picD16.TabIndex = 21;
            this.picD16.TabStop = false;
            this.picD16.Click += new System.EventHandler(this.picD16_Click);
            // 
            // picD15
            // 
            this.picD15.ContextMenuStrip = this.contextMenuStrip1;
            this.picD15.Location = new System.Drawing.Point(394, 82);
            this.picD15.Name = "picD15";
            this.picD15.Size = new System.Drawing.Size(64, 64);
            this.picD15.TabIndex = 20;
            this.picD15.TabStop = false;
            this.picD15.Click += new System.EventHandler(this.picD15_Click);
            // 
            // picD14
            // 
            this.picD14.ContextMenuStrip = this.contextMenuStrip1;
            this.picD14.Location = new System.Drawing.Point(330, 82);
            this.picD14.Name = "picD14";
            this.picD14.Size = new System.Drawing.Size(64, 64);
            this.picD14.TabIndex = 19;
            this.picD14.TabStop = false;
            this.picD14.Click += new System.EventHandler(this.picD14_Click);
            // 
            // picD13
            // 
            this.picD13.ContextMenuStrip = this.contextMenuStrip1;
            this.picD13.Location = new System.Drawing.Point(266, 82);
            this.picD13.Name = "picD13";
            this.picD13.Size = new System.Drawing.Size(64, 64);
            this.picD13.TabIndex = 18;
            this.picD13.TabStop = false;
            this.picD13.Click += new System.EventHandler(this.picD13_Click);
            // 
            // picD12
            // 
            this.picD12.ContextMenuStrip = this.contextMenuStrip1;
            this.picD12.Location = new System.Drawing.Point(202, 82);
            this.picD12.Name = "picD12";
            this.picD12.Size = new System.Drawing.Size(64, 64);
            this.picD12.TabIndex = 17;
            this.picD12.TabStop = false;
            this.picD12.Click += new System.EventHandler(this.picD12_Click);
            // 
            // picD11
            // 
            this.picD11.ContextMenuStrip = this.contextMenuStrip1;
            this.picD11.Location = new System.Drawing.Point(138, 82);
            this.picD11.Name = "picD11";
            this.picD11.Size = new System.Drawing.Size(64, 64);
            this.picD11.TabIndex = 16;
            this.picD11.TabStop = false;
            this.picD11.Click += new System.EventHandler(this.picD11_Click);
            // 
            // picD10
            // 
            this.picD10.ContextMenuStrip = this.contextMenuStrip1;
            this.picD10.Location = new System.Drawing.Point(74, 82);
            this.picD10.Name = "picD10";
            this.picD10.Size = new System.Drawing.Size(64, 64);
            this.picD10.TabIndex = 15;
            this.picD10.TabStop = false;
            this.picD10.Click += new System.EventHandler(this.picD10_Click);
            // 
            // picD09
            // 
            this.picD09.ContextMenuStrip = this.contextMenuStrip1;
            this.picD09.Location = new System.Drawing.Point(10, 82);
            this.picD09.Name = "picD09";
            this.picD09.Size = new System.Drawing.Size(64, 64);
            this.picD09.TabIndex = 14;
            this.picD09.TabStop = false;
            this.picD09.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // picD08
            // 
            this.picD08.ContextMenuStrip = this.contextMenuStrip1;
            this.picD08.Location = new System.Drawing.Point(458, 18);
            this.picD08.Name = "picD08";
            this.picD08.Size = new System.Drawing.Size(64, 64);
            this.picD08.TabIndex = 13;
            this.picD08.TabStop = false;
            this.picD08.Click += new System.EventHandler(this.picD08_Click);
            // 
            // picD07
            // 
            this.picD07.ContextMenuStrip = this.contextMenuStrip1;
            this.picD07.Location = new System.Drawing.Point(394, 18);
            this.picD07.Name = "picD07";
            this.picD07.Size = new System.Drawing.Size(64, 64);
            this.picD07.TabIndex = 12;
            this.picD07.TabStop = false;
            this.picD07.Click += new System.EventHandler(this.picD07_Click);
            // 
            // picD06
            // 
            this.picD06.ContextMenuStrip = this.contextMenuStrip1;
            this.picD06.Location = new System.Drawing.Point(330, 18);
            this.picD06.Name = "picD06";
            this.picD06.Size = new System.Drawing.Size(64, 64);
            this.picD06.TabIndex = 11;
            this.picD06.TabStop = false;
            this.picD06.Click += new System.EventHandler(this.picD06_Click);
            // 
            // picD05
            // 
            this.picD05.ContextMenuStrip = this.contextMenuStrip1;
            this.picD05.Location = new System.Drawing.Point(266, 18);
            this.picD05.Name = "picD05";
            this.picD05.Size = new System.Drawing.Size(64, 64);
            this.picD05.TabIndex = 10;
            this.picD05.TabStop = false;
            this.picD05.Click += new System.EventHandler(this.picD05_Click);
            // 
            // picD04
            // 
            this.picD04.ContextMenuStrip = this.contextMenuStrip1;
            this.picD04.Location = new System.Drawing.Point(202, 18);
            this.picD04.Name = "picD04";
            this.picD04.Size = new System.Drawing.Size(64, 64);
            this.picD04.TabIndex = 9;
            this.picD04.TabStop = false;
            this.picD04.Click += new System.EventHandler(this.picD04_Click);
            // 
            // picD03
            // 
            this.picD03.ContextMenuStrip = this.contextMenuStrip1;
            this.picD03.Location = new System.Drawing.Point(138, 18);
            this.picD03.Name = "picD03";
            this.picD03.Size = new System.Drawing.Size(64, 64);
            this.picD03.TabIndex = 8;
            this.picD03.TabStop = false;
            this.picD03.Click += new System.EventHandler(this.picD03_Click);
            // 
            // picD02
            // 
            this.picD02.ContextMenuStrip = this.contextMenuStrip1;
            this.picD02.Location = new System.Drawing.Point(74, 18);
            this.picD02.Name = "picD02";
            this.picD02.Size = new System.Drawing.Size(64, 64);
            this.picD02.TabIndex = 7;
            this.picD02.TabStop = false;
            this.picD02.Click += new System.EventHandler(this.picD02_Click);
            // 
            // picD01
            // 
            this.picD01.ContextMenuStrip = this.contextMenuStrip1;
            this.picD01.Location = new System.Drawing.Point(10, 18);
            this.picD01.Name = "picD01";
            this.picD01.Size = new System.Drawing.Size(64, 64);
            this.picD01.TabIndex = 6;
            this.picD01.TabStop = false;
            this.picD01.Click += new System.EventHandler(this.picD01_Click);
            // 
            // cmbBackColor
            // 
            this.cmbBackColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBackColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbBackColor.FormattingEnabled = true;
            this.cmbBackColor.Location = new System.Drawing.Point(78, 6);
            this.cmbBackColor.Name = "cmbBackColor";
            this.cmbBackColor.Size = new System.Drawing.Size(158, 20);
            this.cmbBackColor.TabIndex = 3;
            this.cmbBackColor.SelectedIndexChanged += new System.EventHandler(this.cmbBackColor_SelectedIndexChanged);
            // 
            // txtInfo
            // 
            this.txtInfo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtInfo.Location = new System.Drawing.Point(2, 342);
            this.txtInfo.Multiline = true;
            this.txtInfo.Name = "txtInfo";
            this.txtInfo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtInfo.Size = new System.Drawing.Size(186, 101);
            this.txtInfo.TabIndex = 22;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // GDOTCH00
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(814, 447);
            this.Controls.Add(this.txtInfo);
            this.Controls.Add(this.cmbBackColor);
            this.Controls.Add(this.grpDOT);
            this.Controls.Add(this.cmbP2);
            this.Controls.Add(this.cmbP1);
            this.Controls.Add(this.btnCHANGE);
            this.Controls.Add(this.picOriginal);
            this.Controls.Add(this.btnLoad);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "GDOTCH00";
            this.Text = "GDOTCH00 : DOTCHAN";
            this.Load += new System.EventHandler(this.GDOTCH00_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picOriginal)).EndInit();
            this.grpDOT.ResumeLayout(false);
            this.contextMenuStrip2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picD88)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picD87)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD86)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD85)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD84)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD83)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD82)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD81)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD80)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD79)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD78)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD77)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD76)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD75)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD74)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD73)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD72)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD71)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD70)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD69)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD68)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD67)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD66)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD65)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD64)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD63)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD62)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD60)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD59)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD58)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD57)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD49)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD09)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD08)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD07)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD06)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD05)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD04)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picD01)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.PictureBox picOriginal;
        internal System.Windows.Forms.PictureBox picD01;
        internal System.Windows.Forms.PictureBox picD02;
        internal System.Windows.Forms.PictureBox picD03;
        internal System.Windows.Forms.PictureBox picD04;
        internal System.Windows.Forms.PictureBox picD05;
        internal System.Windows.Forms.PictureBox picD06;
        internal System.Windows.Forms.PictureBox picD07;
        internal System.Windows.Forms.PictureBox picD08;
        internal System.Windows.Forms.PictureBox picD09;
        internal System.Windows.Forms.PictureBox picD15;
        internal System.Windows.Forms.PictureBox picD14;
        internal System.Windows.Forms.PictureBox picD13;
        internal System.Windows.Forms.PictureBox picD12;
        internal System.Windows.Forms.PictureBox picD11;
        internal System.Windows.Forms.PictureBox picD10;
        internal System.Windows.Forms.PictureBox picD16;
        internal System.Windows.Forms.PictureBox picD20;
        internal System.Windows.Forms.PictureBox picD19;
        internal System.Windows.Forms.PictureBox picD18;
        internal System.Windows.Forms.PictureBox picD17;
        internal System.Windows.Forms.PictureBox picD30;
        internal System.Windows.Forms.PictureBox picD29;
        internal System.Windows.Forms.PictureBox picD28;
        internal System.Windows.Forms.PictureBox picD27;
        internal System.Windows.Forms.PictureBox picD26;
        internal System.Windows.Forms.PictureBox picD25;
        internal System.Windows.Forms.PictureBox picD24;
        internal System.Windows.Forms.PictureBox picD23;
        internal System.Windows.Forms.PictureBox picD22;
        internal System.Windows.Forms.PictureBox picD21;
        internal System.Windows.Forms.PictureBox picD35;
        internal System.Windows.Forms.PictureBox picD34;
        internal System.Windows.Forms.PictureBox picD33;
        internal System.Windows.Forms.PictureBox picD32;
        internal System.Windows.Forms.PictureBox picD31;
        internal System.Windows.Forms.PictureBox picD64;
        internal System.Windows.Forms.PictureBox picD63;
        internal System.Windows.Forms.PictureBox picD62;
        internal System.Windows.Forms.PictureBox picD61;
        internal System.Windows.Forms.PictureBox picD60;
        internal System.Windows.Forms.PictureBox picD59;
        internal System.Windows.Forms.PictureBox picD58;
        internal System.Windows.Forms.PictureBox picD57;
        internal System.Windows.Forms.PictureBox picD56;
        internal System.Windows.Forms.PictureBox picD55;
        internal System.Windows.Forms.PictureBox picD54;
        internal System.Windows.Forms.PictureBox picD53;
        internal System.Windows.Forms.PictureBox picD52;
        internal System.Windows.Forms.PictureBox picD51;
        internal System.Windows.Forms.PictureBox picD50;
        internal System.Windows.Forms.PictureBox picD49;
        internal System.Windows.Forms.PictureBox picD48;
        internal System.Windows.Forms.PictureBox picD47;
        internal System.Windows.Forms.PictureBox picD46;
        internal System.Windows.Forms.PictureBox picD45;
        internal System.Windows.Forms.PictureBox picD44;
        internal System.Windows.Forms.PictureBox picD43;
        internal System.Windows.Forms.PictureBox picD42;
        internal System.Windows.Forms.PictureBox picD41;
        internal System.Windows.Forms.PictureBox picD40;
        internal System.Windows.Forms.PictureBox picD39;
        internal System.Windows.Forms.PictureBox picD38;
        internal System.Windows.Forms.PictureBox picD37;
        internal System.Windows.Forms.PictureBox picD36;
        internal System.Windows.Forms.PictureBox picD80;
        internal System.Windows.Forms.PictureBox picD79;
        internal System.Windows.Forms.PictureBox picD78;
        internal System.Windows.Forms.PictureBox picD77;
        internal System.Windows.Forms.PictureBox picD76;
        internal System.Windows.Forms.PictureBox picD75;
        internal System.Windows.Forms.PictureBox picD74;
        internal System.Windows.Forms.PictureBox picD73;
        internal System.Windows.Forms.PictureBox picD72;
        internal System.Windows.Forms.PictureBox picD71;
        internal System.Windows.Forms.PictureBox picD70;
        internal System.Windows.Forms.PictureBox picD69;
        internal System.Windows.Forms.PictureBox picD68;
        internal System.Windows.Forms.PictureBox picD67;
        internal System.Windows.Forms.PictureBox picD66;
        internal System.Windows.Forms.PictureBox picD65;
        internal System.Windows.Forms.PictureBox picD88;
        internal System.Windows.Forms.PictureBox picD87;
        internal System.Windows.Forms.PictureBox picD86;
        internal System.Windows.Forms.PictureBox picD85;
        internal System.Windows.Forms.PictureBox picD84;
        internal System.Windows.Forms.PictureBox picD83;
        internal System.Windows.Forms.PictureBox picD82;
        internal System.Windows.Forms.PictureBox picD81;
        private System.Windows.Forms.Button btnCHANGE;
        private System.Windows.Forms.ComboBox cmbP1;
        private System.Windows.Forms.ComboBox cmbP2;
        private System.Windows.Forms.GroupBox grpDOT;
        private System.Windows.Forms.ComboBox cmbBackColor;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem clearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.TextBox txtInfo;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem zoomToolStripMenuItem;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem clearAllStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rearrangeToolStripMenuItem;
        private System.Windows.Forms.Button btnOpt;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
    }
}

