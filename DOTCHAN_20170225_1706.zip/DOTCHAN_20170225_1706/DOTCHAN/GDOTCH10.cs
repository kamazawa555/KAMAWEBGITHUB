﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace DOTCHAN
{
    public partial class GDOTCH10 : Form
    {
        private Bitmap mo_canvas;
        private bool mb_mouse_down = false;
        private Point mo_orinal_point;
        private Form mo_owner_form;
        private Color mo_current_color;
        private int mi_current_number;

        public GDOTCH10(GDOTCH00 f)
        {
            mo_owner_form = f;
            InitializeComponent();
        }

        private void GDOTCH10_Load(object sender, EventArgs e)
        {
            M0_Initialize_Form();
        }

        private void M0_Initialize_Form()
        {
            picView.Parent = pnlView;
            picView.Top = 0;
            picView.Left = 0;
            picView.Width = pnlView.Width;
            picView.Height = pnlView.Height;
        }

        public void setNumber(int i) {
            mi_current_number = i;
        }

        public void setBmp(Bitmap po_bmp)
        {
            if (po_bmp == null) { return; }
            M0_setBmp(po_bmp);
            mo_current_color = this.BackColor;
            M0_Draw_Line(mo_current_color);
        }

        private void M0_setBmp(Bitmap po_bmp)
        {
            if (po_bmp == null) { return; }
            int li_new_width = po_bmp.Width * 16;
            int li_new_height = po_bmp.Height * 16;
            mo_canvas = new Bitmap(li_new_width, li_new_height);
            Graphics g = Graphics.FromImage(mo_canvas);
            g.InterpolationMode =
                System.Drawing.Drawing2D.InterpolationMode.NearestNeighbor;
            g.DrawImage(po_bmp, 0, 0, li_new_width, li_new_height);
            g.Dispose();
            picView.Image = mo_canvas;
            string ls_picD = "picD" + (mi_current_number).ToString("00");
            string ls_size = "(" + po_bmp.Width.ToString() + "x" + po_bmp.Height.ToString() + ")";
            this.Text = this.Name + " : " + ls_picD +" "+ ls_size;
        }

        private void M0_Draw_Line(Color pc_color)
        {
            Pen p = new Pen(pc_color, 1);
            Graphics g = Graphics.FromImage(mo_canvas);
            for (int i = 8; i <= mo_canvas.Height; i = i + 16)
            {
                g.DrawLine(p, 0, i, mo_canvas.Width - 8, i);
            }
            for (int i = 8; i <= mo_canvas.Width; i = i + 16)
            {
                g.DrawLine(p, i, 0, i, mo_canvas.Height - 8);
            }
            g.Dispose();
            picView.Image = mo_canvas;
        }

        private void contextMenuStrip1_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Control source = contextMenuStrip1.SourceControl;
            if (source != null)
            {
                M0_Save_DotImage((PictureBox)source);
            }
        }

        private void M0_Save_DotImage(PictureBox picD)
        {
            if (picD.Image == null) { return; }
            saveFileDialog1.Filter = "Png Image|*.png|Jpeg Image|*.jpg|Bmp Image|*.bmp";
            saveFileDialog1.FilterIndex = 1;
            saveFileDialog1.FileName = ".png";
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string ls_extension = System.IO.Path.GetExtension(saveFileDialog1.FileName);
                switch (ls_extension.ToUpper())
                {
                    case ".JPG":
                        picD.Image.Save(saveFileDialog1.FileName);
                        break;
                    case ".PNG":
                        picD.Image.Save(saveFileDialog1.FileName);
                        break;
                    case ".BMP":
                        picD.Image.Save(saveFileDialog1.FileName);
                        break;
                }
            }
        }

        private void backgroundToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mo_current_color = this.BackColor;
            M0_Draw_Line(mo_current_color);
        }

        private void whiteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mo_current_color = Color.White;
            M0_Draw_Line(mo_current_color);
        }

        private void blackToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mo_current_color = Color.Black;
            M0_Draw_Line(mo_current_color);
        }

        private void blueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mo_current_color = Color.Blue;
            M0_Draw_Line(mo_current_color);
        }

        private void redToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mo_current_color = Color.Red;
            M0_Draw_Line(mo_current_color);
        }

        private void greenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mo_current_color = Color.Green;
            M0_Draw_Line(mo_current_color);
        }

        private void yellowToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mo_current_color = Color.Yellow;
            M0_Draw_Line(mo_current_color);
        }

        private void pinkToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mo_current_color = Color.Pink;
            M0_Draw_Line(mo_current_color);
        }

        private void nextImageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            M0_Get_Parent_Next_Bmp();
        }

        private void previousImageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            M0_Get_Parent_Previous_Bmp();
        }

        private void M1_Previous_or_Next( int pi_d )
        {
            int li_searched = -1;
            string ls_picD;
            for (int i = mi_current_number + pi_d; ( 0 < i && i < 88); i = i + pi_d)
            {
                ls_picD = "picD" + (i).ToString("00");
                PictureBox lo_picD = (PictureBox)mo_owner_form.Controls["grpDOT"].Controls[ls_picD];
                if ( lo_picD.Image != null )
                {
                    //Console.WriteLine("Searched:" + i.ToString());
                    li_searched = i;
                    break;
                }
            }
            if ( li_searched > 0 )
            {
                mi_current_number = li_searched;
            }
        }

        private void M0_Get_Parent_Next_Bmp()
        {
            M1_Previous_or_Next(+1);
            string ls_picD = "picD" + (mi_current_number).ToString("00");
            M1_Set_Parent_Bmp(ls_picD);
        }

        private void M0_Get_Parent_Previous_Bmp()
        {
            M1_Previous_or_Next(-1);
            string ls_picD = "picD" + (mi_current_number).ToString("00");
            M1_Set_Parent_Bmp(ls_picD);
        }

        private void M1_Set_Parent_Bmp(string ps_picD)
        {
            PictureBox lo_picD = (PictureBox)mo_owner_form.Controls["grpDOT"].Controls[ps_picD];
            if (lo_picD == null) { return; }
            if (lo_picD.Image == null) {
                return;
            }
            Bitmap lo_bmp = (Bitmap)lo_picD.Image;
            M0_setBmp(lo_bmp);
            M0_Draw_Line(mo_current_color);
        } 

        private void picView_MouseDown(object sender, MouseEventArgs e)
        {
            mo_orinal_point = picView.Parent.PointToScreen(e.Location);
            Cursor.Current = Cursors.Cross;
            mb_mouse_down = true;
        }

        private void picView_MouseUp(object sender, MouseEventArgs e)
        {
            mb_mouse_down = false;
            Cursor.Current = Cursors.Default;
        }

        private void picView_MouseMove(object sender, MouseEventArgs e)
        {
            if (mb_mouse_down)
            {
                var current = picView.PointToScreen(e.Location);
                int x = current.X - mo_orinal_point.X;
                int y = current.Y - mo_orinal_point.Y;
                pnlView.AutoScrollPosition = new Point(-x, -y);
            }
        }

        private void GDOTCH10_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Right || e.KeyCode == Keys.Down)
            {
                M0_Get_Parent_Next_Bmp();
            }
            else if (e.KeyCode == Keys.Left || e.KeyCode == Keys.Up)
            {
                M0_Get_Parent_Previous_Bmp();
            }
        }

    }
}
