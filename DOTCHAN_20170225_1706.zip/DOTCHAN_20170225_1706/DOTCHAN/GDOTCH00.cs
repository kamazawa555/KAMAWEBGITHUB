﻿using System;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

namespace DOTCHAN
{
    public partial class GDOTCH00 : Form
    {
        private ToolTip mo_tooltip;
        private string[] ms_picDotImages;
        private string ms_OriginalFileInfo = "";
        public string ms_Current_PicD = "";
        static int CMI_MIN_WIDTH = 10;
        static int CMI_MAX_WIDTH = 80;
        static int CMI_MIN_HEIGHT = 10;
        static int CMI_MAX_HEIGHT = 80;

        public GDOTCH00()
        {
            InitializeComponent();
        }

        private void GDOTCH00_Load(object sender, EventArgs e)
        {
            cmbBackColor.DrawMode = DrawMode.OwnerDrawFixed;
            cmbBackColor.DrawItem += new DrawItemEventHandler(this.cmbColor_DrawItem);
            M0_Initialize_Form();
        }

        public string get_str_picDotImages(int i) {
            string str = "";
            str = ms_picDotImages[i];
            return str;
        }

        public void M0_Initialize_Form()
        {
            ms_picDotImages = new string[88];
            for (int i = 0; i < ms_picDotImages.Length; i ++)
            {
                ms_picDotImages[i] = "";
            }
            mo_tooltip = new ToolTip();
            mo_tooltip.InitialDelay = 300;
            mo_tooltip.ReshowDelay = 300;
            mo_tooltip.AutoPopDelay = 5000;
            mo_tooltip.ShowAlways = true;
            mo_tooltip.SetToolTip(cmbBackColor, "BackColor - This is Random. You can change this anytime.");
            mo_tooltip.SetToolTip(btnLoad, "Load Image - Please load Original Image.");
            mo_tooltip.SetToolTip(btnCHANGE, "DOT Change - You can change Original Image to DOT Images.");
            mo_tooltip.SetToolTip(btnOpt, "Option - If you want to Clear All DOT Images, etc.");
            mo_tooltip.SetToolTip(cmbP1, "Size - Please set DOT Image size");
            mo_tooltip.SetToolTip(cmbP2, "Size Variation - If you want to size variation as neighbor.");

            cmbBackColor.Items.Clear();
            M1_Add_Item_Color(cmbBackColor, true);
            Random r = new Random();
            cmbBackColor.SelectedIndex = r.Next(cmbBackColor.Items.Count);
            cmbP1.Items.Clear();
            for (int i = 16; i < 70; i ++)
            {
                cmbP1.Items.Add("Size:" + i.ToString());
            }
            cmbP1.SelectedIndex = 34;
            cmbP2.Items.Clear();
            for (int i = 0; i <= 50; i ++)
            {
                if (i == 0)
                {
                    cmbP2.Items.Add(i.ToString());
                }
                else
                {
                    cmbP2.Items.Add("-" + i.ToString()  + "/+" + i.ToString());

                }
            }
            cmbP2.SelectedIndex = 5;
            picD49.Height = 64;
            picD50.Height = 64;
            picD51.Height = 64;
            picD52.Height = 64;
            picD53.Height = 64;
            picD54.Height = 64;
            picD55.Height = 64;
            picD56.Height = 64;
            picD57.Height = 64;
            picD58.Height = 64;
            picD59.Height = 64;
            picD60.Height = 64;
            picD61.Height = 64;
            picD62.Height = 64;
            picD63.Height = 64;
            picD64.Height = 64;
            picD65.Height = 64;
            picD66.Height = 64;
            picD67.Height = 64;
            picD68.Height = 64;
            picD69.Height = 64;
            picD70.Height = 64;
            picD71.Height = 64;
            picD72.Height = 64;
            picD73.Height = 64;
            picD74.Height = 64;
            picD75.Height = 64;
            picD76.Height = 64;
            picD77.Height = 64;
            picD78.Height = 64;
            picD79.Height = 64;
            picD80.Height = 64;
            picD81.Height = 64;
            picD82.Height = 64;
            picD83.Height = 64;
            picD84.Height = 64;
            picD85.Height = 64;
            picD86.Height = 64;
            picD87.Height = 64;
            picD88.Height = 64;
            picD49.Top = picD41.Top + 64;
            picD50.Top = picD41.Top + 64;
            picD51.Top = picD41.Top + 64;
            picD52.Top = picD41.Top + 64;
            picD53.Top = picD41.Top + 64;
            picD54.Top = picD41.Top + 64;
            picD55.Top = picD41.Top + 64;
            picD56.Top = picD41.Top + 64;
            picD57.Top = picD49.Top + 64;
            picD58.Top = picD49.Top + 64;
            picD59.Top = picD49.Top + 64;
            picD60.Top = picD49.Top + 64;
            picD61.Top = picD49.Top + 64;
            picD62.Top = picD49.Top + 64;
            picD63.Top = picD49.Top + 64;
            picD64.Top = picD49.Top + 64;
            picD65.Top = picD57.Top + 64;
            picD66.Top = picD57.Top + 64;
            picD67.Top = picD57.Top + 64;
            picD68.Top = picD57.Top + 64;
            picD69.Top = picD57.Top + 64;
            picD70.Top = picD57.Top + 64;
            picD71.Top = picD57.Top + 64;
            picD72.Top = picD57.Top + 64;
            picD73.Top = picD65.Top + 64;
            picD74.Top = picD65.Top + 64;
            picD75.Top = picD65.Top + 64;
            picD76.Top = picD65.Top + 64;
            picD77.Top = picD65.Top + 64;
            picD78.Top = picD65.Top + 64;
            picD79.Top = picD65.Top + 64;
            picD80.Top = picD65.Top + 64;
            picD81.Top = picD73.Top + 64;
            picD82.Top = picD73.Top + 64;
            picD83.Top = picD73.Top + 64;
            picD84.Top = picD73.Top + 64;
            picD85.Top = picD73.Top + 64;
            picD86.Top = picD73.Top + 64;
            picD87.Top = picD73.Top + 64;
            picD88.Top = picD73.Top + 64;
            M3_txtInfo_Append("DOTCHAN Started.");
        }

        private void cmbBackColor_SelectedIndexChanged(object sender, EventArgs e)
        {
            M0_cmbBackColor_Change();
        }

        private void M0_cmbBackColor_Change()
        {
            this.BackColor = ColorTranslator.FromHtml(cmbBackColor.Text);
        }

        private void M1_Add_Item_Color(ComboBox pc_ComboBox, Boolean pb_Pastel)
        {
            Boolean lb_color_is_DontUseColor;
            string[] dont_use_color = {
                "ActiveBorder","ActiveCaption","ActiveCaptionText","AppWorkspace",
                "Control","ControlDark","ControlDarkDark","ControlLight","ControlLightLight","ControlText",
                "Desktop","GrayText","Highlight","HighlightText",
                "ButtonFace", "ButtonHighlight", "ButtonShadow",
                "GradientActiveCaption", "GradientInactiveCaption",
                "HotTrack","InactiveBorder","InactiveCaption","InactiveCaptionText",
                "Info","InfoText","Menu","MenuBar", "MenuHighlight","MenuText","ScrollBar","Window","WindowFrame","WindowText",
                "Transparent"
            };
            lb_color_is_DontUseColor = false;
            foreach (string colorname in Enum.GetNames(typeof(KnownColor)))
            {
                lb_color_is_DontUseColor = false;
                for (int i = 0; i < dont_use_color.Length; i++)
                {
                    if (colorname == dont_use_color[i])
                    {
                        lb_color_is_DontUseColor = true;
                        break;
                    }
                }
                if (lb_color_is_DontUseColor == false)
                {
                    if ((pb_Pastel == true) && (ColorTranslator.FromHtml(colorname).GetBrightness() >= 0.65) &&
                             (ColorTranslator.FromHtml(colorname).GetBrightness() <= 0.98))
                    {
                        pc_ComboBox.Items.Add(colorname);
                    }
                    else if (pb_Pastel == false)
                    {
                        pc_ComboBox.Items.Add(colorname);
                    }
                }
            }
        }

        private void cmbColor_DrawItem(object sender, DrawItemEventArgs e)
        {
            string ls_icon = "";
            if (e.Index == -1) { return; }
            ComboBox cmbColor = (ComboBox)sender;
            string ls_Color = e.Index > -1 ? cmbColor.Items[e.Index].ToString() : cmbColor.Text;
            if (ls_Color == "Black")
            {
                ls_icon = " (#000001)";
            }
            e.DrawBackground();
            e.Graphics.DrawString("■", e.Font, new SolidBrush(Color.FromName(ls_Color)),
                 new RectangleF(e.Bounds.X, e.Bounds.Y, e.Bounds.Width, e.Bounds.Height));
            e.Graphics.DrawString("　　" + ls_Color + ls_icon, e.Font, new SolidBrush(e.ForeColor),
                 new RectangleF(e.Bounds.X, e.Bounds.Y, e.Bounds.Width, e.Bounds.Height));
            e.DrawFocusRectangle();
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            M0_btnLoad_Click();
        }

        private void M0_btnLoad_Click()
        {
            string ls_Filepath = "";
            Bitmap lo_bmp;
            string ls_Sizeinfo = "";
            openFileDialog1.Filter = "Image Files|*.*";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                ls_Filepath = openFileDialog1.FileName;
                picOriginal.Image = System.Drawing.Image.FromFile(@ls_Filepath);
                lo_bmp = (Bitmap)picOriginal.Image;
                ls_Sizeinfo = lo_bmp.Width.ToString() + "x" + lo_bmp.Height.ToString();
                ms_OriginalFileInfo = Path.GetFileName(ls_Filepath) + " : " + ls_Sizeinfo;
                mo_tooltip.SetToolTip(picOriginal, ms_OriginalFileInfo);
                M3_txtInfo_Append("Loaded. " + ms_OriginalFileInfo);
                AutoClosingMessageBox.Show("Loaded.", "Notice", 1000);
            }
        }

        private void M3_txtInfo_Append(string ps_info1)
        {
            M3_txtInfo_Append(ps_info1, "", "", "");
        }

        private void M3_txtInfo_Append(string ps_info1, string ps_info2)
        {
            M3_txtInfo_Append(ps_info1, ps_info2, "", "");
        }

        private void M3_txtInfo_Append(string ps_info1, string ps_info2, string ps_info3)
        {
            M3_txtInfo_Append(ps_info1, ps_info2, ps_info3, "");
        }

        private void M3_txtInfo_Append(string ps_info1, string ps_info2, string ps_info3, string ps_info4)
        {
            string ls_datetime = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            txtInfo.AppendText(ls_datetime + Environment.NewLine);
            if (ps_info1 != "")
            {
                txtInfo.AppendText(ps_info1 + Environment.NewLine);
            }
            if (ps_info2 != "")
            {
                txtInfo.AppendText(ps_info2 + Environment.NewLine);
            }
            if (ps_info3 != "")
            {
                txtInfo.AppendText(ps_info3 + Environment.NewLine);
            }
            if (ps_info4 != "")
            {
                txtInfo.AppendText(ps_info4 + Environment.NewLine);
            }
        }

        private void M0_btnCHANGE_Click()
        {
            int li_width = 32;
            int li_height = 32;
            int li_min;
            int li_max;
            if (picOriginal.Image == null) { return;  }
            Bitmap lo_bmp = (Bitmap)picOriginal.Image;
            int delimiter_pos = cmbP1.Text.IndexOf(":");
            string ls_size = cmbP1.Text.Substring(delimiter_pos + 1);
            if (lo_bmp.Width == lo_bmp.Height)
            {
                li_width = Int32.Parse(ls_size);
                li_height = Int32.Parse(ls_size);
            }
            else if (lo_bmp.Width > lo_bmp.Height)
            {
                li_width = Int32.Parse(ls_size);
                li_height = li_width * lo_bmp.Height / lo_bmp.Width;
            }
            else if (lo_bmp.Width < lo_bmp.Height)
            {
                li_height = Int32.Parse(ls_size);
                li_width = li_height * lo_bmp.Width / lo_bmp.Height;
            }
            if ( cmbP2.Text == "0" )
            {
                M2_Add_DotImage(li_width, li_height);
            }
            else
            {
                delimiter_pos = cmbP2.Text.IndexOf("/");
                string ls_min = cmbP2.Text.Substring(0, delimiter_pos);
                string ls_max = cmbP2.Text.Substring(delimiter_pos + 1);
                li_min = Int32.Parse(ls_min);
                li_max = Int32.Parse(ls_max);
                for (int i = li_min; i <= li_max; i++)
                {
                    M2_Add_DotImage(li_width + i, li_height + i);
                }
            }
        }

        private void M2_Add_DotImage(int pi_width, int pi_height)
        {
            if (pi_width < CMI_MIN_WIDTH) { return; }
            if (pi_width > CMI_MAX_WIDTH) { return; }
            if (pi_height < CMI_MIN_HEIGHT) { return; }
            if (pi_height > CMI_MAX_HEIGHT) { return; }

            for (int i = 0; i < ms_picDotImages.Length; i++)
            {
                foreach (Control lc_picBox in grpDOT.Controls)
                {
                    if (lc_picBox.Name == "picD" + (i + 1).ToString("00"))
                    {
                        if (ms_picDotImages[i] == "" )
                        {
                            ms_picDotImages[i] = "Size:" + pi_width.ToString() + "x" + pi_height.ToString();
                            Bitmap lo_bmp = (Bitmap)picOriginal.Image;
                            Image lo_small = lo_bmp.GetThumbnailImage(pi_width, pi_height, null, IntPtr.Zero);
                            ((PictureBox)lc_picBox).Image = lo_small;
                            mo_tooltip.SetToolTip(lc_picBox, ms_picDotImages[i]);
                            return;
                        }
                    }
                }
            }
        }

        private void contextMenuStrip1_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }

        private void zoomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Control source = contextMenuStrip1.SourceControl;
            if (source != null)
            {
                string ls_SourceName = source.Name;
                string ls_SourceType = ls_SourceName.Substring(0, 4);
                if (ls_SourceType == "picD")
                {
                    M0_picD_Click((PictureBox)source);
                }
            }
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Control source = contextMenuStrip1.SourceControl;
            if (source != null)
            {
                string ls_SourceName = source.Name;
                string ls_SourceType = ls_SourceName.Substring(0, 4);
                int i = Int32.Parse(ls_SourceName.Substring(4, 2));
                if (ls_SourceType == "picD")
                {
                    ((PictureBox)source).Image = null;
                    mo_tooltip.SetToolTip(source, "");
                    ms_picDotImages[i - 1] = "";
                }
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Control source = contextMenuStrip1.SourceControl;
            if (source != null)
            {
                string ls_SourceName = source.Name;
                string ls_SourceType = ls_SourceName.Substring(0, 4);
                int i = Int32.Parse(ls_SourceName.Substring(4, 2));
                if (ls_SourceType == "picD")
                {
                    M0_Save_DotImage((PictureBox)source);
                }
            }
        }

        private void M0_Save_DotImage(PictureBox picD )
        {
            if (picD.Image == null) { return; }
            saveFileDialog1.Filter = "Png Image|*.png|Jpeg Image|*.jpg|Bmp Image|*.bmp";
            saveFileDialog1.FilterIndex = 1;
            saveFileDialog1.FileName = ".png";
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string ls_extension = System.IO.Path.GetExtension(saveFileDialog1.FileName);
                switch (ls_extension.ToUpper())
                {
                    case ".JPG":
                        picD.Image.Save(saveFileDialog1.FileName);
                        break;
                    case ".PNG":
                        picD.Image.Save(saveFileDialog1.FileName);
                        break;
                    case ".BMP":
                        picD.Image.Save(saveFileDialog1.FileName);
                        break;
                }
            }
        }

        private void M0_picD_Click( PictureBox picD )
        {
            if (picD.Image == null) { return;  }
            ms_Current_PicD = picD.Name;
            int li_picD = Int32.Parse(ms_Current_PicD.Substring(4));
            GDOTCH10 form = new GDOTCH10(this);
            form.setNumber(li_picD);
            form.BackColor = this.BackColor;
            form.setBmp((Bitmap)picD.Image);
            form.ShowDialog();
            ms_Current_PicD = "";
        }

        private void btnCHANGE_Click(object sender, EventArgs e)
        {
            M0_btnCHANGE_Click();
        }

        private void picD01_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD01);
        }

        private void picD02_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD02);
        }

        private void picD03_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD03);
        }

        private void picD04_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD04);
        }

        private void picD05_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD05);
        }

        private void picD06_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD06);
        }

        private void picD07_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD07);
        }

        private void picD08_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD08);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD09);
        }

        private void picD10_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD10);
        }

        private void picD11_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD11);
        }

        private void picD12_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD12);
        }

        private void picD13_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD13);
        }

        private void picD14_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD14);
        }

        private void picD15_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD15);
        }

        private void picD16_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD16);
        }

        private void picD17_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD17);
        }

        private void picD18_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD18);
        }

        private void picD19_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD19);
        }

        private void picD20_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD20);
        }

        private void picD21_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD21);
        }

        private void picD22_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD22);
        }

        private void picD23_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD23);
        }

        private void picD24_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD24);
        }

        private void picD25_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD25);
        }

        private void picD26_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD26);
        }

        private void picD27_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD27);
        }

        private void picD28_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD28);
        }

        private void picD29_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD29);
        }

        private void picD30_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD30);
        }

        private void picD31_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD31);
        }

        private void picD32_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD32);
        }

        private void picD33_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD33);
        }

        private void picD34_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD34);
        }

        private void picD35_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD35);
        }

        private void picD36_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD36);
        }

        private void picD37_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD37);
        }

        private void picD38_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD38);
        }

        private void picD39_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD39);
        }

        private void picD40_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD40);
        }

        private void picD41_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD41);
        }

        private void picD42_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD42);
        }

        private void picD43_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD43);
        }

        private void picD44_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD44);
        }

        private void picD45_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD45);
        }

        private void picD46_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD46);
        }

        private void picD47_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD47);
        }

        private void picD48_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD48);
        }

        private void picD49_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD49);
        }

        private void picD50_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD50);
        }

        private void picD51_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD51);
        }

        private void picD52_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD52);
        }

        private void picD53_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD53);
        }

        private void picD54_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD54);
        }

        private void picD55_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD55);
        }

        private void picD56_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD56);
        }

        private void picD57_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD57);
        }

        private void picD58_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD58);
        }

        private void picD59_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD59);
        }

        private void picD60_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD60);
        }

        private void picD61_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD61);
        }

        private void picD62_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD62);
        }

        private void picD63_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD63);
        }

        private void picD64_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD64);
        }

        private void picD65_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD65);
        }

        private void picD66_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD66);
        }

        private void picD67_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD67);
        }

        private void picD68_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD68);
        }

        private void picD69_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD69);
        }

        private void picD70_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD70);
        }

        private void picD71_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD71);
        }

        private void picD72_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD72);
        }

        private void picD73_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD73);
        }

        private void picD74_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD74);
        }

        private void picD75_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD75);
        }

        private void picD76_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD76);
        }

        private void picD77_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD77);
        }

        private void picD78_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD78);
        }

        private void picD79_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD79);
        }

        private void picD80_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD80);
        }

        private void picD81_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD81);
        }

        private void picD82_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD82);
        }

        private void picD83_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD83);
        }

        private void picD84_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD84);
        }

        private void picD85_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD85);
        }

        private void picD86_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD86);
        }

        private void picD87_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD87);
        }

        private void picD88_Click(object sender, EventArgs e)
        {
            M0_picD_Click(picD88);
        }

        private void clearAllStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to clear All DOT Images?",
    "Question", MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            if (result == DialogResult.OK)
            {
                M0_Clear_All_Dot_Images();
            }
        }

        private void M0_Clear_All_Dot_Images() {
            for (int i = 0; i < ms_picDotImages.Length; i++)
            {
                foreach (Control lc_picBox in grpDOT.Controls)
                {
                    if (lc_picBox.Name == "picD" + (i + 1).ToString("00"))
                    {
                        ((PictureBox)lc_picBox).Image = null;
                        mo_tooltip.SetToolTip(lc_picBox, "");
                        ms_picDotImages[i] = "";
                    }
                }
            }
        }

        private void rearrangeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to Rearrange DOT Images?",
    "Question", MessageBoxButtons.OKCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            if (result == DialogResult.OK)
            {
                M0_Rearrange_Dot_Images();
            }
        }

        private void M0_Rearrange_Dot_Images()
        {
            //Image設定
            string ls_to_picD;
            for (int i = 0; i < ms_picDotImages.Length; i++)
            {
                ls_to_picD = "picD" + (i + 1).ToString("00");
                PictureBox lo_to_picD = (PictureBox)this.Controls["grpDOT"].Controls[ls_to_picD];
                if (lo_to_picD.Image == null)
                {
                    M1_Rearrange_Dot_Image(lo_to_picD);
                }
            }
        }

        private void M1_Rearrange_Dot_Image(PictureBox po_to_picD)
        {
            int li_start = Int32.Parse(po_to_picD.Name.Substring(4));
            string ls_from_picD;
            for (int i = li_start; i < ms_picDotImages.Length; i++)
            {
                ls_from_picD = "picD" + (i + 1).ToString("00");
                PictureBox lo_from_picD = (PictureBox)this.Controls["grpDOT"].Controls[ls_from_picD];
                if (lo_from_picD.Image != null) {
                    //Console.WriteLine(po_to_picD.Name + " is null, " + ls_from_picD + " is not null");
                    po_to_picD.Image = lo_from_picD.Image;
                    lo_from_picD.Image = null;
                    ms_picDotImages[li_start] = ms_picDotImages[i];
                    mo_tooltip.SetToolTip(po_to_picD, ms_picDotImages[li_start]);
                    mo_tooltip.SetToolTip(lo_from_picD, "");
                    break;
                }
            }
        }

        private void btnOpt_Click(object sender, EventArgs e)
        {
            System.Drawing.Point p = System.Windows.Forms.Cursor.Position;
            this.contextMenuStrip2.Show(p);
        }

        private void picOriginal_DoubleClick(object sender, EventArgs e)
        {
            AutoClosingMessageBox.Show(ms_OriginalFileInfo, "Notice", 3000);
        }
    }


}
