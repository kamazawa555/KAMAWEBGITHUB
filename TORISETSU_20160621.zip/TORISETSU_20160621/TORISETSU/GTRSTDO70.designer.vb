﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class GTRSTDO70
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(GTRSTDO70))
        Me.cmdBACK = New System.Windows.Forms.Button()
        Me.cmdEXIT = New System.Windows.Forms.Button()
        Me.cmbNUM = New System.Windows.Forms.ComboBox()
        Me.cmdNEXT = New System.Windows.Forms.Button()
        Me.cmbANGLE = New System.Windows.Forms.ComboBox()
        Me.lblANGLE = New System.Windows.Forms.Label()
        Me.lblZOOM = New System.Windows.Forms.Label()
        Me.cmbZOOM = New System.Windows.Forms.ComboBox()
        Me.chkAutoFit = New System.Windows.Forms.CheckBox()
        Me.cmdUP = New System.Windows.Forms.Button()
        Me.cmdLEFT = New System.Windows.Forms.Button()
        Me.cmdDOWN = New System.Windows.Forms.Button()
        Me.cmdRIGHT = New System.Windows.Forms.Button()
        Me.picSLIDE = New System.Windows.Forms.PictureBox()
        Me.wmpSLIDE = New AxWMPLib.AxWindowsMediaPlayer()
        Me.chkVBACK = New System.Windows.Forms.CheckBox()
        Me.chkVNEXT = New System.Windows.Forms.CheckBox()
        CType(Me.picSLIDE, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.wmpSLIDE, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdBACK
        '
        Me.cmdBACK.Location = New System.Drawing.Point(3, 3)
        Me.cmdBACK.Name = "cmdBACK"
        Me.cmdBACK.Size = New System.Drawing.Size(76, 22)
        Me.cmdBACK.TabIndex = 104
        Me.cmdBACK.TabStop = False
        Me.cmdBACK.Text = "BACK"
        Me.cmdBACK.UseVisualStyleBackColor = True
        '
        'cmdEXIT
        '
        Me.cmdEXIT.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdEXIT.Location = New System.Drawing.Point(877, 4)
        Me.cmdEXIT.Name = "cmdEXIT"
        Me.cmdEXIT.Size = New System.Drawing.Size(70, 22)
        Me.cmdEXIT.TabIndex = 500
        Me.cmdEXIT.Text = "EXIT"
        Me.cmdEXIT.UseVisualStyleBackColor = True
        '
        'cmbNUM
        '
        Me.cmbNUM.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbNUM.FormattingEnabled = True
        Me.cmbNUM.Location = New System.Drawing.Point(85, 4)
        Me.cmbNUM.Name = "cmbNUM"
        Me.cmbNUM.Size = New System.Drawing.Size(53, 20)
        Me.cmbNUM.TabIndex = 105
        '
        'cmdNEXT
        '
        Me.cmdNEXT.BackColor = System.Drawing.Color.GreenYellow
        Me.cmdNEXT.Location = New System.Drawing.Point(144, 3)
        Me.cmdNEXT.Name = "cmdNEXT"
        Me.cmdNEXT.Size = New System.Drawing.Size(76, 22)
        Me.cmdNEXT.TabIndex = 110
        Me.cmdNEXT.Text = "NEXT"
        Me.cmdNEXT.UseVisualStyleBackColor = False
        '
        'cmbANGLE
        '
        Me.cmbANGLE.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbANGLE.FormattingEnabled = True
        Me.cmbANGLE.Location = New System.Drawing.Point(377, 4)
        Me.cmbANGLE.Name = "cmbANGLE"
        Me.cmbANGLE.Size = New System.Drawing.Size(53, 20)
        Me.cmbANGLE.TabIndex = 113
        '
        'lblANGLE
        '
        Me.lblANGLE.AutoSize = True
        Me.lblANGLE.Location = New System.Drawing.Point(329, 7)
        Me.lblANGLE.Name = "lblANGLE"
        Me.lblANGLE.Size = New System.Drawing.Size(42, 12)
        Me.lblANGLE.TabIndex = 202
        Me.lblANGLE.Text = "ANGLE"
        '
        'lblZOOM
        '
        Me.lblZOOM.AutoSize = True
        Me.lblZOOM.Location = New System.Drawing.Point(436, 7)
        Me.lblZOOM.Name = "lblZOOM"
        Me.lblZOOM.Size = New System.Drawing.Size(37, 12)
        Me.lblZOOM.TabIndex = 203
        Me.lblZOOM.Text = "ZOOM"
        '
        'cmbZOOM
        '
        Me.cmbZOOM.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbZOOM.FormattingEnabled = True
        Me.cmbZOOM.Location = New System.Drawing.Point(479, 3)
        Me.cmbZOOM.Name = "cmbZOOM"
        Me.cmbZOOM.Size = New System.Drawing.Size(43, 20)
        Me.cmbZOOM.TabIndex = 114
        '
        'chkAutoFit
        '
        Me.chkAutoFit.AutoSize = True
        Me.chkAutoFit.Checked = True
        Me.chkAutoFit.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkAutoFit.Location = New System.Drawing.Point(239, 5)
        Me.chkAutoFit.Name = "chkAutoFit"
        Me.chkAutoFit.Size = New System.Drawing.Size(72, 16)
        Me.chkAutoFit.TabIndex = 112
        Me.chkAutoFit.Text = "AUTOFIT"
        Me.chkAutoFit.UseVisualStyleBackColor = True
        '
        'cmdUP
        '
        Me.cmdUP.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.cmdUP.Location = New System.Drawing.Point(438, 31)
        Me.cmdUP.Name = "cmdUP"
        Me.cmdUP.Size = New System.Drawing.Size(50, 20)
        Me.cmdUP.TabIndex = 210
        Me.cmdUP.TabStop = False
        Me.cmdUP.Text = "↑"
        Me.cmdUP.UseVisualStyleBackColor = True
        '
        'cmdLEFT
        '
        Me.cmdLEFT.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cmdLEFT.Location = New System.Drawing.Point(3, 184)
        Me.cmdLEFT.Name = "cmdLEFT"
        Me.cmdLEFT.Size = New System.Drawing.Size(20, 50)
        Me.cmdLEFT.TabIndex = 211
        Me.cmdLEFT.TabStop = False
        Me.cmdLEFT.Text = "←"
        Me.cmdLEFT.UseVisualStyleBackColor = True
        '
        'cmdDOWN
        '
        Me.cmdDOWN.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.cmdDOWN.Location = New System.Drawing.Point(438, 359)
        Me.cmdDOWN.Name = "cmdDOWN"
        Me.cmdDOWN.Size = New System.Drawing.Size(50, 20)
        Me.cmdDOWN.TabIndex = 213
        Me.cmdDOWN.TabStop = False
        Me.cmdDOWN.Text = "↓"
        Me.cmdDOWN.UseVisualStyleBackColor = True
        '
        'cmdRIGHT
        '
        Me.cmdRIGHT.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.cmdRIGHT.Location = New System.Drawing.Point(927, 184)
        Me.cmdRIGHT.Name = "cmdRIGHT"
        Me.cmdRIGHT.Size = New System.Drawing.Size(20, 50)
        Me.cmdRIGHT.TabIndex = 212
        Me.cmdRIGHT.TabStop = False
        Me.cmdRIGHT.Text = "→"
        Me.cmdRIGHT.UseVisualStyleBackColor = True
        '
        'picSLIDE
        '
        Me.picSLIDE.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picSLIDE.Location = New System.Drawing.Point(3, 32)
        Me.picSLIDE.Name = "picSLIDE"
        Me.picSLIDE.Size = New System.Drawing.Size(944, 347)
        Me.picSLIDE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picSLIDE.TabIndex = 215
        Me.picSLIDE.TabStop = False
        '
        'wmpSLIDE
        '
        Me.wmpSLIDE.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.wmpSLIDE.Enabled = True
        Me.wmpSLIDE.Location = New System.Drawing.Point(3, 32)
        Me.wmpSLIDE.Name = "wmpSLIDE"
        Me.wmpSLIDE.OcxState = CType(resources.GetObject("wmpSLIDE.OcxState"), System.Windows.Forms.AxHost.State)
        Me.wmpSLIDE.Size = New System.Drawing.Size(944, 347)
        Me.wmpSLIDE.TabIndex = 301
        '
        'chkVBACK
        '
        Me.chkVBACK.AutoSize = True
        Me.chkVBACK.Checked = True
        Me.chkVBACK.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkVBACK.Location = New System.Drawing.Point(694, 6)
        Me.chkVBACK.Name = "chkVBACK"
        Me.chkVBACK.Size = New System.Drawing.Size(127, 16)
        Me.chkVBACK.TabIndex = 311
        Me.chkVBACK.Text = "VOICE BACK PAGE"
        Me.chkVBACK.UseVisualStyleBackColor = True
        '
        'chkVNEXT
        '
        Me.chkVNEXT.AutoSize = True
        Me.chkVNEXT.Checked = True
        Me.chkVNEXT.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkVNEXT.Location = New System.Drawing.Point(541, 6)
        Me.chkVNEXT.Name = "chkVNEXT"
        Me.chkVNEXT.Size = New System.Drawing.Size(125, 16)
        Me.chkVNEXT.TabIndex = 310
        Me.chkVNEXT.Text = "VOICE NEXT PAGE"
        Me.chkVNEXT.UseVisualStyleBackColor = True
        '
        'GTRSTDO70
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(950, 381)
        Me.Controls.Add(Me.chkVBACK)
        Me.Controls.Add(Me.chkVNEXT)
        Me.Controls.Add(Me.cmdRIGHT)
        Me.Controls.Add(Me.cmdDOWN)
        Me.Controls.Add(Me.cmdLEFT)
        Me.Controls.Add(Me.cmdUP)
        Me.Controls.Add(Me.chkAutoFit)
        Me.Controls.Add(Me.cmbZOOM)
        Me.Controls.Add(Me.lblZOOM)
        Me.Controls.Add(Me.lblANGLE)
        Me.Controls.Add(Me.cmbANGLE)
        Me.Controls.Add(Me.cmdNEXT)
        Me.Controls.Add(Me.cmbNUM)
        Me.Controls.Add(Me.cmdEXIT)
        Me.Controls.Add(Me.cmdBACK)
        Me.Controls.Add(Me.picSLIDE)
        Me.Controls.Add(Me.wmpSLIDE)
        Me.KeyPreview = True
        Me.Name = "GTRSTDO70"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "GTRSTDO70 : FLIP"
        CType(Me.picSLIDE, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.wmpSLIDE, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents cmdBACK As Button
    Friend WithEvents cmdEXIT As Button
    Friend WithEvents cmbNUM As ComboBox
    Friend WithEvents cmdNEXT As Button
    Friend WithEvents cmbANGLE As ComboBox
    Friend WithEvents lblANGLE As Label
    Friend WithEvents lblZOOM As Label
    Friend WithEvents cmbZOOM As ComboBox
    Friend WithEvents chkAutoFit As CheckBox
    Friend WithEvents cmdUP As Button
    Friend WithEvents cmdLEFT As Button
    Friend WithEvents cmdDOWN As Button
    Friend WithEvents cmdRIGHT As Button
    Friend WithEvents picSLIDE As PictureBox
    Friend WithEvents wmpSLIDE As AxWMPLib.AxWindowsMediaPlayer
    Friend WithEvents chkVBACK As CheckBox
    Friend WithEvents chkVNEXT As CheckBox
End Class
