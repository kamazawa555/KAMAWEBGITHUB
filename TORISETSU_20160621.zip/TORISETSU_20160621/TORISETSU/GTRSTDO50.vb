﻿Imports System.Drawing
Imports System.Speech
Imports Tao.Platform.Windows
Imports System
Imports System.Threading

Public Class GTRSTDO50
    'スレッド用モジュール変数
    Private Shared WithEvents mo_Timer As New System.Windows.Forms.Timer()
    Private Shared mb_ExitFlag As Boolean = False
    'スレッドタイマーインターバル
    Const CML_THREAD_INTERVAL As Long = 50
    'Joy Pad Status
    Dim ms_JOY_PAD_STATUS As String
    'SLIDEファイルパス
    'Dim ms_SLIDE_FILEPATH As String = "C:\DEVELOP\IMAGE\"
    Dim ms_SLIDE_FILEPATH As String = System.Windows.Forms.Application.StartupPath + "\IMAGE\"
    'SLIDEファイル名ベース
    Dim ms_SLIDE_FILENAME_BASE As String = "IMAGE"
    '音声認識利用可否
    Dim mb_Voice_Recognition As Boolean = False
    'メッセージ
    Dim ms_FILENOTFOUND_MESSAGE As String = "ERROR:IMAGE(IMAGExxx.jpg/.png) FILE NOT FOUND."
    Dim ms_ERROR_TITLE As String = "ERROR"
    Dim mi_size_zoom As Integer
    Dim mi_Location_x As Integer
    Dim mi_Location_y As Integer
    Dim mi_Location_change As Integer
    Dim mb_Drag As Boolean
    Dim mo_DragPoint As Point
    '音声認識
    Dim WithEvents reco As New Recognition.SpeechRecognitionEngine

    Private Sub picSLIDE_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles picSLIDE.MouseDown
        Select Case chkAutoFit.Checked
            Case True
                'SKIP
            Case False
                If mb_Drag = False Then
                    mb_Drag = True
                    mo_DragPoint = e.Location
                End If
        End Select
    End Sub

    Private Sub picSLIDE_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles picSLIDE.MouseUp
        Dim li_location_change_x As Integer
        Dim li_location_change_y As Integer
        Select Case chkAutoFit.Checked
            Case True
                'SKIP
            Case False
                Me.Cursor = Cursors.WaitCursor
                mb_Drag = False
                li_location_change_x = e.Location.X - mo_DragPoint.X
                li_location_change_y = e.Location.Y - mo_DragPoint.Y
                mi_Location_x = mi_Location_x + li_location_change_x
                mi_Location_y = mi_Location_y + li_location_change_y
                Call M0_LOCATION_CHECK()
                Call M0_IMAGE_REFRESH()
                Me.Cursor = Cursors.Default
        End Select
    End Sub

    Private Sub Form_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call M0_FORM_LOAD()
    End Sub

    Private Sub cmdEXIT_Click(sender As Object, e As EventArgs) Handles cmdEXIT.Click
        Me.Close()
    End Sub

    Private Sub cmdBACK_Click(sender As Object, e As EventArgs) Handles cmdBACK.Click
        Call M0_BACK()
    End Sub

    Private Sub M0_BACK()
        'スライド番号コンボ変更
        If cmbNUM.SelectedIndex > 0 Then
            cmbNUM.SelectedIndex = cmbNUM.SelectedIndex - 1
        End If
    End Sub

    Private Sub cmdNEXT_Click(sender As Object, e As EventArgs) Handles cmdNEXT.Click
        Call M0_NEXT()
    End Sub

    Private Sub M0_NEXT()
        Dim ll_SLIDE_x As Long
        Dim ll_SLIDE_x_start As Long
        Dim ll_SLIDE_x_end As Long
        Dim ll_SLIDE_x_step As Long
        If picSLIDE.Visible = True Then
            'スライドはフレームアウト
            ll_SLIDE_x_start = picSLIDE.Left
            ll_SLIDE_x_end = -picSLIDE.Width
            ll_SLIDE_x_step = (ll_SLIDE_x_end - ll_SLIDE_x_start) / 100
            If ll_SLIDE_x_step >= 0 Then
                ll_SLIDE_x_step = -2
            End If
            For ll_SLIDE_x = ll_SLIDE_x_start To ll_SLIDE_x_end Step ll_SLIDE_x_step
                picSLIDE.Left = ll_SLIDE_x
                '遅くなるのでコメントアウト
                'wmpSLIDE.Left = picSLIDE.Left
            Next ll_SLIDE_x
        Else
            '動画は停止する
            wmpSLIDE.Ctlcontrols.stop()
        End If
        'スライド番号コンボ変更
        If cmbNUM.SelectedIndex < 200 Then
            cmbNUM.SelectedIndex = cmbNUM.SelectedIndex + 1
        End If
        '初期位置に戻す
        picSLIDE.Left = ll_SLIDE_x_start
        wmpSLIDE.Left = picSLIDE.Left
    End Sub

    Private Sub M0_READ_JOYPAD_STICK()
        'Read JoyPad
        Dim joyinfo As Tao.Platform.Windows.Winmm.JOYINFO = New Tao.Platform.Windows.Winmm.JOYINFO()
        If (Tao.Platform.Windows.Winmm.joyGetPos(0, joyinfo) = Tao.Platform.Windows.Winmm.JOYERR_NOERROR) Then
            'Stick
            If (joyinfo.wXpos < (65535 * 0.1)) Then
                If (ms_JOY_PAD_STATUS = "READY") Then
                    ms_JOY_PAD_STATUS = "JOY_PAD_BACK"
                    Call M0_BACK()
                End If
            ElseIf (joyinfo.wXpos > (65535 * 0.9)) Then
                If (ms_JOY_PAD_STATUS = "READY") Then
                    ms_JOY_PAD_STATUS = "JOY_PAD_NEXT"
                    Call M0_NEXT()
                End If
            Else
                ms_JOY_PAD_STATUS = "READY"
            End If
        End If
    End Sub

    Private Sub M0_FORM_LOAD()
        Dim ll_Index As Integer
        Dim ld_index As Decimal
        For ll_Index = 1 To 200
            cmbNUM.Items.Add(CStr(ll_Index))
        Next
        cmbNUM.SelectedIndex = 0
        For ld_index = -35.0 To 35.0 Step 1.0
            cmbANGLE.Items.Add(ld_index.ToString())
        Next
        cmbANGLE.Text = "0.0"
        For ll_Index = 10 To 300 Step 10
            cmbZOOM.Items.Add(CStr(ll_Index))
        Next
        cmbZOOM.Text = 100
        cmdNEXT.Focus()

        '音声認識
        Try
            reco.SetInputToDefaultAudioDevice()
            Dim gram As New Recognition.SrgsGrammar.SrgsDocument
            Dim pageActionRule As New Recognition.SrgsGrammar.SrgsRule("page")
            Dim pageActions As New Recognition.SrgsGrammar.SrgsOneOf(
            "voice recognize on", "voice recognition on",
            "voice recognize off", "voice recognition off",
            "next page", "go next", "go foward", "go ahead", "let's go",
            "back page", "go back", "previous")
            pageActionRule.Add(pageActions)
            gram.Rules.Add(pageActionRule)
            gram.Root = pageActionRule
            reco.LoadGrammar(New Recognition.Grammar(gram))
            reco.RecognizeAsync()
            '音声認識をONにする
            mb_Voice_Recognition = True
        Catch
            '音声認識をOFFにする
            mb_Voice_Recognition = False
        End Try
        '音声認識をOFFにする
        If mb_Voice_Recognition = False Then
            chkVNEXT.Checked = False
            chkVBACK.Checked = False
            chkVNEXT.Enabled = False
            chkVBACK.Enabled = False
        End If
        'タイマー
        mo_Timer.Interval = CML_THREAD_INTERVAL
        mo_Timer.Start()
    End Sub

    Private Shared Sub TimerEventProcessor(myObject As Object, ByVal myEventArgs As EventArgs) Handles mo_Timer.Tick
        'Read Joy Pad
        Call GTRSTDO50.M0_READ_JOYPAD_STICK()
    End Sub

    Private Sub reco_RecognizeCompleted(ByVal sender As Object, ByVal e As System.Speech.Recognition.RecognizeCompletedEventArgs) Handles reco.RecognizeCompleted
        reco.RecognizeAsync()
    End Sub

    Private Sub reco_speechRecognized(ByVal sender As Object, ByVal e As System.Speech.Recognition.RecognitionEventArgs) Handles reco.SpeechRecognized
        Select Case e.Result.Text
            Case "voice recognize on", "voice recognition on"
                chkVNEXT.Checked = True
                chkVBACK.Checked = True
            Case "voice recognize off", "voice recognition off"
                chkVNEXT.Checked = False
                chkVBACK.Checked = False
            Case "next page", "go next", "go foward", "go ahead", "let's go"
                If chkVNEXT.Checked = True Then
                    Call M0_NEXT()
                End If
            Case "back page", "go back", "previous"
                If chkVBACK.Checked = True Then
                    Call M0_BACK()
                End If
        End Select
    End Sub

    Private Sub GTLG10_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        Select Case e.KeyCode
            Case Keys.Back
                If cmbNUM.SelectedIndex > 0 Then
                    cmbNUM.SelectedIndex = cmbNUM.SelectedIndex - 1
                End If
            Case Keys.Enter
                If cmbNUM.SelectedIndex < 200 Then
                    cmbNUM.SelectedIndex = cmbNUM.SelectedIndex + 1
                End If
        End Select
    End Sub

    Private Sub cmbNUM_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbNUM.SelectedIndexChanged
        Dim ls_File As String
        mi_Location_x = 0
        mi_Location_y = 0
        'ファイル名を設定
        ls_File = M2_GET_SLIDE_FILE()
        If System.IO.File.Exists(ls_File) Then
            '画像ファイルを表示
            Call M2_SET_IMAGE_RETRY(ls_File)
        End If
    End Sub

    Private Function M2_GET_SLIDE_FILE() As String
        Dim ls_pngFile As String
        Dim ls_jpgFile As String
        Dim ls_3gpFile As String
        Dim ls_mp4File As String
        '戻り値設定
        M2_GET_SLIDE_FILE = ""
        '処理抜け設定
        If cmbNUM.Text = "" Then
            Exit Function
        End If
        'ファイル名を設定
        ls_pngFile = ms_SLIDE_FILEPATH & ms_SLIDE_FILENAME_BASE & CInt(cmbNUM.Text).ToString("D3") & ".png"
        ls_jpgFile = ms_SLIDE_FILEPATH & ms_SLIDE_FILENAME_BASE & CInt(cmbNUM.Text).ToString("D3") & ".jpg"
        ls_3gpFile = ms_SLIDE_FILEPATH & ms_SLIDE_FILENAME_BASE & CInt(cmbNUM.Text).ToString("D3") & ".3gp"
        ls_mp4File = ms_SLIDE_FILEPATH & ms_SLIDE_FILENAME_BASE & CInt(cmbNUM.Text).ToString("D3") & ".mp4"
        If System.IO.File.Exists(ls_pngFile) Then
            M2_GET_SLIDE_FILE = ls_pngFile
        ElseIf System.IO.File.Exists(ls_jpgFile) Then
            M2_GET_SLIDE_FILE = ls_jpgFile
        ElseIf System.IO.File.Exists(ls_3gpFile) Then
            M2_GET_SLIDE_FILE = ls_3gpFile
        ElseIf System.IO.File.Exists(ls_mp4File) Then
            M2_GET_SLIDE_FILE = ls_mp4File
        End If
        '戻り値設定
        Return M2_GET_SLIDE_FILE
    End Function
    Private Sub M2_SET_IMAGE_RETRY(ByVal ps_File As String)
        Dim ll_Retry_index As Long
        For ll_Retry_index = 1 To 5
            Try
                If System.IO.Path.GetExtension(ps_File) = ".3gp" _
                Or System.IO.Path.GetExtension(ps_File) = ".mp4" Then
                    If System.IO.File.Exists(ps_File) Then
                        picSLIDE.Visible = False
                        wmpSLIDE.Visible = True
                        cmdUP.Visible = False
                        cmdDOWN.Visible = False
                        cmdLEFT.Visible = False
                        cmdRIGHT.Visible = False
                        wmpSLIDE.uiMode = "full"
                        wmpSLIDE.URL = ps_File
                        wmpSLIDE.settings.autoStart = True
                    End If
                Else
                    Select Case chkAutoFit.Checked
                        Case True
                            If System.IO.File.Exists(ps_File) Then
                                picSLIDE.Visible = True
                                wmpSLIDE.Visible = False
                                picSLIDE.Image = Image.FromFile(ps_File)
                                picSLIDE.SizeMode = PictureBoxSizeMode.Zoom
                            End If
                        Case False
                            If System.IO.File.Exists(ps_File) Then
                                picSLIDE.Visible = True
                                wmpSLIDE.Visible = False
                                Call M3_SET_IMAGE_WITH_ANGLE(ps_File)
                            End If
                    End Select
                End If
                Exit For
            Catch ex As System.IO.FileNotFoundException
                MessageBox.Show(ms_FILENOTFOUND_MESSAGE & vbCrLf & ps_File, ms_ERROR_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit For
            Catch ex As System.InvalidOperationException
                System.Diagnostics.Debug.WriteLine("System.InvalidOperationException; " & ps_File)
                System.Threading.Thread.Sleep(500)
                Exit For
            End Try
        Next ll_Retry_index
    End Sub

    Private Sub M3_SET_IMAGE_WITH_ANGLE(ps_File As String)
        Dim img As Bitmap
        Dim ld_angle As Decimal
        Dim x As Single
        Dim y As Single
        Dim x1 As Single
        Dim y1 As Single
        Dim x2 As Single
        Dim y2 As Single
        Dim x_for_fit As Single
        Dim y_for_fit As Single
        '描画先とするImageオブジェクトを作成する
        Dim canvas As New Bitmap(picSLIDE.Width, picSLIDE.Height)
        'ImageオブジェクトのGraphicsオブジェクトを作成する
        Dim g As Graphics = Graphics.FromImage(canvas)
        '描画する画像のBitmapオブジェクトを作成
        img = New Bitmap(ps_File)
        'ラジアン単位に変換
        If cmbANGLE.Text = "" Then
            ld_angle = 0
        Else
            ld_angle = CDec(cmbANGLE.Text)
        End If
        Dim d As Double = ld_angle / (180 / Math.PI)
        '新しい座標位置を計算する
        If cmbANGLE.Text = "" Then
            x = 0.0F
            y = 0.0F
        Else
            If CDec(cmbANGLE.Text) = 0 Then
                x = 0.0F
                y = 0.0F
            ElseIf System.Math.Abs(CDec(cmbANGLE.Text)) <= 1.0 Then
                x = 10.0F
                y = 10.0F
            ElseIf System.Math.Abs(CDec(cmbANGLE.Text)) <= 2.0 Then
                x = 20.0F
                y = 20.0F
            Else
                x = 30.0F
                y = 30.0F
            End If
        End If
        If mi_size_zoom = 0 Then
            x1 = x + img.Width * CType(Math.Cos(d), Single)
            y1 = y + img.Width * CType(Math.Sin(d), Single)
            x2 = x - img.Height * CType(Math.Sin(d), Single)
            y2 = y + img.Height * CType(Math.Cos(d), Single)
        Else
            x1 = x + img.Width * (mi_size_zoom / 100) * CType(Math.Cos(d), Single)
            y1 = y + img.Width * (mi_size_zoom / 100) * CType(Math.Sin(d), Single)
            x2 = x - img.Height * (mi_size_zoom / 100) * CType(Math.Sin(d), Single)
            y2 = y + img.Height * (mi_size_zoom / 100) * CType(Math.Cos(d), Single)
        End If
        If x < x2 Then
            If x < x1 Then
                'xが一番小さい
                x_for_fit = -x
            Else
                'x1が一番小さい
                x_for_fit = -x1
            End If
        Else
            If x1 < x2 Then
                'x1が一番小さい
                x_for_fit = -x1
            Else
                'x2が一番小さい
                x_for_fit = -x2
            End If
        End If
        If y < y2 Then
            If y < y1 Then
                'yが一番小さい
                y_for_fit = -y
            Else
                'y1が一番小さい
                y_for_fit = -y1
            End If
        Else
            If y1 < y2 Then
                'y1が一番小さい
                y_for_fit = -y1
            Else
                'y2が一番小さい
                y_for_fit = -y2
            End If
        End If
        'fitするようにズラす
        x = x + x_for_fit
        y = y + y_for_fit
        x1 = x1 + x_for_fit
        y1 = y1 + y_for_fit
        x2 = x2 + x_for_fit
        y2 = y2 + y_for_fit
        'Location由来でズラす
        x = x + (mi_Location_x * mi_size_zoom / 100)
        y = y + (mi_Location_y * mi_size_zoom / 100)
        x1 = x1 + (mi_Location_x * mi_size_zoom / 100)
        y1 = y1 + (mi_Location_y * mi_size_zoom / 100)
        x2 = x2 + (mi_Location_x * mi_size_zoom / 100)
        y2 = y2 + (mi_Location_y * mi_size_zoom / 100)
        'PointF配列を作成
        Dim destinationPoints() As PointF = {New PointF(x, y),
                            New PointF(x1, y1),
                            New PointF(x2, y2)}
        '画像を表示
        g.DrawImage(img, destinationPoints)
        'リソースを解放する
        img.Dispose()
        g.Dispose()
        '表示する
        picSLIDE.Image = canvas
    End Sub

    Private Sub cmbANGLE_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbANGLE.SelectedIndexChanged
        Call M0_IMAGE_REFRESH()
    End Sub

    Private Sub cmbZOOM_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbZOOM.SelectedIndexChanged
        If cmbZOOM.Text = "" Then
            mi_size_zoom = 100
        Else
            mi_size_zoom = CInt(cmbZOOM.Text)
        End If
        Call M0_IMAGE_REFRESH()
    End Sub

    Private Sub chkAutoFit_CheckedChanged(sender As Object, e As EventArgs) Handles chkAutoFit.CheckedChanged
        Select Case chkAutoFit.Checked
            Case True
                cmbANGLE.Text = "0.0"
                cmbANGLE.Enabled = False
                cmbZOOM.Text = "100"
                cmbZOOM.Enabled = False
                picSLIDE.SizeMode = PictureBoxSizeMode.Zoom
                cmdUP.Visible = False
                cmdDOWN.Visible = False
                cmdLEFT.Visible = False
                cmdRIGHT.Visible = False
                mi_Location_x = 0
                mi_Location_y = 0
                mi_size_zoom = 100
                picSLIDE.Width = Me.Width - 22
                picSLIDE.Height = Me.Height - 73
                Call M0_IMAGE_REFRESH()
            Case False
                cmbANGLE.Enabled = True
                cmbZOOM.Enabled = True
                picSLIDE.SizeMode = PictureBoxSizeMode.AutoSize
                cmdUP.Visible = True
                cmdDOWN.Visible = True
                cmdLEFT.Visible = True
                cmdRIGHT.Visible = True
                If picSLIDE.Width < Me.Width Then
                    mi_Location_x = 0
                Else
                    mi_Location_x = -picSLIDE.Width / 2 + Me.Width / 2 - 100
                End If
                If picSLIDE.Height < Me.Height Then
                    mi_Location_y = 0
                Else
                    mi_Location_y = -picSLIDE.Height / 2 + Me.Width / 2 - 200
                End If
                Call M0_IMAGE_REFRESH()
        End Select
    End Sub

    Private Sub picSLIDE_DoubleClick(sender As Object, e As EventArgs) Handles picSLIDE.DoubleClick
        Call M0_IMAGE_REFRESH()
    End Sub

    Private Sub cmdUP_Click(sender As Object, e As EventArgs) Handles cmdUP.Click
        Select Case chkAutoFit.Checked
            Case True
                'SKIP
            Case False
                Me.Cursor = Cursors.WaitCursor
                Call M0_GET_LOCATION_CHANGE()
                mi_Location_y = mi_Location_y + mi_Location_change
                Call M0_LOCATION_CHECK()
                Call M0_IMAGE_REFRESH()
                Me.Cursor = Cursors.Default
        End Select
    End Sub

    Private Sub cmdDOWN_Click(sender As Object, e As EventArgs) Handles cmdDOWN.Click
        Select Case chkAutoFit.Checked
            Case True
                'SKIP
            Case False
                Me.Cursor = Cursors.WaitCursor
                Call M0_GET_LOCATION_CHANGE()
                mi_Location_y = mi_Location_y - mi_Location_change
                Call M0_LOCATION_CHECK()
                Call M0_IMAGE_REFRESH()
                Me.Cursor = Cursors.Default
        End Select
    End Sub

    Private Sub cmdLEFT_Click(sender As Object, e As EventArgs) Handles cmdLEFT.Click
        Select Case chkAutoFit.Checked
            Case True
                'SKIP
            Case False
                Me.Cursor = Cursors.WaitCursor
                Call M0_GET_LOCATION_CHANGE()
                mi_Location_x = mi_Location_x + mi_Location_change
                Call M0_LOCATION_CHECK()
                Call M0_IMAGE_REFRESH()
                Me.Cursor = Cursors.Default
        End Select
    End Sub

    Private Sub cmdRIGHT_Click(sender As Object, e As EventArgs) Handles cmdRIGHT.Click
        Select Case chkAutoFit.Checked
            Case True
                'SKIP
            Case False
                Me.Cursor = Cursors.WaitCursor
                Call M0_GET_LOCATION_CHANGE()
                mi_Location_x = mi_Location_x - mi_Location_change
                Call M0_LOCATION_CHECK()
                Call M0_IMAGE_REFRESH()
                Me.Cursor = Cursors.Default
        End Select
    End Sub
    Private Sub M0_GET_LOCATION_CHANGE()
        If picSLIDE.Width > picSLIDE.Height Then
            mi_Location_change = picSLIDE.Width / 20
        Else
            mi_Location_change = picSLIDE.Height / 20
        End If
        If (mi_Location_change < 1) Then
            mi_Location_change = 1
        ElseIf (mi_Location_change > 100) Then
            mi_Location_change = 100
        End If
    End Sub
    Private Sub M0_LOCATION_CHECK()
        If mi_Location_x > 0 Then
            mi_Location_x = 0
        ElseIf mi_Location_x < (-picSLIDE.Width - picSLIDE.Left + cmdRIGHT.Location.X - 5) Then
            'バグっている気がするのでコメントアウト
            'mi_Location_x = (-picSLIDE.Width - picSLIDE.Left + cmdRIGHT.Location.X - 5)
        End If
        If mi_Location_y > 0 Then
            mi_Location_y = 0
        ElseIf mi_Location_y < (-picSLIDE.Height - picSLIDE.Top + cmdDOWN.Location.Y - 5) Then
            'バグっている気がするのでコメントアウト
            'mi_Location_y = (-picSLIDE.Height - picSLIDE.Top + cmdDOWN.Location.Y - 5)
        End If
    End Sub

    Private Sub M0_IMAGE_REFRESH()
        'ファイル名を設定
        Dim ls_File As String = M2_GET_SLIDE_FILE()
        If System.IO.File.Exists(ls_File) Then
            '画像ファイルを表示
            Call M2_SET_IMAGE_RETRY(ls_File)
        End If
    End Sub

End Class