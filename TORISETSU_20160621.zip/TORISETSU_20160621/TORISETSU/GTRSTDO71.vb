﻿Imports System.Drawing
Imports System.Speech
Imports Tao.Platform.Windows
Imports System
Imports System.Threading

Public Class GTRSTDO71
    'スレッド用モジュール変数
    Private Shared WithEvents mo_Timer As New System.Windows.Forms.Timer()
    Private Shared mb_ExitFlag As Boolean = False
    'スレッドタイマーインターバル
    Const CML_THREAD_INTERVAL As Long = 50
    'Joy Pad Status
    Dim ms_JOY_PAD_STATUS As String
    'SLIDEファイルパス
    'Dim ms_SLIDE_FILEPATH As String = "C:\DEVELOP\SLIDE\"
    Dim ms_SLIDE_FILEPATH As String = System.Windows.Forms.Application.StartupPath + "\FLIP\"
    'SLIDEファイル名ベース
    Dim ms_SLIDE_FILENAME_BASE As String = "FLIP"
    '音声認識利用可否
    Dim mb_Voice_Recognition As Boolean = False
    'メッセージ
    Dim ms_FILENOTFOUND_MESSAGE As String = "ERROR:IMAGE(FLIPxxx.jpg/.png) FILE NOT FOUND."
    Dim ms_ERROR_TITLE As String = "ERROR"
    Dim mi_size_zoom As Integer
    Dim mi_Location_x As Integer
    Dim mi_Location_y As Integer
    Dim mi_Location_change As Integer
    Dim mb_Drag As Boolean
    Dim mo_DragPoint As Point
    '音声認識
    Dim WithEvents reco As New Recognition.SpeechRecognitionEngine
    '表示中の画像
    Dim mi_FLIP_INDEX As Integer
    Dim ms_FLIP_VIEWING As String
    '元の場所
    Dim mi_OLD_Top As Integer
    Dim mi_OLD_Left As Integer
    Dim mi_OLD_Height As Integer
    Dim mi_OLD_Width As Integer

    Private Sub Form_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call M0_FORM_LOAD()
    End Sub

    Private Sub cmdEXIT_Click(sender As Object, e As EventArgs) Handles cmdEXIT.Click
        Me.Close()
    End Sub

    Private Sub M0_READ_JOYPAD_STICK()
        'Read JoyPad
        Dim joyinfo As Tao.Platform.Windows.Winmm.JOYINFO = New Tao.Platform.Windows.Winmm.JOYINFO()
        If (Tao.Platform.Windows.Winmm.joyGetPos(0, joyinfo) = Tao.Platform.Windows.Winmm.JOYERR_NOERROR) Then
            'Stick
            If (joyinfo.wXpos < (65535 * 0.1)) Then
                If (ms_JOY_PAD_STATUS = "READY") Then
                    ms_JOY_PAD_STATUS = "JOY_PAD_BACK"
                End If
            ElseIf (joyinfo.wXpos > (65535 * 0.9)) Then
                If (ms_JOY_PAD_STATUS = "READY") Then
                    ms_JOY_PAD_STATUS = "JOY_PAD_NEXT"
                End If
            Else
                ms_JOY_PAD_STATUS = "READY"
            End If
        End If
    End Sub

    Private Sub M0_FORM_LOAD()
        Dim ll_Index As Integer
        For ll_Index = 1 To 10
            cmbNUM.Items.Add(((ll_Index - 1) * 20 + 1).ToString("D3") & "-" & (ll_Index * 20).ToString("D3"))
        Next
        cmbNUM.SelectedIndex = 0
        'タイマー
        mo_Timer.Interval = CML_THREAD_INTERVAL
        mo_Timer.Start()
    End Sub

    Private Shared Sub TimerEventProcessor(myObject As Object, ByVal myEventArgs As EventArgs) Handles mo_Timer.Tick
        'Read Joy Pad
        Call GTRSTDO71.M0_READ_JOYPAD_STICK()
    End Sub

    Private Sub M2_SET_IMAGE_RETRY(ByVal pi_Index As Integer, ByVal ps_File As String)
        Dim ll_Retry_index As Long
        Dim li_FLIP_Pos As Integer
        li_FLIP_Pos = pi_Index Mod 20
        If li_FLIP_Pos = 0 Then
            li_FLIP_Pos = 20
        End If
        Dim cs1 As Control() = Me.Controls.Find("picFLIP" & li_FLIP_Pos.ToString("D2"), True)
        For ll_Retry_index = 1 To 5
            Try
                If System.IO.File.Exists(ps_File) Then
                    If cs1.Length > 0 Then
                        CType(cs1(0), PictureBox).Visible = True
                        CType(cs1(0), PictureBox).Image = Image.FromFile(ps_File)
                        CType(cs1(0), PictureBox).SizeMode = PictureBoxSizeMode.Zoom
                    End If
                Else
                    If cs1.Length > 0 Then
                        CType(cs1(0), PictureBox).Visible = False
                    End If
                End If
                Exit For
            Catch ex As System.IO.FileNotFoundException
                MessageBox.Show(ms_FILENOTFOUND_MESSAGE & vbCrLf & ps_File, ms_ERROR_TITLE, MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit For
            Catch ex As System.InvalidOperationException
                System.Diagnostics.Debug.WriteLine("System.InvalidOperationException; " & ps_File)
                System.Threading.Thread.Sleep(500)
                Exit For
            End Try
        Next ll_Retry_index
    End Sub

    Private Sub M1_FLIP_VIEW(pi_Index As Integer)
        Dim li_FLIP_Pos As Integer
        li_FLIP_Pos = pi_Index Mod 20
        If li_FLIP_Pos = 0 Then
            li_FLIP_Pos = 20
        End If
        Dim li_Start_Top As String
        Dim li_Start_Left As String
        Dim ls_PngFile As String = ms_SLIDE_FILEPATH + "FLIP" + pi_Index.ToString("D3") + ".png"
        Dim ls_JpgFile As String = ms_SLIDE_FILEPATH + "FLIP" + pi_Index.ToString("D3") + ".Jpg"
        Dim cs1 As Control() = Me.Controls.Find("picFLIP" & li_FLIP_Pos.ToString("D2"), True)
        Dim cs2 As Control() = Me.Controls.Find("pnlFLIP" & li_FLIP_Pos.ToString("D2"), True)
        If cs2.Length > 0 Then
            CType(cs2(0), Panel).BackColor = Color.DarkGray
        End If
        picSLIDE.Visible = False
        If System.IO.File.Exists(ls_JpgFile) Then
            picSLIDE.Image = Image.FromFile(ls_JpgFile)
            mi_FLIP_INDEX = pi_Index
            ms_FLIP_VIEWING = ls_JpgFile
        Else
            picSLIDE.Image = Image.FromFile(ls_PngFile)
            mi_FLIP_INDEX = pi_Index
            ms_FLIP_VIEWING = ls_PngFile
        End If
        picSLIDE.SizeMode = PictureBoxSizeMode.Zoom
        picSLIDE.Visible = True
        '初期の場所
        li_Start_Top = pnlFLIP.Top + (pnlFLIP.Height \ 4) * ((li_FLIP_Pos - 1) \ 5)
        li_Start_Left = pnlFLIP.Left + (pnlFLIP.Width \ 5) * ((li_FLIP_Pos - 1) Mod 5)
        '元に戻る時用の情報取得
        mi_OLD_Top = li_Start_Top
        mi_OLD_Left = li_Start_Left
        mi_OLD_Height = pnlFLIP01.Height
        mi_OLD_Width = pnlFLIP01.Width
        Dim li_idx As Integer
        Dim li_max As Integer = 5
        For li_idx = 1 To li_max
            picSLIDE.Top = M2_CALC_VAL(li_Start_Top, pnlFLIP.Top, li_idx, li_max)
            picSLIDE.Left = M2_CALC_VAL(li_Start_Left, pnlFLIP.Left, li_idx, li_max)
            picSLIDE.Width = M2_CALC_VAL(pnlFLIP01.Width, pnlFLIP.Width, li_idx, li_max)
            picSLIDE.Height = M2_CALC_VAL(pnlFLIP01.Height, pnlFLIP.Height, li_idx, li_max)
            System.Windows.Forms.Application.DoEvents()
        Next
        picSLIDE.Top = pnlFLIP.Top
        picSLIDE.Left = pnlFLIP.Left
        picSLIDE.Width = pnlFLIP.Width
        picSLIDE.Height = pnlFLIP.Height
        picSLIDE.Anchor = AnchorStyles.Bottom AndAlso AnchorStyles.Left AndAlso AnchorStyles.Right AndAlso AnchorStyles.Top
    End Sub

    Private Function M2_CALC_VAL(pi_Start As Integer, pi_End As Integer, pi_Idx As Integer, pi_Max As Integer) As Integer
        Dim li_Ret As Integer
        If pi_Idx >= pi_Max Then
            li_Ret = pi_End
        ElseIf pi_Idx <= 1 Then
            li_Ret = pi_Start
        Else
            li_Ret = pi_Start + CInt((pi_End - pi_Start) * (CDbl(pi_Idx) / CDbl(pi_Max)))
        End If
        Return li_Ret
    End Function

    Private Sub M0_FLIPS_REFRESH()
        Dim li_Start As Integer
        Dim li_End As Integer
        li_Start = ((cmbNUM.SelectedIndex) * 20 + 1)
        li_End = li_Start + 19
        For li_index = 1 To 20
            Dim cs2 As Control() = Me.Controls.Find("pnlFLIP" & li_index.ToString("D2"), True)
            If cs2.Length > 0 Then
                CType(cs2(0), Panel).BackColor = Color.Transparent
            End If
        Next
        Dim ls_PngFile As String
        Dim ls_JpgFile As String
        For li_index = li_Start To li_End
            ls_PngFile = ms_SLIDE_FILEPATH + "FLIP" + li_index.ToString("D3") + ".png"
            ls_JpgFile = ms_SLIDE_FILEPATH + "FLIP" + li_index.ToString("D3") + ".jpg"
            If System.IO.File.Exists(ls_JpgFile) Then
                M2_SET_IMAGE_RETRY(li_index, ls_JpgFile)
            Else
                M2_SET_IMAGE_RETRY(li_index, ls_PngFile)
            End If
        Next
    End Sub

    Private Sub cmbNUM_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbNUM.SelectedIndexChanged
        Call M0_FLIPS_REFRESH()
    End Sub

    Private Sub picSLIDE_Click(sender As Object, e As EventArgs) Handles picSLIDE.Click
        Dim ls_PngFile As String = ms_SLIDE_FILEPATH + "FLIP" + mi_FLIP_INDEX.ToString("D3") + ".png"
        Dim ls_PngFile_b As String = ms_SLIDE_FILEPATH + "FLIP" + mi_FLIP_INDEX.ToString("D3") + "_b.png"
        Dim ls_JpgFile As String = ms_SLIDE_FILEPATH + "FLIP" + mi_FLIP_INDEX.ToString("D3") + ".Jpg"
        Dim ls_JpgFile_b As String = ms_SLIDE_FILEPATH + "FLIP" + mi_FLIP_INDEX.ToString("D3") + "_b.Jpg"
        If ms_FLIP_VIEWING = ls_PngFile And System.IO.File.Exists(ls_PngFile_b) Then
            picSLIDE.Image = Image.FromFile(ls_PngFile_b)
            ms_FLIP_VIEWING = ls_PngFile_b
        ElseIf ms_FLIP_VIEWING = ls_JpgFile And System.IO.File.Exists(ls_JpgFile_b) Then
            picSLIDE.Image = Image.FromFile(ls_JpgFile_b)
            ms_FLIP_VIEWING = ls_JpgFile_b
        Else
            Dim li_idx As Integer
            Dim li_max As Integer = 5
            For li_idx = 1 To li_max
                picSLIDE.Top = M2_CALC_VAL(pnlFLIP.Top, mi_OLD_Top, li_idx, li_max)
                picSLIDE.Left = M2_CALC_VAL(pnlFLIP.Left, mi_OLD_Left, li_idx, li_max)
                picSLIDE.Width = M2_CALC_VAL(pnlFLIP.Width, mi_OLD_Width, li_idx, li_max)
                picSLIDE.Height = M2_CALC_VAL(pnlFLIP.Height, mi_OLD_Height, li_idx, li_max)
                System.Windows.Forms.Application.DoEvents()
            Next
            picSLIDE.Visible = False
        End If
    End Sub

    Private Sub picFLIP01_Click(sender As Object, e As EventArgs) Handles picFLIP01.Click
        Dim li_Num As Integer = cmbNUM.SelectedIndex * 20 + 1
        Call M1_FLIP_VIEW(li_Num)
    End Sub

    Private Sub picFLIP02_Click(sender As Object, e As EventArgs) Handles picFLIP02.Click
        Dim li_Num As Integer = cmbNUM.SelectedIndex * 20 + 2
        Call M1_FLIP_VIEW(li_Num)
    End Sub

    Private Sub picFLIP03_Click(sender As Object, e As EventArgs) Handles picFLIP03.Click
        Dim li_Num As Integer = cmbNUM.SelectedIndex * 20 + 3
        Call M1_FLIP_VIEW(li_Num)
    End Sub

    Private Sub picFLIP04_Click(sender As Object, e As EventArgs) Handles picFLIP04.Click
        Dim li_Num As Integer = cmbNUM.SelectedIndex * 20 + 4
        Call M1_FLIP_VIEW(li_Num)
    End Sub

    Private Sub picFLIP05_Click(sender As Object, e As EventArgs) Handles picFLIP05.Click
        Dim li_Num As Integer = cmbNUM.SelectedIndex * 20 + 5
        Call M1_FLIP_VIEW(li_Num)
    End Sub

    Private Sub picFLIP06_Click(sender As Object, e As EventArgs) Handles picFLIP06.Click
        Dim li_Num As Integer = cmbNUM.SelectedIndex * 20 + 6
        Call M1_FLIP_VIEW(li_Num)
    End Sub

    Private Sub picFLIP07_Click(sender As Object, e As EventArgs) Handles picFLIP07.Click
        Dim li_Num As Integer = cmbNUM.SelectedIndex * 20 + 7
        Call M1_FLIP_VIEW(li_Num)
    End Sub

    Private Sub picFLIP08_Click(sender As Object, e As EventArgs) Handles picFLIP08.Click
        Dim li_Num As Integer = cmbNUM.SelectedIndex * 20 + 8
        Call M1_FLIP_VIEW(li_Num)
    End Sub

    Private Sub picFLIP09_Click(sender As Object, e As EventArgs) Handles picFLIP09.Click
        Dim li_Num As Integer = cmbNUM.SelectedIndex * 20 + 9
        Call M1_FLIP_VIEW(li_Num)
    End Sub

    Private Sub picFLIP10_Click(sender As Object, e As EventArgs) Handles picFLIP10.Click
        Dim li_Num As Integer = cmbNUM.SelectedIndex * 20 + 10
        Call M1_FLIP_VIEW(li_Num)
    End Sub

    Private Sub picFLIP11_Click(sender As Object, e As EventArgs) Handles picFLIP11.Click
        Dim li_Num As Integer = cmbNUM.SelectedIndex * 20 + 11
        Call M1_FLIP_VIEW(li_Num)
    End Sub

    Private Sub picFLIP12_Click(sender As Object, e As EventArgs) Handles picFLIP12.Click
        Dim li_Num As Integer = cmbNUM.SelectedIndex * 20 + 12
        Call M1_FLIP_VIEW(li_Num)
    End Sub

    Private Sub picFLIP13_Click(sender As Object, e As EventArgs) Handles picFLIP13.Click
        Dim li_Num As Integer = cmbNUM.SelectedIndex * 20 + 13
        Call M1_FLIP_VIEW(li_Num)
    End Sub

    Private Sub picFLIP14_Click(sender As Object, e As EventArgs) Handles picFLIP14.Click
        Dim li_Num As Integer = cmbNUM.SelectedIndex * 20 + 14
        Call M1_FLIP_VIEW(li_Num)
    End Sub

    Private Sub picFLIP15_Click(sender As Object, e As EventArgs) Handles picFLIP15.Click
        Dim li_Num As Integer = cmbNUM.SelectedIndex * 20 + 15
        Call M1_FLIP_VIEW(li_Num)
    End Sub

    Private Sub picFLIP16_Click(sender As Object, e As EventArgs) Handles picFLIP16.Click
        Dim li_Num As Integer = cmbNUM.SelectedIndex * 20 + 16
        Call M1_FLIP_VIEW(li_Num)
    End Sub

    Private Sub picFLIP17_Click(sender As Object, e As EventArgs) Handles picFLIP17.Click
        Dim li_Num As Integer = cmbNUM.SelectedIndex * 20 + 17
        Call M1_FLIP_VIEW(li_Num)
    End Sub

    Private Sub picFLIP18_Click(sender As Object, e As EventArgs) Handles picFLIP18.Click
        Dim li_Num As Integer = cmbNUM.SelectedIndex * 20 + 18
        Call M1_FLIP_VIEW(li_Num)
    End Sub

    Private Sub picFLIP19_Click(sender As Object, e As EventArgs) Handles picFLIP19.Click
        Dim li_Num As Integer = cmbNUM.SelectedIndex * 20 + 19
        Call M1_FLIP_VIEW(li_Num)
    End Sub

    Private Sub picFLIP20_Click(sender As Object, e As EventArgs) Handles picFLIP20.Click
        Dim li_Num As Integer = cmbNUM.SelectedIndex * 20 + 20
        Call M1_FLIP_VIEW(li_Num)
    End Sub

End Class