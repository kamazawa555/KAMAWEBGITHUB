﻿Public Class GTRSTMN00

    Private Sub cmdSLIDE_Click(sender As Object, e As EventArgs) Handles cmdSLIDE.Click
        GTRSTDO10.Show()
    End Sub

    Private Sub cmdSCREENSHOT_Click(sender As Object, e As EventArgs) Handles cmdSCREENSHOT.Click
        GTRSTDO20.Show()
    End Sub

    Private Sub cmdPHOTO_Click(sender As Object, e As EventArgs) Handles cmdPHOTO.Click
        GTRSTDO30.Show()
    End Sub

    Private Sub cmdPICTURE_Click(sender As Object, e As EventArgs) Handles cmdPICTURE.Click
        GTRSTDO40.Show()
    End Sub

    Private Sub cmdIMAGE_Click(sender As Object, e As EventArgs) Handles cmdIMAGE.Click
        GTRSTDO50.Show()
    End Sub

    Private Sub cmdSNAPSHOT_Click(sender As Object, e As EventArgs) Handles cmdSNAPSHOT.Click
        GTRSTDO60.Show()
    End Sub

    Private Sub cmdFLIP_Click(sender As Object, e As EventArgs) Handles cmdFLIP.Click
        GTRSTDO70.Show()
    End Sub

    Private Sub cmdFLIP2_Click(sender As Object, e As EventArgs) Handles cmdFLIP2.Click
        GTRSTDO71.Show()
    End Sub
End Class
