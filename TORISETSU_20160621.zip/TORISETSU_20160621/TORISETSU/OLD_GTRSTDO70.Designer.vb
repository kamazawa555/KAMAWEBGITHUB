﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class GTRSTDO70
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(GTRSTDO70))
        Me.chkVBACK = New System.Windows.Forms.CheckBox()
        Me.chkVNEXT = New System.Windows.Forms.CheckBox()
        Me.cmdRIGHT = New System.Windows.Forms.Button()
        Me.cmdDOWN = New System.Windows.Forms.Button()
        Me.cmdLEFT = New System.Windows.Forms.Button()
        Me.cmdUP = New System.Windows.Forms.Button()
        Me.chkAutoFit = New System.Windows.Forms.CheckBox()
        Me.cmbZOOM = New System.Windows.Forms.ComboBox()
        Me.lblZOOM = New System.Windows.Forms.Label()
        Me.lblANGLE = New System.Windows.Forms.Label()
        Me.cmbANGLE = New System.Windows.Forms.ComboBox()
        Me.cmdNEXT = New System.Windows.Forms.Button()
        Me.cmbNUM = New System.Windows.Forms.ComboBox()
        Me.cmdEXIT = New System.Windows.Forms.Button()
        Me.cmdBACK = New System.Windows.Forms.Button()
        Me.picSLIDE = New System.Windows.Forms.PictureBox()
        Me.wmpSLIDE = New AxWMPLib.AxWindowsMediaPlayer()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.AxWindowsMediaPlayer1 = New AxWMPLib.AxWindowsMediaPlayer()
        CType(Me.picSLIDE, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.wmpSLIDE, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.AxWindowsMediaPlayer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'chkVBACK
        '
        Me.chkVBACK.AutoSize = True
        Me.chkVBACK.Checked = True
        Me.chkVBACK.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkVBACK.Location = New System.Drawing.Point(361, -55)
        Me.chkVBACK.Name = "chkVBACK"
        Me.chkVBACK.Size = New System.Drawing.Size(127, 16)
        Me.chkVBACK.TabIndex = 516
        Me.chkVBACK.Text = "VOICE BACK PAGE"
        Me.chkVBACK.UseVisualStyleBackColor = True
        '
        'chkVNEXT
        '
        Me.chkVNEXT.AutoSize = True
        Me.chkVNEXT.Checked = True
        Me.chkVNEXT.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkVNEXT.Location = New System.Drawing.Point(208, -55)
        Me.chkVNEXT.Name = "chkVNEXT"
        Me.chkVNEXT.Size = New System.Drawing.Size(125, 16)
        Me.chkVNEXT.TabIndex = 515
        Me.chkVNEXT.Text = "VOICE NEXT PAGE"
        Me.chkVNEXT.UseVisualStyleBackColor = True
        '
        'cmdRIGHT
        '
        Me.cmdRIGHT.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.cmdRIGHT.Location = New System.Drawing.Point(1260, 183)
        Me.cmdRIGHT.Name = "cmdRIGHT"
        Me.cmdRIGHT.Size = New System.Drawing.Size(20, 50)
        Me.cmdRIGHT.TabIndex = 511
        Me.cmdRIGHT.TabStop = False
        Me.cmdRIGHT.Text = "→"
        Me.cmdRIGHT.UseVisualStyleBackColor = True
        '
        'cmdDOWN
        '
        Me.cmdDOWN.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.cmdDOWN.Location = New System.Drawing.Point(438, 418)
        Me.cmdDOWN.Name = "cmdDOWN"
        Me.cmdDOWN.Size = New System.Drawing.Size(50, 20)
        Me.cmdDOWN.TabIndex = 512
        Me.cmdDOWN.TabStop = False
        Me.cmdDOWN.Text = "↓"
        Me.cmdDOWN.UseVisualStyleBackColor = True
        '
        'cmdLEFT
        '
        Me.cmdLEFT.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.cmdLEFT.Location = New System.Drawing.Point(-330, 183)
        Me.cmdLEFT.Name = "cmdLEFT"
        Me.cmdLEFT.Size = New System.Drawing.Size(20, 50)
        Me.cmdLEFT.TabIndex = 510
        Me.cmdLEFT.TabStop = False
        Me.cmdLEFT.Text = "←"
        Me.cmdLEFT.UseVisualStyleBackColor = True
        '
        'cmdUP
        '
        Me.cmdUP.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.cmdUP.Location = New System.Drawing.Point(438, -30)
        Me.cmdUP.Name = "cmdUP"
        Me.cmdUP.Size = New System.Drawing.Size(50, 20)
        Me.cmdUP.TabIndex = 509
        Me.cmdUP.TabStop = False
        Me.cmdUP.Text = "↑"
        Me.cmdUP.UseVisualStyleBackColor = True
        '
        'chkAutoFit
        '
        Me.chkAutoFit.AutoSize = True
        Me.chkAutoFit.Checked = True
        Me.chkAutoFit.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkAutoFit.Location = New System.Drawing.Point(-94, -56)
        Me.chkAutoFit.Name = "chkAutoFit"
        Me.chkAutoFit.Size = New System.Drawing.Size(72, 16)
        Me.chkAutoFit.TabIndex = 504
        Me.chkAutoFit.Text = "AUTOFIT"
        Me.chkAutoFit.UseVisualStyleBackColor = True
        '
        'cmbZOOM
        '
        Me.cmbZOOM.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbZOOM.FormattingEnabled = True
        Me.cmbZOOM.Location = New System.Drawing.Point(146, -58)
        Me.cmbZOOM.Name = "cmbZOOM"
        Me.cmbZOOM.Size = New System.Drawing.Size(43, 20)
        Me.cmbZOOM.TabIndex = 506
        '
        'lblZOOM
        '
        Me.lblZOOM.AutoSize = True
        Me.lblZOOM.Location = New System.Drawing.Point(103, -54)
        Me.lblZOOM.Name = "lblZOOM"
        Me.lblZOOM.Size = New System.Drawing.Size(37, 12)
        Me.lblZOOM.TabIndex = 508
        Me.lblZOOM.Text = "ZOOM"
        '
        'lblANGLE
        '
        Me.lblANGLE.AutoSize = True
        Me.lblANGLE.Location = New System.Drawing.Point(-4, -54)
        Me.lblANGLE.Name = "lblANGLE"
        Me.lblANGLE.Size = New System.Drawing.Size(42, 12)
        Me.lblANGLE.TabIndex = 507
        Me.lblANGLE.Text = "ANGLE"
        '
        'cmbANGLE
        '
        Me.cmbANGLE.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbANGLE.FormattingEnabled = True
        Me.cmbANGLE.Location = New System.Drawing.Point(44, -57)
        Me.cmbANGLE.Name = "cmbANGLE"
        Me.cmbANGLE.Size = New System.Drawing.Size(53, 20)
        Me.cmbANGLE.TabIndex = 505
        '
        'cmdNEXT
        '
        Me.cmdNEXT.BackColor = System.Drawing.Color.GreenYellow
        Me.cmdNEXT.Location = New System.Drawing.Point(-189, -58)
        Me.cmdNEXT.Name = "cmdNEXT"
        Me.cmdNEXT.Size = New System.Drawing.Size(76, 22)
        Me.cmdNEXT.TabIndex = 503
        Me.cmdNEXT.Text = "NEXT"
        Me.cmdNEXT.UseVisualStyleBackColor = False
        '
        'cmbNUM
        '
        Me.cmbNUM.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbNUM.FormattingEnabled = True
        Me.cmbNUM.Location = New System.Drawing.Point(-248, -57)
        Me.cmbNUM.Name = "cmbNUM"
        Me.cmbNUM.Size = New System.Drawing.Size(53, 20)
        Me.cmbNUM.TabIndex = 502
        '
        'cmdEXIT
        '
        Me.cmdEXIT.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdEXIT.Location = New System.Drawing.Point(1210, -57)
        Me.cmdEXIT.Name = "cmdEXIT"
        Me.cmdEXIT.Size = New System.Drawing.Size(70, 22)
        Me.cmdEXIT.TabIndex = 517
        Me.cmdEXIT.Text = "EXIT"
        Me.cmdEXIT.UseVisualStyleBackColor = True
        '
        'cmdBACK
        '
        Me.cmdBACK.Location = New System.Drawing.Point(-330, -58)
        Me.cmdBACK.Name = "cmdBACK"
        Me.cmdBACK.Size = New System.Drawing.Size(76, 22)
        Me.cmdBACK.TabIndex = 501
        Me.cmdBACK.TabStop = False
        Me.cmdBACK.Text = "BACK"
        Me.cmdBACK.UseVisualStyleBackColor = True
        '
        'picSLIDE
        '
        Me.picSLIDE.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picSLIDE.Location = New System.Drawing.Point(-330, -29)
        Me.picSLIDE.Name = "picSLIDE"
        Me.picSLIDE.Size = New System.Drawing.Size(1610, 467)
        Me.picSLIDE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picSLIDE.TabIndex = 513
        Me.picSLIDE.TabStop = False
        '
        'wmpSLIDE
        '
        Me.wmpSLIDE.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.wmpSLIDE.Enabled = True
        Me.wmpSLIDE.Location = New System.Drawing.Point(-330, -29)
        Me.wmpSLIDE.Name = "wmpSLIDE"
        Me.wmpSLIDE.OcxState = CType(resources.GetObject("wmpSLIDE.OcxState"), System.Windows.Forms.AxHost.State)
        Me.wmpSLIDE.Size = New System.Drawing.Size(1610, 467)
        Me.wmpSLIDE.TabIndex = 514
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Checked = True
        Me.CheckBox1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox1.Location = New System.Drawing.Point(694, 5)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(127, 16)
        Me.CheckBox1.TabIndex = 533
        Me.CheckBox1.Text = "VOICE BACK PAGE"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Checked = True
        Me.CheckBox2.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox2.Location = New System.Drawing.Point(541, 5)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(125, 16)
        Me.CheckBox2.TabIndex = 532
        Me.CheckBox2.Text = "VOICE NEXT PAGE"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Anchor = System.Windows.Forms.AnchorStyles.Right
        Me.Button1.Location = New System.Drawing.Point(927, 183)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(20, 50)
        Me.Button1.TabIndex = 528
        Me.Button1.TabStop = False
        Me.Button1.Text = "→"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.Button2.Location = New System.Drawing.Point(438, 358)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(50, 20)
        Me.Button2.TabIndex = 529
        Me.Button2.TabStop = False
        Me.Button2.Text = "↓"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.Button3.Location = New System.Drawing.Point(3, 183)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(20, 50)
        Me.Button3.TabIndex = 527
        Me.Button3.TabStop = False
        Me.Button3.Text = "←"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Button4.Location = New System.Drawing.Point(438, 30)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(50, 20)
        Me.Button4.TabIndex = 526
        Me.Button4.TabStop = False
        Me.Button4.Text = "↑"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.Checked = True
        Me.CheckBox3.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox3.Location = New System.Drawing.Point(239, 4)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(72, 16)
        Me.CheckBox3.TabIndex = 521
        Me.CheckBox3.Text = "AUTOFIT"
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'ComboBox1
        '
        Me.ComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(479, 2)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(43, 20)
        Me.ComboBox1.TabIndex = 523
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(436, 6)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(37, 12)
        Me.Label1.TabIndex = 525
        Me.Label1.Text = "ZOOM"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(329, 6)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(42, 12)
        Me.Label2.TabIndex = 524
        Me.Label2.Text = "ANGLE"
        '
        'ComboBox2
        '
        Me.ComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(377, 3)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(53, 20)
        Me.ComboBox2.TabIndex = 522
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.GreenYellow
        Me.Button5.Location = New System.Drawing.Point(144, 2)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(76, 22)
        Me.Button5.TabIndex = 520
        Me.Button5.Text = "NEXT"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'ComboBox3
        '
        Me.ComboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Location = New System.Drawing.Point(85, 3)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(53, 20)
        Me.ComboBox3.TabIndex = 519
        '
        'Button6
        '
        Me.Button6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button6.Location = New System.Drawing.Point(877, 3)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(70, 22)
        Me.Button6.TabIndex = 534
        Me.Button6.Text = "EXIT"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(3, 2)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(76, 22)
        Me.Button7.TabIndex = 518
        Me.Button7.TabStop = False
        Me.Button7.Text = "BACK"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PictureBox1.Location = New System.Drawing.Point(3, 31)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(944, 347)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 530
        Me.PictureBox1.TabStop = False
        '
        'AxWindowsMediaPlayer1
        '
        Me.AxWindowsMediaPlayer1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.AxWindowsMediaPlayer1.Enabled = True
        Me.AxWindowsMediaPlayer1.Location = New System.Drawing.Point(3, 31)
        Me.AxWindowsMediaPlayer1.Name = "AxWindowsMediaPlayer1"
        Me.AxWindowsMediaPlayer1.OcxState = CType(resources.GetObject("AxWindowsMediaPlayer1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxWindowsMediaPlayer1.Size = New System.Drawing.Size(944, 347)
        Me.AxWindowsMediaPlayer1.TabIndex = 531
        '
        'GTRSTDO70
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(950, 381)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.CheckBox2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.CheckBox3)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.ComboBox2)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.ComboBox3)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.AxWindowsMediaPlayer1)
        Me.Controls.Add(Me.chkVBACK)
        Me.Controls.Add(Me.chkVNEXT)
        Me.Controls.Add(Me.cmdRIGHT)
        Me.Controls.Add(Me.cmdDOWN)
        Me.Controls.Add(Me.cmdLEFT)
        Me.Controls.Add(Me.cmdUP)
        Me.Controls.Add(Me.chkAutoFit)
        Me.Controls.Add(Me.cmbZOOM)
        Me.Controls.Add(Me.lblZOOM)
        Me.Controls.Add(Me.lblANGLE)
        Me.Controls.Add(Me.cmbANGLE)
        Me.Controls.Add(Me.cmdNEXT)
        Me.Controls.Add(Me.cmbNUM)
        Me.Controls.Add(Me.cmdEXIT)
        Me.Controls.Add(Me.cmdBACK)
        Me.Controls.Add(Me.picSLIDE)
        Me.Controls.Add(Me.wmpSLIDE)
        Me.Name = "GTRSTDO70"
        Me.Text = "GTRSTDO70"
        CType(Me.picSLIDE, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.wmpSLIDE, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.AxWindowsMediaPlayer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents chkVBACK As CheckBox
    Friend WithEvents chkVNEXT As CheckBox
    Friend WithEvents cmdRIGHT As Button
    Friend WithEvents cmdDOWN As Button
    Friend WithEvents cmdLEFT As Button
    Friend WithEvents cmdUP As Button
    Friend WithEvents chkAutoFit As CheckBox
    Friend WithEvents cmbZOOM As ComboBox
    Friend WithEvents lblZOOM As Label
    Friend WithEvents lblANGLE As Label
    Friend WithEvents cmbANGLE As ComboBox
    Friend WithEvents cmdNEXT As Button
    Friend WithEvents cmbNUM As ComboBox
    Friend WithEvents cmdEXIT As Button
    Friend WithEvents cmdBACK As Button
    Friend WithEvents picSLIDE As PictureBox
    Friend WithEvents wmpSLIDE As AxWMPLib.AxWindowsMediaPlayer
    Friend WithEvents CheckBox1 As CheckBox
    Friend WithEvents CheckBox2 As CheckBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents CheckBox3 As CheckBox
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents Button5 As Button
    Friend WithEvents ComboBox3 As ComboBox
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents AxWindowsMediaPlayer1 As AxWMPLib.AxWindowsMediaPlayer
End Class
