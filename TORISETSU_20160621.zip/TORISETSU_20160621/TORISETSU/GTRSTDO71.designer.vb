﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class GTRSTDO71
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.cmdEXIT = New System.Windows.Forms.Button()
        Me.picSLIDE = New System.Windows.Forms.PictureBox()
        Me.picFLIP06 = New System.Windows.Forms.PictureBox()
        Me.picFLIP07 = New System.Windows.Forms.PictureBox()
        Me.picFLIP08 = New System.Windows.Forms.PictureBox()
        Me.picFLIP09 = New System.Windows.Forms.PictureBox()
        Me.picFLIP11 = New System.Windows.Forms.PictureBox()
        Me.picFLIP12 = New System.Windows.Forms.PictureBox()
        Me.picFLIP13 = New System.Windows.Forms.PictureBox()
        Me.picFLIP14 = New System.Windows.Forms.PictureBox()
        Me.picFLIP16 = New System.Windows.Forms.PictureBox()
        Me.picFLIP17 = New System.Windows.Forms.PictureBox()
        Me.picFLIP18 = New System.Windows.Forms.PictureBox()
        Me.picFLIP20 = New System.Windows.Forms.PictureBox()
        Me.pnlFLIP = New System.Windows.Forms.TableLayoutPanel()
        Me.pnlFLIP01 = New System.Windows.Forms.Panel()
        Me.picFLIP01 = New System.Windows.Forms.PictureBox()
        Me.pnlFLIP02 = New System.Windows.Forms.Panel()
        Me.picFLIP02 = New System.Windows.Forms.PictureBox()
        Me.pnlFLIP03 = New System.Windows.Forms.Panel()
        Me.picFLIP03 = New System.Windows.Forms.PictureBox()
        Me.pnlFLIP04 = New System.Windows.Forms.Panel()
        Me.picFLIP04 = New System.Windows.Forms.PictureBox()
        Me.pnlFLIP05 = New System.Windows.Forms.Panel()
        Me.picFLIP05 = New System.Windows.Forms.PictureBox()
        Me.pnlFLIP06 = New System.Windows.Forms.Panel()
        Me.pnlFLIP07 = New System.Windows.Forms.Panel()
        Me.pnlFLIP08 = New System.Windows.Forms.Panel()
        Me.pnlFLIP09 = New System.Windows.Forms.Panel()
        Me.pnlFLIP10 = New System.Windows.Forms.Panel()
        Me.picFLIP10 = New System.Windows.Forms.PictureBox()
        Me.pnlFLIP11 = New System.Windows.Forms.Panel()
        Me.pnlFLIP12 = New System.Windows.Forms.Panel()
        Me.pnlFLIP13 = New System.Windows.Forms.Panel()
        Me.pnlFLIP14 = New System.Windows.Forms.Panel()
        Me.pnlFLIP15 = New System.Windows.Forms.Panel()
        Me.picFLIP15 = New System.Windows.Forms.PictureBox()
        Me.pnlFLIP16 = New System.Windows.Forms.Panel()
        Me.pnlFLIP17 = New System.Windows.Forms.Panel()
        Me.pnlFLIP18 = New System.Windows.Forms.Panel()
        Me.pnlFLIP19 = New System.Windows.Forms.Panel()
        Me.picFLIP19 = New System.Windows.Forms.PictureBox()
        Me.pnlFLIP20 = New System.Windows.Forms.Panel()
        Me.cmbNUM = New System.Windows.Forms.ComboBox()
        CType(Me.picSLIDE, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFLIP06, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFLIP07, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFLIP08, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFLIP09, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFLIP11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFLIP12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFLIP13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFLIP14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFLIP16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFLIP17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFLIP18, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFLIP20, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlFLIP.SuspendLayout()
        Me.pnlFLIP01.SuspendLayout()
        CType(Me.picFLIP01, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlFLIP02.SuspendLayout()
        CType(Me.picFLIP02, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlFLIP03.SuspendLayout()
        CType(Me.picFLIP03, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlFLIP04.SuspendLayout()
        CType(Me.picFLIP04, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlFLIP05.SuspendLayout()
        CType(Me.picFLIP05, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlFLIP06.SuspendLayout()
        Me.pnlFLIP07.SuspendLayout()
        Me.pnlFLIP08.SuspendLayout()
        Me.pnlFLIP09.SuspendLayout()
        Me.pnlFLIP10.SuspendLayout()
        CType(Me.picFLIP10, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlFLIP11.SuspendLayout()
        Me.pnlFLIP12.SuspendLayout()
        Me.pnlFLIP13.SuspendLayout()
        Me.pnlFLIP14.SuspendLayout()
        Me.pnlFLIP15.SuspendLayout()
        CType(Me.picFLIP15, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlFLIP16.SuspendLayout()
        Me.pnlFLIP17.SuspendLayout()
        Me.pnlFLIP18.SuspendLayout()
        Me.pnlFLIP19.SuspendLayout()
        CType(Me.picFLIP19, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnlFLIP20.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmdEXIT
        '
        Me.cmdEXIT.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdEXIT.Location = New System.Drawing.Point(933, 4)
        Me.cmdEXIT.Name = "cmdEXIT"
        Me.cmdEXIT.Size = New System.Drawing.Size(70, 22)
        Me.cmdEXIT.TabIndex = 500
        Me.cmdEXIT.Text = "EXIT"
        Me.cmdEXIT.UseVisualStyleBackColor = True
        '
        'picSLIDE
        '
        Me.picSLIDE.Location = New System.Drawing.Point(236, 3)
        Me.picSLIDE.Name = "picSLIDE"
        Me.picSLIDE.Size = New System.Drawing.Size(84, 26)
        Me.picSLIDE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picSLIDE.TabIndex = 215
        Me.picSLIDE.TabStop = False
        Me.picSLIDE.Visible = False
        '
        'picFLIP06
        '
        Me.picFLIP06.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picFLIP06.Location = New System.Drawing.Point(2, 2)
        Me.picFLIP06.Name = "picFLIP06"
        Me.picFLIP06.Size = New System.Drawing.Size(190, 112)
        Me.picFLIP06.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picFLIP06.TabIndex = 506
        Me.picFLIP06.TabStop = False
        '
        'picFLIP07
        '
        Me.picFLIP07.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picFLIP07.Location = New System.Drawing.Point(2, 2)
        Me.picFLIP07.Name = "picFLIP07"
        Me.picFLIP07.Size = New System.Drawing.Size(190, 112)
        Me.picFLIP07.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picFLIP07.TabIndex = 507
        Me.picFLIP07.TabStop = False
        '
        'picFLIP08
        '
        Me.picFLIP08.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picFLIP08.Location = New System.Drawing.Point(2, 2)
        Me.picFLIP08.Name = "picFLIP08"
        Me.picFLIP08.Size = New System.Drawing.Size(190, 112)
        Me.picFLIP08.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picFLIP08.TabIndex = 508
        Me.picFLIP08.TabStop = False
        '
        'picFLIP09
        '
        Me.picFLIP09.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picFLIP09.Location = New System.Drawing.Point(2, 2)
        Me.picFLIP09.Name = "picFLIP09"
        Me.picFLIP09.Size = New System.Drawing.Size(190, 112)
        Me.picFLIP09.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picFLIP09.TabIndex = 509
        Me.picFLIP09.TabStop = False
        '
        'picFLIP11
        '
        Me.picFLIP11.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picFLIP11.Location = New System.Drawing.Point(2, 2)
        Me.picFLIP11.Name = "picFLIP11"
        Me.picFLIP11.Size = New System.Drawing.Size(190, 112)
        Me.picFLIP11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picFLIP11.TabIndex = 511
        Me.picFLIP11.TabStop = False
        '
        'picFLIP12
        '
        Me.picFLIP12.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picFLIP12.Location = New System.Drawing.Point(2, 2)
        Me.picFLIP12.Name = "picFLIP12"
        Me.picFLIP12.Size = New System.Drawing.Size(190, 112)
        Me.picFLIP12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picFLIP12.TabIndex = 512
        Me.picFLIP12.TabStop = False
        '
        'picFLIP13
        '
        Me.picFLIP13.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picFLIP13.Location = New System.Drawing.Point(2, 2)
        Me.picFLIP13.Name = "picFLIP13"
        Me.picFLIP13.Size = New System.Drawing.Size(190, 112)
        Me.picFLIP13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picFLIP13.TabIndex = 513
        Me.picFLIP13.TabStop = False
        '
        'picFLIP14
        '
        Me.picFLIP14.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picFLIP14.Location = New System.Drawing.Point(2, 2)
        Me.picFLIP14.Name = "picFLIP14"
        Me.picFLIP14.Size = New System.Drawing.Size(190, 112)
        Me.picFLIP14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picFLIP14.TabIndex = 514
        Me.picFLIP14.TabStop = False
        '
        'picFLIP16
        '
        Me.picFLIP16.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picFLIP16.Location = New System.Drawing.Point(2, 2)
        Me.picFLIP16.Name = "picFLIP16"
        Me.picFLIP16.Size = New System.Drawing.Size(190, 112)
        Me.picFLIP16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picFLIP16.TabIndex = 516
        Me.picFLIP16.TabStop = False
        '
        'picFLIP17
        '
        Me.picFLIP17.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picFLIP17.Location = New System.Drawing.Point(2, 2)
        Me.picFLIP17.Name = "picFLIP17"
        Me.picFLIP17.Size = New System.Drawing.Size(190, 112)
        Me.picFLIP17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picFLIP17.TabIndex = 517
        Me.picFLIP17.TabStop = False
        '
        'picFLIP18
        '
        Me.picFLIP18.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picFLIP18.Location = New System.Drawing.Point(2, 2)
        Me.picFLIP18.Name = "picFLIP18"
        Me.picFLIP18.Size = New System.Drawing.Size(190, 112)
        Me.picFLIP18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picFLIP18.TabIndex = 518
        Me.picFLIP18.TabStop = False
        '
        'picFLIP20
        '
        Me.picFLIP20.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picFLIP20.Location = New System.Drawing.Point(2, 2)
        Me.picFLIP20.Name = "picFLIP20"
        Me.picFLIP20.Size = New System.Drawing.Size(190, 112)
        Me.picFLIP20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picFLIP20.TabIndex = 520
        Me.picFLIP20.TabStop = False
        '
        'pnlFLIP
        '
        Me.pnlFLIP.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlFLIP.ColumnCount = 5
        Me.pnlFLIP.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.pnlFLIP.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.pnlFLIP.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.pnlFLIP.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.pnlFLIP.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.0!))
        Me.pnlFLIP.Controls.Add(Me.pnlFLIP01, 0, 0)
        Me.pnlFLIP.Controls.Add(Me.pnlFLIP02, 1, 0)
        Me.pnlFLIP.Controls.Add(Me.pnlFLIP03, 2, 0)
        Me.pnlFLIP.Controls.Add(Me.pnlFLIP04, 3, 0)
        Me.pnlFLIP.Controls.Add(Me.pnlFLIP05, 4, 0)
        Me.pnlFLIP.Controls.Add(Me.pnlFLIP06, 0, 1)
        Me.pnlFLIP.Controls.Add(Me.pnlFLIP07, 1, 1)
        Me.pnlFLIP.Controls.Add(Me.pnlFLIP08, 2, 1)
        Me.pnlFLIP.Controls.Add(Me.pnlFLIP09, 3, 1)
        Me.pnlFLIP.Controls.Add(Me.pnlFLIP10, 4, 1)
        Me.pnlFLIP.Controls.Add(Me.pnlFLIP11, 0, 2)
        Me.pnlFLIP.Controls.Add(Me.pnlFLIP12, 1, 2)
        Me.pnlFLIP.Controls.Add(Me.pnlFLIP13, 2, 2)
        Me.pnlFLIP.Controls.Add(Me.pnlFLIP14, 3, 2)
        Me.pnlFLIP.Controls.Add(Me.pnlFLIP15, 4, 2)
        Me.pnlFLIP.Controls.Add(Me.pnlFLIP16, 0, 3)
        Me.pnlFLIP.Controls.Add(Me.pnlFLIP17, 1, 3)
        Me.pnlFLIP.Controls.Add(Me.pnlFLIP18, 2, 3)
        Me.pnlFLIP.Controls.Add(Me.pnlFLIP19, 3, 3)
        Me.pnlFLIP.Controls.Add(Me.pnlFLIP20, 4, 3)
        Me.pnlFLIP.Location = New System.Drawing.Point(3, 32)
        Me.pnlFLIP.Name = "pnlFLIP"
        Me.pnlFLIP.RowCount = 4
        Me.pnlFLIP.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.pnlFLIP.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.pnlFLIP.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.pnlFLIP.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.pnlFLIP.Size = New System.Drawing.Size(1000, 488)
        Me.pnlFLIP.TabIndex = 521
        '
        'pnlFLIP01
        '
        Me.pnlFLIP01.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlFLIP01.Controls.Add(Me.picFLIP01)
        Me.pnlFLIP01.Location = New System.Drawing.Point(3, 3)
        Me.pnlFLIP01.Name = "pnlFLIP01"
        Me.pnlFLIP01.Size = New System.Drawing.Size(194, 116)
        Me.pnlFLIP01.TabIndex = 529
        '
        'picFLIP01
        '
        Me.picFLIP01.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picFLIP01.Location = New System.Drawing.Point(2, 2)
        Me.picFLIP01.Name = "picFLIP01"
        Me.picFLIP01.Size = New System.Drawing.Size(190, 112)
        Me.picFLIP01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picFLIP01.TabIndex = 523
        Me.picFLIP01.TabStop = False
        '
        'pnlFLIP02
        '
        Me.pnlFLIP02.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlFLIP02.Controls.Add(Me.picFLIP02)
        Me.pnlFLIP02.Location = New System.Drawing.Point(203, 3)
        Me.pnlFLIP02.Name = "pnlFLIP02"
        Me.pnlFLIP02.Size = New System.Drawing.Size(194, 116)
        Me.pnlFLIP02.TabIndex = 530
        '
        'picFLIP02
        '
        Me.picFLIP02.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picFLIP02.Location = New System.Drawing.Point(2, 2)
        Me.picFLIP02.Name = "picFLIP02"
        Me.picFLIP02.Size = New System.Drawing.Size(190, 112)
        Me.picFLIP02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picFLIP02.TabIndex = 524
        Me.picFLIP02.TabStop = False
        '
        'pnlFLIP03
        '
        Me.pnlFLIP03.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlFLIP03.Controls.Add(Me.picFLIP03)
        Me.pnlFLIP03.Location = New System.Drawing.Point(403, 3)
        Me.pnlFLIP03.Name = "pnlFLIP03"
        Me.pnlFLIP03.Size = New System.Drawing.Size(194, 116)
        Me.pnlFLIP03.TabIndex = 531
        '
        'picFLIP03
        '
        Me.picFLIP03.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picFLIP03.Location = New System.Drawing.Point(2, 2)
        Me.picFLIP03.Name = "picFLIP03"
        Me.picFLIP03.Size = New System.Drawing.Size(190, 112)
        Me.picFLIP03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picFLIP03.TabIndex = 525
        Me.picFLIP03.TabStop = False
        '
        'pnlFLIP04
        '
        Me.pnlFLIP04.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlFLIP04.Controls.Add(Me.picFLIP04)
        Me.pnlFLIP04.Location = New System.Drawing.Point(603, 3)
        Me.pnlFLIP04.Name = "pnlFLIP04"
        Me.pnlFLIP04.Size = New System.Drawing.Size(194, 116)
        Me.pnlFLIP04.TabIndex = 532
        '
        'picFLIP04
        '
        Me.picFLIP04.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picFLIP04.Location = New System.Drawing.Point(2, 2)
        Me.picFLIP04.Name = "picFLIP04"
        Me.picFLIP04.Size = New System.Drawing.Size(190, 112)
        Me.picFLIP04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picFLIP04.TabIndex = 526
        Me.picFLIP04.TabStop = False
        '
        'pnlFLIP05
        '
        Me.pnlFLIP05.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlFLIP05.Controls.Add(Me.picFLIP05)
        Me.pnlFLIP05.Location = New System.Drawing.Point(803, 3)
        Me.pnlFLIP05.Name = "pnlFLIP05"
        Me.pnlFLIP05.Size = New System.Drawing.Size(194, 116)
        Me.pnlFLIP05.TabIndex = 533
        '
        'picFLIP05
        '
        Me.picFLIP05.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picFLIP05.Location = New System.Drawing.Point(2, 2)
        Me.picFLIP05.Name = "picFLIP05"
        Me.picFLIP05.Size = New System.Drawing.Size(190, 112)
        Me.picFLIP05.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picFLIP05.TabIndex = 527
        Me.picFLIP05.TabStop = False
        '
        'pnlFLIP06
        '
        Me.pnlFLIP06.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlFLIP06.Controls.Add(Me.picFLIP06)
        Me.pnlFLIP06.Location = New System.Drawing.Point(3, 125)
        Me.pnlFLIP06.Name = "pnlFLIP06"
        Me.pnlFLIP06.Size = New System.Drawing.Size(194, 116)
        Me.pnlFLIP06.TabIndex = 534
        '
        'pnlFLIP07
        '
        Me.pnlFLIP07.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlFLIP07.Controls.Add(Me.picFLIP07)
        Me.pnlFLIP07.Location = New System.Drawing.Point(203, 125)
        Me.pnlFLIP07.Name = "pnlFLIP07"
        Me.pnlFLIP07.Size = New System.Drawing.Size(194, 116)
        Me.pnlFLIP07.TabIndex = 535
        '
        'pnlFLIP08
        '
        Me.pnlFLIP08.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlFLIP08.Controls.Add(Me.picFLIP08)
        Me.pnlFLIP08.Location = New System.Drawing.Point(403, 125)
        Me.pnlFLIP08.Name = "pnlFLIP08"
        Me.pnlFLIP08.Size = New System.Drawing.Size(194, 116)
        Me.pnlFLIP08.TabIndex = 536
        '
        'pnlFLIP09
        '
        Me.pnlFLIP09.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlFLIP09.Controls.Add(Me.picFLIP09)
        Me.pnlFLIP09.Location = New System.Drawing.Point(603, 125)
        Me.pnlFLIP09.Name = "pnlFLIP09"
        Me.pnlFLIP09.Size = New System.Drawing.Size(194, 116)
        Me.pnlFLIP09.TabIndex = 537
        '
        'pnlFLIP10
        '
        Me.pnlFLIP10.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlFLIP10.Controls.Add(Me.picFLIP10)
        Me.pnlFLIP10.Location = New System.Drawing.Point(803, 125)
        Me.pnlFLIP10.Name = "pnlFLIP10"
        Me.pnlFLIP10.Size = New System.Drawing.Size(194, 116)
        Me.pnlFLIP10.TabIndex = 538
        '
        'picFLIP10
        '
        Me.picFLIP10.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picFLIP10.Location = New System.Drawing.Point(2, 2)
        Me.picFLIP10.Name = "picFLIP10"
        Me.picFLIP10.Size = New System.Drawing.Size(190, 112)
        Me.picFLIP10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picFLIP10.TabIndex = 527
        Me.picFLIP10.TabStop = False
        '
        'pnlFLIP11
        '
        Me.pnlFLIP11.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlFLIP11.Controls.Add(Me.picFLIP11)
        Me.pnlFLIP11.Location = New System.Drawing.Point(3, 247)
        Me.pnlFLIP11.Name = "pnlFLIP11"
        Me.pnlFLIP11.Size = New System.Drawing.Size(194, 116)
        Me.pnlFLIP11.TabIndex = 539
        '
        'pnlFLIP12
        '
        Me.pnlFLIP12.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlFLIP12.Controls.Add(Me.picFLIP12)
        Me.pnlFLIP12.Location = New System.Drawing.Point(203, 247)
        Me.pnlFLIP12.Name = "pnlFLIP12"
        Me.pnlFLIP12.Size = New System.Drawing.Size(194, 116)
        Me.pnlFLIP12.TabIndex = 540
        '
        'pnlFLIP13
        '
        Me.pnlFLIP13.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlFLIP13.Controls.Add(Me.picFLIP13)
        Me.pnlFLIP13.Location = New System.Drawing.Point(403, 247)
        Me.pnlFLIP13.Name = "pnlFLIP13"
        Me.pnlFLIP13.Size = New System.Drawing.Size(194, 116)
        Me.pnlFLIP13.TabIndex = 541
        '
        'pnlFLIP14
        '
        Me.pnlFLIP14.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlFLIP14.Controls.Add(Me.picFLIP14)
        Me.pnlFLIP14.Location = New System.Drawing.Point(603, 247)
        Me.pnlFLIP14.Name = "pnlFLIP14"
        Me.pnlFLIP14.Size = New System.Drawing.Size(194, 116)
        Me.pnlFLIP14.TabIndex = 542
        '
        'pnlFLIP15
        '
        Me.pnlFLIP15.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlFLIP15.Controls.Add(Me.picFLIP15)
        Me.pnlFLIP15.Location = New System.Drawing.Point(803, 247)
        Me.pnlFLIP15.Name = "pnlFLIP15"
        Me.pnlFLIP15.Size = New System.Drawing.Size(194, 116)
        Me.pnlFLIP15.TabIndex = 543
        '
        'picFLIP15
        '
        Me.picFLIP15.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picFLIP15.Location = New System.Drawing.Point(2, 2)
        Me.picFLIP15.Name = "picFLIP15"
        Me.picFLIP15.Size = New System.Drawing.Size(190, 112)
        Me.picFLIP15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picFLIP15.TabIndex = 528
        Me.picFLIP15.TabStop = False
        '
        'pnlFLIP16
        '
        Me.pnlFLIP16.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlFLIP16.Controls.Add(Me.picFLIP16)
        Me.pnlFLIP16.Location = New System.Drawing.Point(3, 369)
        Me.pnlFLIP16.Name = "pnlFLIP16"
        Me.pnlFLIP16.Size = New System.Drawing.Size(194, 116)
        Me.pnlFLIP16.TabIndex = 544
        '
        'pnlFLIP17
        '
        Me.pnlFLIP17.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlFLIP17.Controls.Add(Me.picFLIP17)
        Me.pnlFLIP17.Location = New System.Drawing.Point(203, 369)
        Me.pnlFLIP17.Name = "pnlFLIP17"
        Me.pnlFLIP17.Size = New System.Drawing.Size(194, 116)
        Me.pnlFLIP17.TabIndex = 545
        '
        'pnlFLIP18
        '
        Me.pnlFLIP18.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlFLIP18.Controls.Add(Me.picFLIP18)
        Me.pnlFLIP18.Location = New System.Drawing.Point(403, 369)
        Me.pnlFLIP18.Name = "pnlFLIP18"
        Me.pnlFLIP18.Size = New System.Drawing.Size(194, 116)
        Me.pnlFLIP18.TabIndex = 546
        '
        'pnlFLIP19
        '
        Me.pnlFLIP19.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlFLIP19.Controls.Add(Me.picFLIP19)
        Me.pnlFLIP19.Location = New System.Drawing.Point(603, 369)
        Me.pnlFLIP19.Name = "pnlFLIP19"
        Me.pnlFLIP19.Size = New System.Drawing.Size(194, 116)
        Me.pnlFLIP19.TabIndex = 547
        '
        'picFLIP19
        '
        Me.picFLIP19.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.picFLIP19.Location = New System.Drawing.Point(2, 2)
        Me.picFLIP19.Name = "picFLIP19"
        Me.picFLIP19.Size = New System.Drawing.Size(190, 112)
        Me.picFLIP19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picFLIP19.TabIndex = 522
        Me.picFLIP19.TabStop = False
        '
        'pnlFLIP20
        '
        Me.pnlFLIP20.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.pnlFLIP20.Controls.Add(Me.picFLIP20)
        Me.pnlFLIP20.Location = New System.Drawing.Point(803, 369)
        Me.pnlFLIP20.Name = "pnlFLIP20"
        Me.pnlFLIP20.Size = New System.Drawing.Size(194, 116)
        Me.pnlFLIP20.TabIndex = 548
        '
        'cmbNUM
        '
        Me.cmbNUM.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbNUM.FormattingEnabled = True
        Me.cmbNUM.Location = New System.Drawing.Point(3, 4)
        Me.cmbNUM.Name = "cmbNUM"
        Me.cmbNUM.Size = New System.Drawing.Size(69, 20)
        Me.cmbNUM.TabIndex = 522
        '
        'GTRSTDO71
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1006, 524)
        Me.Controls.Add(Me.cmbNUM)
        Me.Controls.Add(Me.picSLIDE)
        Me.Controls.Add(Me.pnlFLIP)
        Me.Controls.Add(Me.cmdEXIT)
        Me.KeyPreview = True
        Me.Name = "GTRSTDO71"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "GTRSTDO71 : FLIP 5x4 MATRIX"
        CType(Me.picSLIDE, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFLIP06, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFLIP07, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFLIP08, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFLIP09, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFLIP11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFLIP12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFLIP13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFLIP14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFLIP16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFLIP17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFLIP18, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFLIP20, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlFLIP.ResumeLayout(False)
        Me.pnlFLIP01.ResumeLayout(False)
        CType(Me.picFLIP01, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlFLIP02.ResumeLayout(False)
        CType(Me.picFLIP02, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlFLIP03.ResumeLayout(False)
        CType(Me.picFLIP03, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlFLIP04.ResumeLayout(False)
        CType(Me.picFLIP04, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlFLIP05.ResumeLayout(False)
        CType(Me.picFLIP05, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlFLIP06.ResumeLayout(False)
        Me.pnlFLIP07.ResumeLayout(False)
        Me.pnlFLIP08.ResumeLayout(False)
        Me.pnlFLIP09.ResumeLayout(False)
        Me.pnlFLIP10.ResumeLayout(False)
        CType(Me.picFLIP10, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlFLIP11.ResumeLayout(False)
        Me.pnlFLIP12.ResumeLayout(False)
        Me.pnlFLIP13.ResumeLayout(False)
        Me.pnlFLIP14.ResumeLayout(False)
        Me.pnlFLIP15.ResumeLayout(False)
        CType(Me.picFLIP15, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlFLIP16.ResumeLayout(False)
        Me.pnlFLIP17.ResumeLayout(False)
        Me.pnlFLIP18.ResumeLayout(False)
        Me.pnlFLIP19.ResumeLayout(False)
        CType(Me.picFLIP19, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnlFLIP20.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cmdEXIT As Button
    Friend WithEvents picSLIDE As PictureBox
    Friend WithEvents picFLIP06 As PictureBox
    Friend WithEvents picFLIP07 As PictureBox
    Friend WithEvents picFLIP08 As PictureBox
    Friend WithEvents picFLIP09 As PictureBox
    Friend WithEvents picFLIP11 As PictureBox
    Friend WithEvents picFLIP12 As PictureBox
    Friend WithEvents picFLIP13 As PictureBox
    Friend WithEvents picFLIP14 As PictureBox
    Friend WithEvents picFLIP16 As PictureBox
    Friend WithEvents picFLIP17 As PictureBox
    Friend WithEvents picFLIP18 As PictureBox
    Friend WithEvents picFLIP20 As PictureBox
    Friend WithEvents pnlFLIP As TableLayoutPanel
    Friend WithEvents picFLIP19 As PictureBox
    Friend WithEvents picFLIP01 As PictureBox
    Friend WithEvents picFLIP02 As PictureBox
    Friend WithEvents picFLIP10 As PictureBox
    Friend WithEvents picFLIP15 As PictureBox
    Friend WithEvents pnlFLIP01 As Panel
    Friend WithEvents pnlFLIP02 As Panel
    Friend WithEvents pnlFLIP03 As Panel
    Friend WithEvents pnlFLIP04 As Panel
    Friend WithEvents pnlFLIP05 As Panel
    Friend WithEvents pnlFLIP06 As Panel
    Friend WithEvents pnlFLIP07 As Panel
    Friend WithEvents pnlFLIP08 As Panel
    Friend WithEvents pnlFLIP09 As Panel
    Friend WithEvents pnlFLIP10 As Panel
    Friend WithEvents pnlFLIP11 As Panel
    Friend WithEvents pnlFLIP12 As Panel
    Friend WithEvents pnlFLIP13 As Panel
    Friend WithEvents pnlFLIP14 As Panel
    Friend WithEvents pnlFLIP15 As Panel
    Friend WithEvents pnlFLIP16 As Panel
    Friend WithEvents pnlFLIP17 As Panel
    Friend WithEvents pnlFLIP18 As Panel
    Friend WithEvents pnlFLIP19 As Panel
    Friend WithEvents pnlFLIP20 As Panel
    Friend WithEvents picFLIP04 As PictureBox
    Friend WithEvents picFLIP05 As PictureBox
    Friend WithEvents picFLIP03 As PictureBox
    Friend WithEvents cmbNUM As ComboBox
End Class
