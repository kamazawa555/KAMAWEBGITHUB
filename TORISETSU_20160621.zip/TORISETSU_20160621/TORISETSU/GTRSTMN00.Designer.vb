﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class GTRSTMN00
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmdSLIDE = New System.Windows.Forms.Button()
        Me.cmdSCREENSHOT = New System.Windows.Forms.Button()
        Me.cmdPHOTO = New System.Windows.Forms.Button()
        Me.cmdPICTURE = New System.Windows.Forms.Button()
        Me.cmdIMAGE = New System.Windows.Forms.Button()
        Me.cmdSNAPSHOT = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cmdFLIP = New System.Windows.Forms.Button()
        Me.cmdFLIP2 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'cmdSLIDE
        '
        Me.cmdSLIDE.Location = New System.Drawing.Point(14, 35)
        Me.cmdSLIDE.Name = "cmdSLIDE"
        Me.cmdSLIDE.Size = New System.Drawing.Size(159, 23)
        Me.cmdSLIDE.TabIndex = 0
        Me.cmdSLIDE.Text = "SLIDExxx"
        Me.cmdSLIDE.UseVisualStyleBackColor = True
        '
        'cmdSCREENSHOT
        '
        Me.cmdSCREENSHOT.Location = New System.Drawing.Point(14, 64)
        Me.cmdSCREENSHOT.Name = "cmdSCREENSHOT"
        Me.cmdSCREENSHOT.Size = New System.Drawing.Size(159, 23)
        Me.cmdSCREENSHOT.TabIndex = 1
        Me.cmdSCREENSHOT.Text = "SCREENSHOTxxx"
        Me.cmdSCREENSHOT.UseVisualStyleBackColor = True
        '
        'cmdPHOTO
        '
        Me.cmdPHOTO.Location = New System.Drawing.Point(14, 93)
        Me.cmdPHOTO.Name = "cmdPHOTO"
        Me.cmdPHOTO.Size = New System.Drawing.Size(159, 23)
        Me.cmdPHOTO.TabIndex = 2
        Me.cmdPHOTO.Text = "PHOTOxxx"
        Me.cmdPHOTO.UseVisualStyleBackColor = True
        '
        'cmdPICTURE
        '
        Me.cmdPICTURE.Location = New System.Drawing.Point(14, 122)
        Me.cmdPICTURE.Name = "cmdPICTURE"
        Me.cmdPICTURE.Size = New System.Drawing.Size(159, 23)
        Me.cmdPICTURE.TabIndex = 3
        Me.cmdPICTURE.Text = "PICTURExxx"
        Me.cmdPICTURE.UseVisualStyleBackColor = True
        '
        'cmdIMAGE
        '
        Me.cmdIMAGE.Location = New System.Drawing.Point(14, 151)
        Me.cmdIMAGE.Name = "cmdIMAGE"
        Me.cmdIMAGE.Size = New System.Drawing.Size(159, 23)
        Me.cmdIMAGE.TabIndex = 4
        Me.cmdIMAGE.Text = "IMAGExxx"
        Me.cmdIMAGE.UseVisualStyleBackColor = True
        '
        'cmdSNAPSHOT
        '
        Me.cmdSNAPSHOT.Location = New System.Drawing.Point(14, 180)
        Me.cmdSNAPSHOT.Name = "cmdSNAPSHOT"
        Me.cmdSNAPSHOT.Size = New System.Drawing.Size(159, 23)
        Me.cmdSNAPSHOT.TabIndex = 5
        Me.cmdSNAPSHOT.Text = "SNAPSHOTxxx"
        Me.cmdSNAPSHOT.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(316, 12)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Using The Tao Framework (MIT Licence) for JoyPad support"
        '
        'cmdFLIP
        '
        Me.cmdFLIP.Location = New System.Drawing.Point(14, 211)
        Me.cmdFLIP.Name = "cmdFLIP"
        Me.cmdFLIP.Size = New System.Drawing.Size(159, 23)
        Me.cmdFLIP.TabIndex = 7
        Me.cmdFLIP.Text = "FLIPxxx"
        Me.cmdFLIP.UseVisualStyleBackColor = True
        '
        'cmdFLIP2
        '
        Me.cmdFLIP2.Location = New System.Drawing.Point(179, 211)
        Me.cmdFLIP2.Name = "cmdFLIP2"
        Me.cmdFLIP2.Size = New System.Drawing.Size(159, 23)
        Me.cmdFLIP2.TabIndex = 8
        Me.cmdFLIP2.Text = "FLIPxxx 5x4 MATRIX"
        Me.cmdFLIP2.UseVisualStyleBackColor = True
        '
        'GTRSTMN00
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(354, 244)
        Me.Controls.Add(Me.cmdFLIP2)
        Me.Controls.Add(Me.cmdFLIP)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cmdSNAPSHOT)
        Me.Controls.Add(Me.cmdIMAGE)
        Me.Controls.Add(Me.cmdPICTURE)
        Me.Controls.Add(Me.cmdPHOTO)
        Me.Controls.Add(Me.cmdSCREENSHOT)
        Me.Controls.Add(Me.cmdSLIDE)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "GTRSTMN00"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "GTRSTMN00 : TORISETSU"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents cmdSLIDE As Button
    Friend WithEvents cmdSCREENSHOT As Button
    Friend WithEvents cmdPHOTO As Button
    Friend WithEvents cmdPICTURE As Button
    Friend WithEvents cmdIMAGE As Button
    Friend WithEvents cmdSNAPSHOT As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents cmdFLIP As Button
    Friend WithEvents cmdFLIP2 As Button
End Class
